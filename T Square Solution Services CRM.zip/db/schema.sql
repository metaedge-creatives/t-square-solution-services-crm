-- Run once in MariaDB (CloudPanel > Databases > phpMyAdmin or via CLI).
-- The app also auto-creates this table on first request, so this file is optional.

CREATE TABLE IF NOT EXISTS app_state (
  id VARCHAR(64) NOT NULL PRIMARY KEY,
  data LONGTEXT NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
