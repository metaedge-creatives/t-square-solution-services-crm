## Goal
Make the CRM feel user-friendly and complete: richer forms, auto customer creation, per-record detail pages, better contract/invoice UX, and useful email automations.

## 1. Richer forms everywhere

**Leads** (`_authenticated.leads.tsx`) — add fields to "New lead" dialog:
- name, contact person, email, phone, address, city/zip, source, estimated value, service of interest, notes

**Customers** — add fields to dialog: address, city/zip, notes, tags. Show total jobs, lifetime value, and service history (derived).

**Bookings** ("New booking" dialog) — capture full details:
- Search or pick existing customer OR type new customer name+email+phone+address (auto-creates customer)
- Service dropdown, date, time, assignee, price, notes
- Creates booking AND customer record in one step

## 2. Invoices & Contracts — new-customer flow + own pages

- Replace the invoice/contract create dialogs with dedicated pages: `/invoices/new` and `/contracts/new`.
- Customer picker with search + "Add new customer" inline (creates customer on save).
- Contracts page: clean form (customer, service, start/end, amount, terms) → live PDF preview with branded template → "Save & email" flow.
- Extend `Contract` type with address/phone/email/notes so template is fully populated.

## 3. Detail pages

Add these dynamic routes with full record view + related entities:
- `/customers/$id` — profile + bookings + invoices + contracts + reviews for that customer
- `/leads/$id` — lead detail + activity + "convert to customer" button
- `/bookings/$id` — booking detail + linked customer + invoice quick-generate
- `/inspections/$id` — inspection detail

"View" buttons on each list row navigate to these pages.

## 4. Auto customer creation

Centralize a helper `ensureCustomer(name,email,phone,...)` in data-store — used by:
- New booking (manual)
- New invoice (manual)
- New contract (manual)
- WooCommerce webhook (already does this)

Settings → Integrations gets an "Auto-create customers from bookings" toggle (default on).

## 5. Email automations (SMS removed from priorities)

Preload built-in email automations users can toggle:
- Booking created → send confirmation email to customer
- Booking completed → send review request
- Invoice created → send invoice email with PDF link
- Contract sent → send contract email
- Lead created → send welcome email

Hook triggers into the corresponding `add`/`update` calls. Automations page shows these with on/off + template picker.

## 6. Small polish
- "Recent services" list on customer detail (derived from bookings + invoices).
- Booking calendar highlights today.
- Ensure the sidebar "Contracts" and "Invoices" pages open detail on click.

## Technical notes
- Detail pages use TanStack file convention: `_authenticated.customers.$id.tsx`, etc.
- No backend/Cloud — everything stays in the local `useStore`/localStorage flow.
- PDF generation continues via `src/lib/pdf.ts`.
- Email sending continues via `/api/send-email` + configured provider.
