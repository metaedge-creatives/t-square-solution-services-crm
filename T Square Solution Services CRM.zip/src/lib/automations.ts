// Client-side automation engine — fires on triggers from CRM actions.
import { logActivity } from "./activity-log";

export type TriggerType =
  | "booking.created"
  | "booking.completed"
  | "invoice.created"
  | "invoice.approved"
  | "invoice.paid"
  | "contract.sent"
  | "customer.created"
  | "lead.created";

export type ActionType = "send_email" | "log";

export interface AutomationRule {
  id: string;
  name: string;
  trigger: TriggerType;
  action: ActionType;
  enabled: boolean;
  /** Recipient — literal email OR "{{email}}" placeholder pulled from event payload */
  to?: string;
  subject?: string;
  message?: string; // supports {{customer}} {{amount}} {{service}} {{date}} {{email}}
}

const KEY = "tsquare_automations_v2";
const SEED_KEY = "tsquare_automations_seeded_v1";

const BUILT_IN: AutomationRule[] = [
  {
    id: "auto_booking_confirm",
    name: "Booking confirmation email",
    trigger: "booking.created",
    action: "send_email",
    enabled: true,
    to: "{{email}}",
    subject: "Your booking is confirmed — {{service}}",
    message:
      "Hi {{customer}},\n\nThanks for booking {{service}} with T Square Solutions on {{date}} at {{time}}.\n\nWe'll see you soon!\n— The T Square Team",
  },
  {
    id: "auto_booking_review",
    name: "Post-service review request",
    trigger: "booking.completed",
    action: "send_email",
    enabled: true,
    to: "{{email}}",
    subject: "How did we do, {{customer}}?",
    message:
      "Hi {{customer}},\n\nThanks for having us over for {{service}} on {{date}}. If we did a great job, would you mind leaving us a quick review? It means the world.\n\n— The T Square Team",
  },
  {
    id: "auto_invoice_sent",
    name: "Invoice email to customer",
    trigger: "invoice.approved",
    action: "send_email",
    enabled: true,
    to: "{{email}}",
    subject: "Invoice {{id}} from T Square Solutions",
    message:
      "Hi {{customer}},\n\nPlease find your invoice attached. Total due: ${{amount}}.\n\nThank you for your business,\nT Square Solutions",
  },
  {
    id: "auto_contract_sent",
    name: "Contract email to customer",
    trigger: "contract.sent",
    action: "send_email",
    enabled: true,
    to: "{{email}}",
    subject: "Your service agreement — {{service}}",
    message:
      "Hi {{customer}},\n\nAttached is your service agreement for {{service}}. Please review, sign and return at your convenience.\n\n— T Square Solutions",
  },
  {
    id: "auto_lead_welcome",
    name: "New lead — internal notification",
    trigger: "lead.created",
    action: "log",
    enabled: true,
    subject: "",
    message: "New lead: {{customer}} ({{email}}) from {{source}}",
  },
  {
    id: "auto_customer_welcome",
    name: "Welcome email to new customer",
    trigger: "customer.created",
    action: "send_email",
    enabled: false,
    to: "{{email}}",
    subject: "Welcome to T Square Solutions",
    message:
      "Hi {{customer}},\n\nWelcome aboard — we're delighted to have you. If you ever need anything, just reply to this email.\n\n— The T Square Team",
  },
];

export function readRules(): AutomationRule[] {
  if (typeof window === "undefined") return BUILT_IN;
  try {
    // Seed built-in rules once per browser so users see meaningful defaults.
    if (!window.localStorage.getItem(SEED_KEY)) {
      const raw = window.localStorage.getItem(KEY);
      const existing = raw ? (JSON.parse(raw) as AutomationRule[]) : [];
      const seeded = [
        ...BUILT_IN,
        ...existing.filter((r) => !BUILT_IN.some((b) => b.id === r.id)),
      ];
      window.localStorage.setItem(KEY, JSON.stringify(seeded));
      window.localStorage.setItem(SEED_KEY, "1");
      return seeded;
    }
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as AutomationRule[]) : BUILT_IN;
  } catch {
    return BUILT_IN;
  }
}
export function writeRules(list: AutomationRule[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(list));
}

export interface AutomationEvent {
  trigger: TriggerType;
  payload: Record<string, unknown>;
}

function interpolate(tpl: string, vars: Record<string, unknown>): string {
  return tpl.replace(/\{\{(\w+)\}\}/g, (_, k) => String(vars[k] ?? ""));
}

export async function fireEvent(ev: AutomationEvent) {
  const rules = readRules().filter((r) => r.enabled && r.trigger === ev.trigger);
  for (const r of rules) {
    if (r.action === "log") {
      logActivity({
        actor: "Automation",
        entity: "automation",
        action: "fired",
        summary: `${r.name}: ${interpolate(r.message ?? "", ev.payload)}`,
      });
    } else if (r.action === "send_email") {
      const to = interpolate(r.to ?? "{{email}}", ev.payload).trim();
      if (!to || !to.includes("@")) {
        logActivity({
          actor: "Automation",
          entity: "email",
          action: "skipped",
          summary: `${r.name}: no recipient`,
        });
        continue;
      }
      const subject = interpolate(r.subject ?? "", ev.payload);
      const body = interpolate(r.message ?? "", ev.payload);
      try {
        const res = await fetch("/api/send-email", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ to, subject, html: body.replace(/\n/g, "<br>"), text: body }),
        });
        const ok = res.ok;
        logActivity({
          actor: "Automation",
          entity: "email",
          action: ok ? "sent" : "failed",
          summary: `${r.name} → ${to}`,
        });
      } catch (err) {
        logActivity({
          actor: "Automation",
          entity: "email",
          action: "failed",
          summary: `${r.name} → ${to} (${err instanceof Error ? err.message : "error"})`,
        });
      }
    }
  }
}
