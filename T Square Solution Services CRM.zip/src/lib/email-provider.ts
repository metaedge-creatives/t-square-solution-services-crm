/**
 * Multi-provider email integration (client-side config + server dispatch).
 * Credentials are stored in this browser's localStorage only. Sending calls
 * hit our /api/send-email server route, which forwards to the selected
 * provider's REST API (no third-party backend, no secrets on the server).
 */

export type EmailProviderId =
  | "brevo"
  | "resend"
  | "sendgrid"
  | "mailgun"
  | "mailchimp";

export interface EmailProviderCommon {
  fromName: string;
  fromEmail: string;
  connectedAt: string;
  lastVerifiedAt?: string;
  lastVerifyError?: string;
}


export interface BrevoCreds extends EmailProviderCommon {
  apiKey: string;
}
export interface ResendCreds extends EmailProviderCommon {
  apiKey: string;
}
export interface SendGridCreds extends EmailProviderCommon {
  apiKey: string;
}
export interface MailgunCreds extends EmailProviderCommon {
  apiKey: string;
  domain: string;
  region: "us" | "eu";
}
export interface MailchimpCreds extends EmailProviderCommon {
  apiKey: string;
  serverPrefix: string;
}

export interface EmailIntegrations {
  active: EmailProviderId | null;
  brevo?: BrevoCreds;
  resend?: ResendCreds;
  sendgrid?: SendGridCreds;
  mailgun?: MailgunCreds;
  mailchimp?: MailchimpCreds;
}

const KEY = "tsq_email_integrations_v2";
const LEGACY_MC_KEY = "tsq_mailchimp_settings";

export const PROVIDER_LABELS: Record<EmailProviderId, string> = {
  brevo: "Brevo (Sendinblue)",
  resend: "Resend",
  sendgrid: "SendGrid",
  mailgun: "Mailgun",
  mailchimp: "Mailchimp",
};

export function loadIntegrations(): EmailIntegrations {
  if (typeof window === "undefined") return { active: null };
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as EmailIntegrations;
    // migrate legacy mailchimp-only config
    const legacy = window.localStorage.getItem(LEGACY_MC_KEY);
    if (legacy) {
      const mc = JSON.parse(legacy);
      const migrated: EmailIntegrations = {
        active: "mailchimp",
        mailchimp: {
          apiKey: mc.apiKey,
          serverPrefix: mc.serverPrefix,
          fromName: mc.fromName,
          fromEmail: mc.fromEmail,
          connectedAt: mc.connectedAt,
        },
      };
      window.localStorage.setItem(KEY, JSON.stringify(migrated));
      return migrated;
    }
  } catch {
    /* ignore */
  }
  return { active: null };
}

export function saveIntegrations(next: EmailIntegrations) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event("tsq:integrations-updated"));
}

export interface SendEmailInput {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  replyTo?: string;
}

export interface SendEmailResult {
  ok: boolean;
  provider: EmailProviderId | null;
  sent: number;
  failed: number;
  errors?: string[];
}

/** Client helper: sends via the currently-active provider through /api/send-email. */
export async function sendEmail(input: SendEmailInput): Promise<SendEmailResult> {
  const cfg = loadIntegrations();
  if (!cfg.active) {
    return {
      ok: false,
      provider: null,
      sent: 0,
      failed: 1,
      errors: ["No email provider connected. Open Email Marketing → Integrations."],
    };
  }
  const creds = cfg[cfg.active];
  if (!creds) {
    return {
      ok: false,
      provider: cfg.active,
      sent: 0,
      failed: 1,
      errors: [`${PROVIDER_LABELS[cfg.active]} is selected but not configured.`],
    };
  }
  try {
    const res = await fetch("/api/send-email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ provider: cfg.active, creds, message: input }),
    });
    const data = (await res.json()) as SendEmailResult;
    return data;
  } catch (err) {
    return {
      ok: false,
      provider: cfg.active,
      sent: 0,
      failed: 1,
      errors: [String(err)],
    };
  }
}
