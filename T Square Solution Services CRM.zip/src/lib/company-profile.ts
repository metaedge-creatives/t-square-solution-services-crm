import { useEffect, useState } from "react";

export const COMPANY_KEY = "tsquare_crm_company_v1";
export const DOCS_KEY = "tsquare_crm_docs_v1";

export interface CompanyProfile {
  name: string;
  email: string;
  phone: string;
  website: string;
  address: string;
  logoDataUrl?: string; // optional embedded logo
  taxId?: string;
  paymentInstructions?: string;
}

export const defaultCompany: CompanyProfile = {
  name: "T Square Solution Services",
  email: "hello@tsquaresulotionservices.com",
  phone: "(415) 555-0100",
  website: "tsquaresulotionservices.com",
  address: "1234 Market St, Suite 200\nSan Francisco, CA 94103",
  taxId: "",
  paymentInstructions:
    "Please make payment within the due date. Bank transfer or check accepted.",
};


export interface DocTemplates {
  invoiceHeader: string;
  invoiceFooter: string;
  invoiceEmailSubject: string;
  invoiceEmailBody: string;

  quoteHeader: string;
  quoteFooter: string;
  quoteEmailSubject: string;
  quoteEmailBody: string;

  contractIntro: string;
  contractBody: string;
  contractTerms: string;
  contractEmailSubject: string;
  contractEmailBody: string;
}

export const defaultDocs: DocTemplates = {
  invoiceHeader: "INVOICE",
  invoiceFooter:
    "Thank you for choosing {{company_name}}. For questions about this invoice contact us at {{company_email}}.",
  invoiceEmailSubject: "Invoice {{invoice_id}} from {{company_name}}",
  invoiceEmailBody:
    "Hi {{customer_name}},\n\nPlease find attached invoice {{invoice_id}} for ${{amount}} — due {{due_date}}.\n\nIf you have any questions, just reply to this email.\n\nThanks,\n{{company_name}}",

  quoteHeader: "QUOTE / PROPOSAL",
  quoteFooter:
    "This quote is valid for 30 days. Prices in USD. — {{company_name}}",
  quoteEmailSubject: "Your quote {{quote_id}} from {{company_name}}",
  quoteEmailBody:
    "Hi {{customer_name}},\n\nHere's your quote {{quote_id}} for {{service}} — ${{amount}}.\n\nReply to accept or ask any questions.\n\n{{company_name}}",

  contractIntro: `SERVICE AGREEMENT

This Service Agreement ("Agreement") is entered into on {{today}} by and between:

Service Provider:
{{company_name}}
{{company_address}}
Email: {{company_email}} · Phone: {{company_phone}}

Client:
{{customer_name}}
{{customer_email}}

Service: {{service}}
Contract value: \${{amount}}
Term: {{start_date}} → {{end_date}}`,

  contractBody: `The Service Provider agrees to provide {{service}} to the Client, beginning on {{start_date}} and continuing until {{end_date}} unless terminated earlier under the terms below. In consideration of these services, the Client agrees to pay a total of \${{amount}}, invoiced per the payment schedule agreed between the parties. {{payment_instructions}}`,

  contractTerms: `The Service Provider will perform all work in a professional manner using trained personnel and appropriate equipment, and will maintain commercial liability insurance throughout the term of this Agreement. The Client will provide reasonable access to the premises during scheduled service times. Either party may terminate this Agreement with 14 days' written notice; any unpaid, completed work remains due on termination. Neither party is liable for indirect or consequential damages. This document represents the entire agreement between the parties and supersedes any prior discussions.


Signed:

_________________________          _________________________
{{company_name}}                   {{customer_name}}
Date: {{today}}                    Date: ______________`,
  contractEmailSubject:
    "Service agreement {{contract_id}} — please review & sign",
  contractEmailBody:
    "Hi {{customer_name}},\n\nAttached is the service agreement {{contract_id}} for {{service}}.\n\nPlease review, sign, and return a copy. Reach out with any questions.\n\nThanks,\n{{company_name}}",
};

/** Assemble full contract text: intro + (custom body || default body) + terms. */
export function assembleContract(
  docs: DocTemplates,
  vars: Record<string, string | number | undefined | null>,
  customBody?: string,
): string {
  const middle = (customBody && customBody.trim().length > 0) ? customBody : docs.contractBody;
  const full = `${docs.contractIntro}\n\n${middle}\n\n${docs.contractTerms}`;
  return interpolate(full, vars);
}

function readLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? { ...fallback, ...(JSON.parse(raw) as Partial<T>) } : fallback;
  } catch {
    return fallback;
  }
}

export function writeCompany(c: CompanyProfile) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(COMPANY_KEY, JSON.stringify(c));
  window.dispatchEvent(new Event("tsquare:company-updated"));
}

export function writeDocs(d: DocTemplates) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(DOCS_KEY, JSON.stringify(d));
  window.dispatchEvent(new Event("tsquare:docs-updated"));
}

export function getCompany(): CompanyProfile {
  return readLS<CompanyProfile>(COMPANY_KEY, defaultCompany);
}
export function getDocs(): DocTemplates {
  return readLS<DocTemplates>(DOCS_KEY, defaultDocs);
}

export function useCompanyProfile() {
  const [company, setCompany] = useState<CompanyProfile>(defaultCompany);
  useEffect(() => {
    setCompany(getCompany());
    const h = () => setCompany(getCompany());
    window.addEventListener("tsquare:company-updated", h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener("tsquare:company-updated", h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return company;
}

export function useDocTemplates() {
  const [docs, setDocs] = useState<DocTemplates>(defaultDocs);
  useEffect(() => {
    setDocs(getDocs());
    const h = () => setDocs(getDocs());
    window.addEventListener("tsquare:docs-updated", h);
    window.addEventListener("storage", h);
    return () => {
      window.removeEventListener("tsquare:docs-updated", h);
      window.removeEventListener("storage", h);
    };
  }, []);
  return docs;
}

/** Replace {{key}} in template with the given values (case-insensitive keys). */
export function interpolate(
  template: string,
  vars: Record<string, string | number | undefined | null>,
): string {
  const map: Record<string, string> = {};
  for (const [k, v] of Object.entries(vars)) {
    map[k.toLowerCase()] = v == null ? "" : String(v);
  }
  return template.replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_, key: string) => {
    const val = map[String(key).toLowerCase()];
    return val ?? "";
  });
}

/** Standard variable set derived from company + given entity fields. */
export function buildVars(
  company: CompanyProfile,
  extra: Record<string, string | number | undefined | null> = {},
): Record<string, string> {
  const today = new Date().toISOString().slice(0, 10);
  const base: Record<string, string> = {
    company_name: company.name,
    company_email: company.email,
    company_phone: company.phone,
    company_website: company.website,
    company_address: company.address,
    payment_instructions: company.paymentInstructions ?? "",
    today,
  };
  const out: Record<string, string> = { ...base };
  for (const [k, v] of Object.entries(extra)) {
    out[k] = v == null ? "" : String(v);
  }
  return out;
}
