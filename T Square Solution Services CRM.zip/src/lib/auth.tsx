import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Permission } from "@/lib/data-store";
import { ALL_PERMISSIONS } from "@/lib/data-store";

// Frontend-only multi-user auth with per-user permissions. Data lives in
// localStorage; suitable for single-device/team CRM without a backend.
export type Role = "owner" | "admin" | "manager" | "cleaner" | "client";

export interface CrmUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  password: string; // plaintext (frontend-only). Swap for hash when wired to backend.
  permissions: Permission[]; // owner ignores this list (has everything).
  avatarUrl?: string;
  createdAt: number;
}

export type AuthUser = Omit<CrmUser, "password">;

interface AuthContextValue {
  user: AuthUser | null;
  isAuthenticated: boolean;
  users: AuthUser[];
  login: (email: string, password: string) => Promise<AuthUser>;
  logout: () => void;
  hasPermission: (p: Permission) => boolean;
  addUser: (input: Omit<CrmUser, "id" | "createdAt">) => AuthUser;
  updateUser: (id: string, patch: Partial<Omit<CrmUser, "id" | "createdAt">>) => void;
  removeUser: (id: string) => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const USERS_KEY = "tsquare_crm_users_v1";
const SESSION_KEY = "tsquare_crm_session_v1";
const LEGACY_KEY = "tsquare_crm_user";

const OWNER_SEED: CrmUser = {
  id: "user_owner",
  name: "Tsquare Admin",
  email: "info@metaedgecreatives.com",
  role: "owner",
  password: "Admin@2026",
  permissions: [...ALL_PERMISSIONS],
  createdAt: Date.now(),
};

function readUsers(): CrmUser[] {
  if (typeof window === "undefined") return [OWNER_SEED];
  try {
    const raw = window.localStorage.getItem(USERS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as CrmUser[];
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch { /* empty */ }
  const seed = [OWNER_SEED];
  try { window.localStorage.setItem(USERS_KEY, JSON.stringify(seed)); } catch { /* empty */ }
  return seed;
}

function writeUsers(list: CrmUser[]) {
  if (typeof window === "undefined") return;
  try { window.localStorage.setItem(USERS_KEY, JSON.stringify(list)); } catch { /* empty */ }
}

function normalizeSession(u: Partial<AuthUser> | null): AuthUser | null {
  if (!u || !u.id || !u.email) return null;
  return {
    id: u.id,
    name: u.name ?? u.email,
    email: u.email,
    role: (u.role as Role) ?? "owner",
    permissions: Array.isArray(u.permissions) ? (u.permissions as Permission[]) : [...ALL_PERMISSIONS],
    avatarUrl: u.avatarUrl,
    createdAt: u.createdAt ?? Date.now(),
  };
}

function readSession(): AuthUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (raw) return normalizeSession(JSON.parse(raw) as AuthUser);
    // legacy migration
    const legacy = window.localStorage.getItem(LEGACY_KEY);
    if (legacy) {
      const u = normalizeSession(JSON.parse(legacy));
      if (u) window.localStorage.setItem(SESSION_KEY, JSON.stringify(u));
      window.localStorage.removeItem(LEGACY_KEY);
      return u;
    }
  } catch { /* empty */ }
  return null;
}


function stripPassword(u: CrmUser): AuthUser {
  const { password: _pw, ...rest } = u;
  void _pw;
  return rest;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<CrmUser[]>(() => readUsers());
  const [user, setUser] = useState<AuthUser | null>(() => readSession());

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === SESSION_KEY) setUser(readSession());
      if (e.key === USERS_KEY) setUsers(readUsers());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const persistUsers = useCallback((next: CrmUser[]) => {
    setUsers(next);
    writeUsers(next);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const list = readUsers();
    const found = list.find(
      (u) => u.email.trim().toLowerCase() === email.trim().toLowerCase() && u.password === password,
    );
    if (!found) throw new Error("Invalid email or password.");
    const safe = stripPassword(found);
    window.localStorage.setItem(SESSION_KEY, JSON.stringify(safe));
    setUser(safe);
    return safe;
  }, []);

  const logout = useCallback(() => {
    window.localStorage.removeItem(SESSION_KEY);
    setUser(null);
  }, []);

  const hasPermission = useCallback(
    (p: Permission) => {
      if (!user) return false;
      if (user.role === "owner") return true;
      return Array.isArray(user.permissions) && user.permissions.includes(p);
    },
    [user],
  );


  const addUser = useCallback<AuthContextValue["addUser"]>((input) => {
    const created: CrmUser = {
      ...input,
      id: `user_${Math.random().toString(36).slice(2, 10)}`,
      createdAt: Date.now(),
      permissions: input.role === "owner" ? [...ALL_PERMISSIONS] : input.permissions,
    };
    const next = [...readUsers(), created];
    persistUsers(next);
    return stripPassword(created);
  }, [persistUsers]);

  const updateUser = useCallback<AuthContextValue["updateUser"]>((id, patch) => {
    const list = readUsers();
    const next = list.map((u) => {
      if (u.id !== id) return u;
      const merged = { ...u, ...patch } as CrmUser;
      if (merged.role === "owner") merged.permissions = [...ALL_PERMISSIONS];
      if (!patch.password) merged.password = u.password;
      return merged;
    });
    persistUsers(next);
    // sync current session if editing self
    if (user?.id === id) {
      const updated = next.find((u) => u.id === id);
      if (updated) {
        const safe = stripPassword(updated);
        window.localStorage.setItem(SESSION_KEY, JSON.stringify(safe));
        setUser(safe);
      }
    }
  }, [persistUsers, user?.id]);

  const removeUser = useCallback((id: string) => {
    const list = readUsers();
    if (list.length <= 1) throw new Error("At least one user must remain.");
    const target = list.find((u) => u.id === id);
    if (target?.role === "owner") throw new Error("Owner account can't be deleted.");
    persistUsers(list.filter((u) => u.id !== id));
    if (user?.id === id) logout();
  }, [persistUsers, user?.id, logout]);

  const safeUsers = useMemo(() => users.map(stripPassword), [users]);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      isAuthenticated: !!user,
      users: safeUsers,
      login,
      logout,
      hasPermission,
      addUser,
      updateUser,
      removeUser,
    }),
    [user, safeUsers, login, logout, hasPermission, addUser, updateUser, removeUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}

export function getStoredUser() {
  return readSession();
}
