// Simple client-side activity log, persisted in localStorage
export interface Activity {
  id: string;
  ts: string; // ISO
  actor: string;
  entity: string; // e.g. "invoice", "booking"
  action: string; // e.g. "created", "updated", "deleted", "approved", "sent"
  summary: string;
  entityId?: string;
}

const KEY = "tsquare_activity_log_v1";
const MAX = 500;

export function readActivity(): Activity[] {
  if (typeof window === "undefined") return [];
  try { const raw = window.localStorage.getItem(KEY); return raw ? (JSON.parse(raw) as Activity[]) : []; }
  catch { return []; }
}
export function logActivity(a: Omit<Activity, "id" | "ts">) {
  if (typeof window === "undefined") return;
  const item: Activity = { ...a, id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, ts: new Date().toISOString() };
  const list = [item, ...readActivity()].slice(0, MAX);
  try { window.localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* quota */ }
  try { window.dispatchEvent(new CustomEvent("tsquare:activity", { detail: item })); } catch { /* ignore */ }
}
export function clearActivity() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(KEY);
  try { window.dispatchEvent(new Event("tsquare:activity")); } catch { /* ignore */ }
}
