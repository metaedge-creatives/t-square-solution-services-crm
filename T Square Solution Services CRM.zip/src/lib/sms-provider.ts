// SMS provider (Twilio, GatewayAPI) — creds stored in localStorage; send via /api/send-sms
export type SmsProviderId = "twilio" | "gatewayapi";

export interface SmsProviderConfig {
  id: string;
  provider: SmsProviderId;
  label: string;
  from: string; // Twilio: E.164 phone or Messaging Service SID; GatewayAPI: sender name
  creds: Record<string, string>;
  active?: boolean;
}

const KEY = "tsquare_sms_providers_v1";

export function readProviders(): SmsProviderConfig[] {
  if (typeof window === "undefined") return [];
  try { const raw = window.localStorage.getItem(KEY); return raw ? (JSON.parse(raw) as SmsProviderConfig[]) : []; }
  catch { return []; }
}
export function writeProviders(list: SmsProviderConfig[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(list));
}
export function activeProvider(): SmsProviderConfig | undefined {
  return readProviders().find((p) => p.active) ?? readProviders()[0];
}

export async function sendSms(to: string, text: string): Promise<{ ok: boolean; error?: string }> {
  const p = activeProvider();
  if (!p) return { ok: false, error: "No SMS provider configured — add one in Settings → Integrations" };
  try {
    const res = await fetch("/api/send-sms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ provider: p.provider, from: p.from, creds: p.creds, to, text }),
    });
    const j = (await res.json()) as { ok: boolean; error?: string };
    return j;
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}
