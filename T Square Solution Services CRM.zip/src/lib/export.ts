// CSV export utility — converts an array of objects to CSV and triggers download.

function escape(v: unknown): string {
  if (v === null || v === undefined) return "";
  const s = typeof v === "object" ? JSON.stringify(v) : String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function toCsv<T>(rows: T[], headers?: (keyof T)[]): string {
  if (!rows.length && !headers?.length) return "";
  const cols = (headers ?? (Object.keys(rows[0] ?? {}) as (keyof T)[])) as (keyof T)[];
  const head = cols.map((c) => escape(String(c))).join(",");
  const body = rows.map((r) => cols.map((c) => escape((r as Record<string, unknown>)[c as string])).join(",")).join("\n");
  return `${head}\n${body}`;
}

export function downloadCsv<T>(
  filename: string,
  rows: T[],
  headers?: (keyof T)[],
) {
  const csv = toCsv(rows, headers);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename.endsWith(".csv") ? filename : `${filename}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
