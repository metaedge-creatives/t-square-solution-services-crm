// Static mock data used to make the CRM front-end feel real.
// Replace with real backend queries later.

const STANDARD_ADDONS = [
  { name: "Inside Fridge", price: 25 },
  { name: "Inside Oven", price: 30 },
  { name: "Laundry Service", price: 20 },
  { name: "Dishwashing", price: 15 },
  { name: "Organization", price: 40 },
];

export const services = [
  {
    id: "s1",
    name: "Junk Removal",
    tagline: "Full-service pickup & haul-away",
    basePrice: 800,
    unit: "/ job",
    color: "bg-primary/10 text-primary",
    options: [
      { name: "Residential junk removal", price: 800 },
      { name: "Office & commercial cleanouts", price: 1200 },
      { name: "Garage cleanout", price: 400 },
      { name: "Attic cleanout", price: 350 },
      { name: "Basement cleanout", price: 500 },
      { name: "Furniture removal (per item)", price: 75 },
      { name: "Appliance removal (per item)", price: 100 },
      { name: "Yard debris removal", price: 300 },
      { name: "Construction debris cleanup", price: 600 },
      { name: "Move-in / move-out cleanout", price: 450 },
    ],
    addOns: [],
  },
  {
    id: "s2",
    name: "Commercial Cleaning",
    tagline: "Custom Contracts Available",
    basePrice: 100,
    unit: "/ visit",
    color: "bg-primary/10 text-primary",
    options: [
      { name: "Small Business", price: 100 },
      { name: "Medium Business", price: 200 },
      { name: "Large Commercial Space", price: 400 },
    ],
    addOns: STANDARD_ADDONS,
  },
  {
    id: "s3",
    name: "Office Cleaning",
    tagline: "Monthly Contracts Available (Discounted Pricing)",
    basePrice: 80,
    unit: "/ visit",
    color: "bg-primary/10 text-primary",
    options: [
      { name: "Small Office", price: 80 },
      { name: "Medium Office", price: 150 },
      { name: "Large Office", price: 280 },
    ],
    addOns: STANDARD_ADDONS,
  },
  {
    id: "s4",
    name: "Airbnb / Short-Term Rental Cleaning",
    tagline: "Fast turnovers with hotel-quality finish",
    basePrice: 70,
    unit: "/ turnover",
    color: "bg-secondary/40 text-secondary-foreground",
    options: [
      { name: "Studio / Small Unit", price: 70 },
      { name: "1–2 Bedroom", price: 110 },
      { name: "3+ Bedroom", price: 160 },
    ],
    addOns: [
      ...STANDARD_ADDONS,
      { name: "Add-ons (Laundry / Restocking)", price: 45 },
    ],
  },
  {
    id: "s5",
    name: "Move-In / Move-Out Cleaning",
    tagline: "Deep, top-to-bottom transition cleans",
    basePrice: 180,
    unit: "/ job",
    color: "bg-success/20 text-success-foreground",
    options: [
      { name: "Small Unit", price: 180 },
      { name: "Medium Home", price: 280 },
      { name: "Large Home", price: 420 },
    ],
    addOns: STANDARD_ADDONS,
  },
  {
    id: "s6",
    name: "Apartment Cleaning",
    tagline: "Recurring & one-off apartment cleans",
    basePrice: 100,
    unit: "/ visit",
    color: "bg-primary/10 text-primary",
    options: [
      { name: "Studio / 1 Bedroom", price: 100 },
      { name: "2 Bedroom", price: 150 },
      { name: "3 Bedroom", price: 220 },
    ],
    addOns: [
      ...STANDARD_ADDONS,
      { name: "Deep Cleaning Add-on", price: 60 },
    ],
  },
];

export const customers = [
  { id: "c1", name: "Nova Coworking", contact: "Amelia Reyes", email: "amelia@novacowork.com", phone: "(415) 555-2081", type: "Commercial", jobs: 34, lifetime: 12480, since: "2023-04-11" },
  { id: "c2", name: "The Harper Residence", contact: "Jonah Harper", email: "jonah.harper@mail.com", phone: "(415) 555-8712", type: "Residential", jobs: 22, lifetime: 4980, since: "2023-08-02" },
  { id: "c3", name: "Bay Bloom Airbnbs", contact: "Priya Rao", email: "priya@baybloom.co", phone: "(415) 555-3391", type: "Airbnb", jobs: 118, lifetime: 15920, since: "2022-11-19" },
  { id: "c4", name: "Larkin & Vale LLP", contact: "Marcus Vale", email: "m.vale@larkinvale.com", phone: "(415) 555-6640", type: "Office", jobs: 44, lifetime: 8620, since: "2023-01-27" },
  { id: "c5", name: "The Ortiz Family", contact: "Sofia Ortiz", email: "sofia@ortizhome.com", phone: "(415) 555-1177", type: "Residential", jobs: 9, lifetime: 1620, since: "2024-06-04" },
  { id: "c6", name: "Studio 4 Yoga", contact: "Kai Nakamura", email: "kai@studio4.yoga", phone: "(415) 555-0022", type: "Commercial", jobs: 12, lifetime: 2880, since: "2024-01-15" },
];

export const leads = [
  { id: "l1", name: "Sunset Dental", contact: "Dr. Patel", email: "office@sunsetdental.com", source: "Website", value: 480, stage: "New" },
  { id: "l2", name: "Presidio Lofts HOA", contact: "Rita Sinclair", email: "rita@presidiolofts.org", source: "Referral", value: 1200, stage: "Contacted" },
  { id: "l3", name: "Craft & Ember Cafe", contact: "Owen Diaz", email: "owen@craftember.co", source: "Instagram", value: 320, stage: "Quoted" },
  { id: "l4", name: "Mission Loft #402", contact: "Chloe Winters", email: "chloe.w@mail.com", source: "Yelp", value: 220, stage: "Won" },
  { id: "l5", name: "North Beach Airbnb Portfolio", contact: "Mateo Aguilar", email: "mateo@nbstays.com", source: "Referral", value: 3400, stage: "New" },
  { id: "l6", name: "Bay Area Legal Group", contact: "Hannah Bloom", email: "hbloom@balegal.com", source: "Google", value: 780, stage: "Contacted" },
] as const;

export const leadStages = ["New", "Contacted", "Quoted", "Won", "Lost"] as const;

export const quotes = [
  { id: "Q-1042", customer: "Sunset Dental", service: "Office Cleaning", amount: 480, status: "Sent", sentAt: "2026-07-01" },
  { id: "Q-1041", customer: "Presidio Lofts HOA", service: "Commercial Cleaning", amount: 1200, status: "Draft", sentAt: "—" },
  { id: "Q-1040", customer: "Craft & Ember Cafe", service: "Office Cleaning", amount: 320, status: "Accepted", sentAt: "2026-06-28" },
  { id: "Q-1039", customer: "Mission Loft #402", service: "Move In / Move Out", amount: 220, status: "Accepted", sentAt: "2026-06-25" },
  { id: "Q-1038", customer: "North Beach Airbnb Portfolio", service: "Airbnb Turnover", amount: 3400, status: "Sent", sentAt: "2026-06-24" },
  { id: "Q-1037", customer: "Bay Area Legal Group", service: "Office Cleaning", amount: 780, status: "Declined", sentAt: "2026-06-20" },
];

export const staff = [
  { id: "u1", name: "Marisol Vega", role: "Manager", jobs: 42, rating: 4.9, status: "Active", email: "marisol@tsquare.co" },
  { id: "u2", name: "Deon Carter", role: "Cleaner", jobs: 96, rating: 4.8, status: "Active", email: "deon@tsquare.co" },
  { id: "u3", name: "Ana Petrova", role: "Cleaner", jobs: 88, rating: 4.7, status: "Active", email: "ana@tsquare.co" },
  { id: "u4", name: "Jamal Ellis", role: "Cleaner", jobs: 71, rating: 4.6, status: "Time off", email: "jamal@tsquare.co" },
  { id: "u5", name: "Sana Iqbal", role: "Manager", jobs: 33, rating: 4.9, status: "Active", email: "sana@tsquare.co" },
];

export const bookings = [
  { id: "b1", customer: "Nova Coworking", service: "Commercial Cleaning", date: "2026-07-06", time: "07:00", assignee: "Deon Carter", status: "Scheduled" },
  { id: "b2", customer: "Bay Bloom Airbnbs — Unit 12", service: "Airbnb Turnover", date: "2026-07-06", time: "11:00", assignee: "Ana Petrova", status: "In progress" },
  { id: "b3", customer: "Larkin & Vale LLP", service: "Office Cleaning", date: "2026-07-06", time: "18:30", assignee: "Jamal Ellis", status: "Scheduled" },
  { id: "b4", customer: "The Harper Residence", service: "Residential Deep Clean", date: "2026-07-07", time: "09:00", assignee: "Marisol Vega", status: "Scheduled" },
  { id: "b5", customer: "Studio 4 Yoga", service: "Commercial Cleaning", date: "2026-07-07", time: "20:00", assignee: "Deon Carter", status: "Scheduled" },
  { id: "b6", customer: "The Ortiz Family", service: "Residential Deep Clean", date: "2026-07-08", time: "10:00", assignee: "Ana Petrova", status: "Scheduled" },
];

export const invoices = [
  { id: "INV-2081", customer: "Nova Coworking", amount: 1280, issued: "2026-06-30", due: "2026-07-14", status: "Paid" },
  { id: "INV-2080", customer: "Larkin & Vale LLP", amount: 720, issued: "2026-06-28", due: "2026-07-12", status: "Sent" },
  { id: "INV-2079", customer: "Bay Bloom Airbnbs", amount: 3420, issued: "2026-06-25", due: "2026-07-09", status: "Overdue" },
  { id: "INV-2078", customer: "The Harper Residence", amount: 220, issued: "2026-06-22", due: "2026-07-06", status: "Paid" },
  { id: "INV-2077", customer: "Studio 4 Yoga", amount: 480, issued: "2026-06-20", due: "2026-07-04", status: "Paid" },
];

export const inspections = [
  { id: "i1", job: "Nova Coworking — 06/29", inspector: "Marisol Vega", score: 96, status: "Passed" },
  { id: "i2", job: "Bay Bloom #7 — 06/30", inspector: "Sana Iqbal", score: 88, status: "Passed" },
  { id: "i3", job: "Larkin & Vale — 06/28", inspector: "Marisol Vega", score: 72, status: "Needs rework" },
  { id: "i4", job: "The Harper Residence — 06/22", inspector: "Sana Iqbal", score: 100, status: "Passed" },
];

export const reviews = [
  { id: "r1", customer: "Sofia Ortiz", rating: 5, text: "The team was punctual, kind and left the house sparkling. Booking again next month.", date: "2026-06-30" },
  { id: "r2", customer: "Jonah Harper", rating: 5, text: "Ana was incredible. Attention to detail like nothing we've experienced before.", date: "2026-06-24" },
  { id: "r3", customer: "Kai Nakamura", rating: 4, text: "Great job on the studio. Missed one mirror but responsive when we flagged it.", date: "2026-06-18" },
  { id: "r4", customer: "Priya Rao", rating: 5, text: "Best Airbnb turnover crew in the Bay. Guests keep leaving 5★ reviews.", date: "2026-06-14" },
];

export const revenueSeries = [
  { month: "Jan", revenue: 18400 },
  { month: "Feb", revenue: 21800 },
  { month: "Mar", revenue: 24950 },
  { month: "Apr", revenue: 27600 },
  { month: "May", revenue: 31240 },
  { month: "Jun", revenue: 34980 },
];

export const jobsByServiceSeries = [
  { service: "Commercial", jobs: 42 },
  { service: "Office", jobs: 31 },
  { service: "Airbnb", jobs: 88 },
  { service: "Move In/Out", jobs: 12 },
  { service: "Apartment", jobs: 24 },
  { service: "Residential", jobs: 37 },
];

export const activity = [
  { id: "a1", who: "Marisol Vega", what: "marked booking b1 as scheduled", when: "2 min ago" },
  { id: "a2", who: "Ana Petrova", what: "completed inspection i2 with score 88", when: "18 min ago" },
  { id: "a3", who: "System", what: "sent Q-1042 to Sunset Dental", when: "1 hour ago" },
  { id: "a4", who: "Deon Carter", what: "clocked in at Nova Coworking", when: "3 hours ago" },
  { id: "a5", who: "System", what: "invoice INV-2079 is now overdue", when: "yesterday" },
];

export const serviceAreas = [
  { id: "sa1", zip: "94103", city: "San Francisco", surcharge: 0 },
  { id: "sa2", zip: "94110", city: "San Francisco", surcharge: 0 },
  { id: "sa3", zip: "94133", city: "San Francisco", surcharge: 15 },
  { id: "sa4", zip: "94612", city: "Oakland", surcharge: 25 },
  { id: "sa5", zip: "94301", city: "Palo Alto", surcharge: 40 },
];
