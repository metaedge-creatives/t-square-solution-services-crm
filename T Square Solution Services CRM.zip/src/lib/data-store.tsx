import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  bookings as seedBookings,
  customers as seedCustomers,
  inspections as seedInspections,
  invoices as seedInvoices,
  leads as seedLeads,
  quotes as seedQuotes,
  reviews as seedReviews,
  serviceAreas as seedServiceAreas,
  services as seedServices,
  staff as seedStaff,
} from "./mock-data";

// -------- Types --------
export type LeadStage = "New" | "Contacted" | "Quoted" | "Won" | "Lost";
export const LEAD_STAGES: LeadStage[] = ["New", "Contacted", "Quoted", "Won", "Lost"];

export interface ServiceOption {
  name: string;
  price: number;
}

export interface Service {
  id: string;
  name: string;
  basePrice: number;
  unit: string;
  color: string;
  tagline?: string;
  options?: ServiceOption[];
  addOns?: ServiceOption[];
}

export interface Customer {
  id: string;
  name: string;
  contact: string;
  email: string;
  phone: string;
  address?: string;
  city?: string;
  zip?: string;
  notes?: string;
  tags?: string;
  type: string;
  jobs: number;
  lifetime: number;
  since: string;
}

export interface Lead {
  id: string;
  name: string;
  contact: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  serviceInterest?: string;
  notes?: string;
  source: string;
  value: number;
  stage: LeadStage;
}

export type Permission =
  | "dashboard"
  | "customers"
  | "leads"
  | "bookings"
  | "invoices"
  | "quotes"
  | "contracts"
  | "services"
  | "inspections"
  | "email"
  | "automations"
  | "reports"
  | "activity"
  | "staff"
  | "settings";

export const ALL_PERMISSIONS: Permission[] = [
  "dashboard","customers","leads","bookings","invoices","quotes","contracts",
  "services","inspections","email","automations","reports","activity","staff","settings",
];

export interface Staff {
  id: string;
  name: string;
  role: string;
  jobs: number;
  rating: number;
  status: string;
  email: string;
  permissions?: Permission[];
}


export interface Booking {
  id: string;
  customer: string;
  email?: string;
  phone?: string;
  address?: string;
  service: string;
  date: string;
  time: string;
  assignee: string;
  status: string;
  price?: number;
  notes?: string;
  orderId?: string;
}

export type QuoteStatus = "Draft" | "Sent" | "Accepted" | "Declined";
export interface Quote {
  id: string;
  customer: string;
  service: string;
  amount: number;
  status: QuoteStatus;
  sentAt: string;
}

export type InvoiceStatus = "Draft" | "Pending Approval" | "Sent" | "Paid" | "Overdue";
export type RecurringFrequency = "weekly" | "biweekly" | "monthly" | "quarterly";
export interface InvoiceLineItem {
  description: string;
  qty: number;
  rate: number;
}
export interface Invoice {
  id: string;
  customer: string;
  email?: string;
  phone?: string;
  address?: string;
  service?: string;
  notes?: string;
  amount: number;
  issued: string;
  due: string;
  status: InvoiceStatus;
  items?: InvoiceLineItem[];
  taxRate?: number; // percentage, e.g. 8.25
  discount?: number; // flat currency
  recurring?: { frequency: RecurringFrequency; nextIssue: string; templateId?: string };
  parentId?: string;
}



export interface Inspection {
  id: string;
  job: string;
  inspector: string;
  score: number;
  status: "Passed" | "Needs rework";
}

export interface Review {
  id: string;
  customer: string;
  rating: number;
  text: string;
  date: string;
  reply?: string;
}

export interface ServiceArea {
  id: string;
  zip: string;
  city: string;
  surcharge: number;
}


export type CampaignStatus = "Draft" | "Scheduled" | "Sent";
export interface Campaign {
  id: string;
  name: string;
  subject: string;
  previewText?: string;
  fromName?: string;
  fromEmail?: string;
  audience: string;
  body: string;
  blocks?: unknown[];
  status: CampaignStatus;
  scheduledAt: string;
  recipients: number;
}

export interface AudienceContact {
  id: string;
  name: string;
  email: string;
  phone?: string;
  tags?: string;
}

export interface Audience {
  id: string;
  name: string;
  description: string;
  contacts: AudienceContact[];
}

export interface EmailTemplate {
  id: string;
  name: string;
  category: string;
  subject: string;
  body: string;
  blocks?: unknown[]; // EmailBlock[] — kept as unknown to avoid coupling to editor types
}

export type ContractStatus = "Draft" | "Sent" | "Signed" | "Expired";
export interface Contract {
  id: string;
  customer: string;
  customerEmail?: string;
  customerPhone?: string;
  customerAddress?: string;
  service: string;
  amount: number;
  startDate: string;
  endDate: string;
  status: ContractStatus;
  body?: string; // overrides the default template if set
  terms?: string;
  sentAt?: string;
  signedAt?: string;
}

interface StoreState {
  services: Service[];
  customers: Customer[];
  leads: Lead[];
  staff: Staff[];
  bookings: Booking[];
  quotes: Quote[];
  invoices: Invoice[];
  inspections: Inspection[];
  reviews: Review[];
  serviceAreas: ServiceArea[];
  campaigns: Campaign[];
  audiences: Audience[];
  templates: EmailTemplate[];
  contracts: Contract[];
}

type CollectionKey = keyof StoreState;

export interface EnsureCustomerInput {
  name: string;
  email?: string;
  phone?: string;
  address?: string;
  contact?: string;
  type?: string;
}

interface StoreContextValue extends StoreState {
  add: <K extends CollectionKey>(key: K, item: StoreState[K][number]) => void;
  update: <K extends CollectionKey>(
    key: K,
    id: string,
    patch: Partial<StoreState[K][number]>,
  ) => void;
  remove: (key: CollectionKey, id: string) => void;
  reset: () => void;
  /** Create the customer if none matches name/email, otherwise return the existing one. */
  ensureCustomer: (input: EnsureCustomerInput) => Customer;
}

interface BrandedTemplateOpts {
  preheader: string;
  eyebrow: string;
  heading: string;
  intro: string;
  bullets?: string[];
  highlight?: { label: string; value: string };
  ctaText: string;
  ctaUrl: string;
  signoff: string;
}

function brandedTemplate(o: BrandedTemplateOpts): string {
  const P = "#048BA8"; // primary
  const S = "#F8DD42"; // secondary
  const bg = "#E6F3F6";
  const ink = "#0F1F24";
  const muted = "#4a5b62";
  const bullets = o.bullets
    ? `<ul style="margin:0 0 24px 0;padding:0 0 0 20px;color:${muted};font-size:15px;line-height:1.7;">
        ${o.bullets
          .map(
            (b) =>
              `<li style="margin:0 0 8px 0;"><span style="color:${ink};">${b}</span></li>`,
          )
          .join("")}
      </ul>`
    : "";
  const highlight = o.highlight
    ? `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px 0;">
        <tr><td align="center" style="background:${S};border-radius:12px;padding:18px 20px;">
          <div style="font-family:Arial,Helvetica,sans-serif;font-size:11px;letter-spacing:2px;color:${ink};font-weight:700;">${o.highlight.label.toUpperCase()}</div>
          <div style="font-family:Georgia,'Times New Roman',serif;font-size:28px;color:${ink};font-weight:700;letter-spacing:3px;margin-top:6px;">${o.highlight.value}</div>
        </td></tr>
      </table>`
    : "";
  const signoff = o.signoff
    .split("\n")
    .map((l) => `<div>${l}</div>`)
    .join("");
  return `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${o.eyebrow}</title></head>
<body style="margin:0;padding:0;background:${bg};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
<span style="display:none;visibility:hidden;opacity:0;color:transparent;height:0;width:0;overflow:hidden;">${o.preheader}</span>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${bg};padding:32px 12px;">
<tr><td align="center">
  <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(4,139,168,0.08);">
    <tr><td style="background:${P};padding:20px 32px;" align="left">
      <img src="${typeof window !== 'undefined' ? window.location.origin : ''}/tsquare-logo.png" alt="T Square Solutions" height="44" style="display:block;height:44px;width:auto;border:0;outline:none;text-decoration:none;" />
    </td></tr>
    <tr><td style="padding:40px 40px 8px 40px;">
      <div style="font-size:11px;letter-spacing:3px;color:${P};font-weight:700;margin-bottom:12px;">${o.eyebrow}</div>
      <h1 style="margin:0 0 20px 0;font-family:Georgia,'Times New Roman',serif;font-size:28px;line-height:1.25;color:${ink};font-weight:700;">${o.heading}</h1>
      <p style="margin:0 0 24px 0;color:${muted};font-size:16px;line-height:1.65;">${o.intro}</p>
      ${bullets}
      ${highlight}
      <table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="border-radius:10px;background:${P};">
        <a href="${o.ctaUrl}" style="display:inline-block;padding:14px 28px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;color:#ffffff;text-decoration:none;border-radius:10px;">${o.ctaText}</a>
      </td></tr></table>
      <div style="margin:32px 0 0 0;padding-top:24px;border-top:1px solid #eef2f4;color:${muted};font-size:14px;line-height:1.6;">${signoff}</div>
    </td></tr>
    <tr><td style="background:#fafcfd;padding:20px 40px;color:#7a8b92;font-size:12px;line-height:1.5;" align="center">
      <div style="margin-bottom:6px;"><strong style="color:${ink};">T Square Solutions</strong> · Trusted cleaning services</div>
      <div>You're receiving this because you're a valued customer.</div>
    </td></tr>
  </table>
</td></tr></table>
</body></html>`;
}

const defaultState: StoreState = {
  services: seedServices as Service[],
  customers: seedCustomers as Customer[],
  leads: seedLeads.map((l) => ({ ...l })) as Lead[],
  staff: seedStaff as Staff[],
  bookings: seedBookings as Booking[],
  quotes: seedQuotes as Quote[],
  invoices: seedInvoices as Invoice[],
  inspections: seedInspections as Inspection[],
  reviews: seedReviews as Review[],
  serviceAreas: seedServiceAreas as ServiceArea[],
  contracts: [],
  campaigns: [
    {
      id: "cm_welcome",
      name: "Welcome new customers",
      subject: "Thanks for choosing T Square Solutions",
      audience: "All customers",
      body: "Hi there,\n\nThanks for booking with us. Here's what to expect on your first visit…",
      status: "Sent",
      scheduledAt: new Date().toISOString().slice(0, 10),
      recipients: 42,
    },
  ],
  audiences: [
    {
      id: "aud_all",
      name: "All customers",
      description: "Every customer in your CRM.",
      contacts: [],
    },
    {
      id: "aud_leads",
      name: "New leads",
      description: "Leads at the New stage.",
      contacts: [],
    },
  ],
  templates: [
    {
      id: "tpl_welcome",
      name: "Welcome email",
      category: "Onboarding",
      subject: "Welcome to T Square Solutions 👋",
      body: brandedTemplate({
        preheader: "A quick hello and what to expect from our team.",
        eyebrow: "WELCOME",
        heading: "Hi {{name}}, welcome to the family ✨",
        intro:
          "Thanks for choosing T Square Solutions. We can't wait to make your space sparkle. Here's a quick overview of what happens next so there are no surprises on your first visit.",
        bullets: [
          "Our team arrives on time, in uniform, with everything they need.",
          "We follow a 40+ point checklist so nothing gets missed.",
          "Not happy with something? We'll come back and re-clean — free.",
        ],
        ctaText: "View your dashboard",
        ctaUrl: "https://tsquaresulotionservices.com",
        signoff: "See you soon,\nThe T Square Solutions team",
      }),
    },
    {
      id: "tpl_promo",
      name: "Seasonal promo — 15% off",
      category: "Promotion",
      subject: "This week only: 15% off your next clean",
      body: brandedTemplate({
        preheader: "Save 15% on any service booked this week.",
        eyebrow: "LIMITED TIME",
        heading: "Hey {{name}} — enjoy 15% off ✨",
        intro:
          "Because you're a valued customer, this week only, take 15% off any deep clean, move-in / move-out, or recurring booking. Use the code below at checkout — it's yours.",
        highlight: { label: "Your code", value: "SPARKLE15" },
        ctaText: "Book with 15% off",
        ctaUrl: "https://tsquaresulotionservices.com",
        signoff: "Happy cleaning,\nThe T Square Solutions team",
      }),
    },
    {
      id: "tpl_review",
      name: "Post-service review request",
      category: "Reviews",
      subject: "How did we do, {{name}}?",
      body: brandedTemplate({
        preheader: "A 30-second review would mean the world to our team.",
        eyebrow: "THANK YOU",
        heading: "Thanks for having us over, {{name}} 🌟",
        intro:
          "We hope you're loving your fresh, clean space. If our team did a great job, would you mind sharing a quick review? It genuinely helps small businesses like ours grow.",
        bullets: [
          "Takes about 30 seconds.",
          "Even one line makes a huge difference.",
          "Not perfect? Reply to this email and we'll make it right.",
        ],
        ctaText: "Leave a review ⭐",
        ctaUrl: "https://g.page/tsquare",
        signoff: "With gratitude,\nThe T Square Solutions team",
      }),
    },
    {
      id: "tpl_reactivation",
      name: "Win-back — we miss you",
      category: "Retention",
      subject: "We miss you, {{name}} — here's 20% off",
      body: brandedTemplate({
        preheader: "It's been a while — come back and save 20%.",
        eyebrow: "WE MISS YOU",
        heading: "{{name}}, ready for a refresh? 💛",
        intro:
          "It's been a while since your last clean and we'd love to have you back. To make it easy, here's 20% off your next booking — no strings attached.",
        highlight: { label: "Welcome-back code", value: "MISSYOU20" },
        ctaText: "Rebook now",
        ctaUrl: "https://tsquaresulotionservices.com",
        signoff: "Talk soon,\nThe T Square Solutions team",
      }),
    },
    {
      id: "tpl_newsletter",
      name: "Monthly newsletter",
      category: "Newsletter",
      subject: "Your monthly clean-living tips ✨",
      body: brandedTemplate({
        preheader: "3 quick tips + what's new at T Square this month.",
        eyebrow: "NEWSLETTER",
        heading: "This month at T Square, {{name}}",
        intro:
          "Here's a short round-up of our favourite tips for keeping your home fresh between visits, plus a couple of updates from our team.",
        bullets: [
          "Tip 1 — Wipe down high-touch surfaces daily with a microfibre cloth.",
          "Tip 2 — Vacuum entryways twice a week to cut down on tracked-in dirt.",
          "Tip 3 — Change bed linens weekly for a hotel-quality sleep.",
        ],
        ctaText: "Read more on our blog",
        ctaUrl: "https://tsquaresulotionservices.com",
        signoff: "Until next month,\nThe T Square Solutions team",
      }),
    },
  ],
};

const StoreContext = createContext<StoreContextValue | undefined>(undefined);

const LOCAL_KEY = "tsquare_crm_state_v1";

export function DataStoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<StoreState>(defaultState);
  const [hydrated, setHydrated] = useState(false);

  // Load state: try server (/api/state) first, then localStorage fallback.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      let loaded: Partial<StoreState> | null = null;
      try {
        const res = await fetch("/api/state", { headers: { Accept: "application/json" } });
        if (res.ok) {
          const json = (await res.json()) as { data: Partial<StoreState> | null };
          if (json.data) loaded = json.data;
        }
      } catch {
        /* ignore */
      }
      if (!loaded && typeof window !== "undefined") {
        try {
          const raw = window.localStorage.getItem(LOCAL_KEY);
          if (raw) loaded = JSON.parse(raw) as Partial<StoreState>;
        } catch {
          /* ignore */
        }
      }
      if (!cancelled && loaded) setState({ ...defaultState, ...loaded });
      if (!cancelled) setHydrated(true);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Persist state: localStorage (debounced, idle) + best-effort server sync.
  useEffect(() => {
    if (!hydrated) return;
    const t = window.setTimeout(() => {
      const run = () => {
        let serialized: string;
        try {
          serialized = JSON.stringify(state);
        } catch {
          return;
        }
        try {
          window.localStorage.setItem(LOCAL_KEY, serialized);
        } catch {
          /* quota / private mode */
        }
        try {
          void fetch("/api/state", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: serialized,
            keepalive: true,
          }).catch(() => {});
        } catch {
          /* ignore */
        }
      };
      const ric = (window as unknown as { requestIdleCallback?: (cb: () => void) => number })
        .requestIdleCallback;
      if (ric) ric(run);
      else run();
    }, 1200);
    return () => window.clearTimeout(t);
  }, [state, hydrated]);

  // Poll WooCommerce webhook queue only when the tab is visible.
  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;
    let iv: number | null = null;

    const tick = async () => {
      if (document.visibilityState !== "visible") return;
      try {
        const res = await fetch("/api/wc-pending", { headers: { Accept: "application/json" } });
        if (!res.ok) return;
        const { items } = (await res.json()) as {
          items: Array<{
            id: string;
            orderId: string;
            customer: string;
            contact: string;
            email: string;
            phone: string;
            service: string;
            date: string;
            time: string;
            amount: number;
            status: string;
          }>;
        };
        if (cancelled || !items || items.length === 0) return;

        setState((prev) => {
          const existingOrders = new Set(
            prev.bookings.map((b) => b.orderId).filter(Boolean),
          );
          const newBookings: Booking[] = [];
          const newCustomers: Customer[] = [];
          for (const it of items) {
            if (it.orderId && existingOrders.has(it.orderId)) continue;
            newBookings.push({
              id: `b_wc_${it.orderId || it.id}`,
              customer: it.customer,
              email: it.email,
              phone: it.phone,
              service: it.service,
              date: it.date,
              time: it.time,
              assignee: "Unassigned",
              status: "Scheduled",
              orderId: it.orderId,
            });
            const alreadyCustomer = prev.customers.some(
              (c) =>
                (it.email && c.email && c.email.toLowerCase() === it.email.toLowerCase()) ||
                c.name.toLowerCase() === it.customer.toLowerCase(),
            );
            if (!alreadyCustomer) {
              newCustomers.push({
                id: `c_wc_${it.orderId || it.id}`,
                name: it.customer,
                contact: it.contact || it.customer,
                email: it.email,
                phone: it.phone,
                type: "Residential",
                jobs: 1,
                lifetime: it.amount,
                since: it.date,
              });
            }
          }
          if (newBookings.length === 0 && newCustomers.length === 0) return prev;
          return {
            ...prev,
            bookings: [...newBookings, ...prev.bookings],
            customers: [...newCustomers, ...prev.customers],
          };
        });

        void fetch("/api/wc-pending", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ consumed: items.map((i) => i.id) }),
        }).catch(() => {});
      } catch {
        /* ignore */
      }
    };

    const start = () => {
      if (iv != null) return;
      void tick();
      iv = window.setInterval(tick, 60000);
    };
    const stop = () => {
      if (iv != null) {
        window.clearInterval(iv);
        iv = null;
      }
    };
    const onVis = () => {
      if (document.visibilityState === "visible") start();
      else stop();
    };
    if (document.visibilityState === "visible") start();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      cancelled = true;
      stop();
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [hydrated]);



  // Recurring invoice generator — checks every hour, generates due invoices.
  useEffect(() => {
    if (!hydrated) return;
    const gen = () => {
      const today = new Date().toISOString().slice(0, 10);
      setState((prev) => {
        const toAdd: Invoice[] = [];
        const updatedInvoices = prev.invoices.map((inv) => {
          if (!inv.recurring) return inv;
          if (inv.recurring.nextIssue > today) return inv;
          // due — generate a child
          const days = { weekly: 7, biweekly: 14, monthly: 30, quarterly: 90 }[inv.recurring.frequency];
          const next = new Date(inv.recurring.nextIssue);
          next.setDate(next.getDate() + days);
          const nextStr = next.toISOString().slice(0, 10);
          const dueDate = new Date(); dueDate.setDate(dueDate.getDate() + 14);
          toAdd.push({
            ...inv,
            id: `INV-${Date.now().toString().slice(-6)}-${Math.random().toString(36).slice(2, 5)}`,
            issued: today,
            due: dueDate.toISOString().slice(0, 10),
            status: "Pending Approval",
            recurring: undefined,
            parentId: inv.id,
          });
          return { ...inv, recurring: { ...inv.recurring, nextIssue: nextStr } };
        });
        if (toAdd.length === 0) return prev;
        return { ...prev, invoices: [...toAdd, ...updatedInvoices] };
      });
    };
    gen();
    const iv = window.setInterval(gen, 60 * 60 * 1000);
    return () => window.clearInterval(iv);
  }, [hydrated]);

  const add: StoreContextValue["add"] = useCallback((key, item) => {

    setState((prev) => ({
      ...prev,
      [key]: [item, ...(prev[key] as unknown as Array<typeof item>)],
    }));
  }, []);

  const update: StoreContextValue["update"] = useCallback((key, id, patch) => {
    setState((prev) => ({
      ...prev,
      [key]: (prev[key] as unknown as Array<{ id: string }>).map((row) =>
        row.id === id ? { ...row, ...patch } : row,
      ),
    }));
  }, []);

  const remove: StoreContextValue["remove"] = useCallback((key, id) => {
    setState((prev) => ({
      ...prev,
      [key]: (prev[key] as unknown as Array<{ id: string }>).filter((row) => row.id !== id),
    }));
  }, []);

  const reset = useCallback(() => setState(defaultState), []);

  const ensureCustomer: StoreContextValue["ensureCustomer"] = useCallback((input) => {
    const nameKey = input.name.trim().toLowerCase();
    const emailKey = (input.email ?? "").trim().toLowerCase();
    let created: Customer | null = null;
    setState((prev) => {
      const existing = prev.customers.find(
        (c) =>
          (emailKey && c.email && c.email.toLowerCase() === emailKey) ||
          c.name.toLowerCase() === nameKey,
      );
      if (existing) {
        created = existing;
        // best-effort backfill of missing contact info
        const patch: Partial<Customer> = {};
        if (!existing.email && input.email) patch.email = input.email;
        if (!existing.phone && input.phone) patch.phone = input.phone;
        if (!existing.address && input.address) patch.address = input.address;
        if (!existing.contact && input.contact) patch.contact = input.contact;
        if (Object.keys(patch).length === 0) return prev;
        return {
          ...prev,
          customers: prev.customers.map((c) => (c.id === existing.id ? { ...c, ...patch } : c)),
        };
      }
      const fresh: Customer = {
        id: `c_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
        name: input.name.trim(),
        contact: input.contact ?? input.name.trim(),
        email: input.email ?? "",
        phone: input.phone ?? "",
        address: input.address ?? "",
        type: input.type ?? "Residential",
        jobs: 0,
        lifetime: 0,
        since: new Date().toISOString().slice(0, 10),
      };
      created = fresh;
      return { ...prev, customers: [fresh, ...prev.customers] };
    });
    // `created` is set synchronously inside the reducer.
    return created as unknown as Customer;
  }, []);

  const value = useMemo<StoreContextValue>(
    () => ({ ...state, add, update, remove, reset, ensureCustomer }),
    [state, add, update, remove, reset, ensureCustomer],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used inside <DataStoreProvider>");
  return ctx;
}

export function newId(prefix = "id") {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}
