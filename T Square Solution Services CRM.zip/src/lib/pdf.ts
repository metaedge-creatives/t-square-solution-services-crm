import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  type CompanyProfile,
  type DocTemplates,
  interpolate,
  buildVars,
  assembleContract,
} from "./company-profile";

const BRAND = "#048BA8";
const BRAND_DEEP = "#036A82";
const BRAND_SOFT = "#E6F3F6";
const INK = "#0F1F24";
const MUTED = "#4A5B62";
const ACCENT = "#F8DD42";

// Logo intrinsic aspect ~3.26:1 (transparent PNG). We keep that ratio in the PDF.
const LOGO_ASPECT = 3.26;

let logoDataUrlPromise: Promise<string | null> | null = null;
function loadLogoDataUrl(): Promise<string | null> {
  if (typeof window === "undefined") return Promise.resolve(null);
  if (!logoDataUrlPromise) {
    logoDataUrlPromise = fetch("/tsquare-logo.png")
      .then((r) => (r.ok ? r.blob() : Promise.reject()))
      .then(
        (blob) =>
          new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          }),
      )
      .catch(() => null);
  }
  return logoDataUrlPromise;
}
export function preloadLogo() {
  void loadLogoDataUrl();
}

function headerBlock(
  doc: jsPDF,
  company: CompanyProfile,
  label: string,
  logoDataUrl: string | null,
) {
  const pageW = doc.internal.pageSize.getWidth();
  const bandH = 96;

  // solid brand band
  doc.setFillColor(BRAND);
  doc.rect(0, 0, pageW, bandH, "F");

  // slim accent stripe at the bottom of the band
  doc.setFillColor(ACCENT);
  doc.rect(0, bandH, pageW, 3, "F");

  // logo — placed directly on brand color, aspect preserved (no card behind)
  const logoH = 44;
  const logoW = logoH * LOGO_ASPECT;
  const logoY = (bandH - logoH) / 2;
  if (logoDataUrl) {
    try {
      doc.addImage(logoDataUrl, "PNG", 36, logoY, logoW, logoH, undefined, "FAST");
    } catch {
      // ignore
    }
  }

  // company name + contact
  const textX = 36 + logoW + 18;
  doc.setTextColor("#ffffff");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text(company.name, textX, 42);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.text(
    [company.email, company.phone, company.website].filter(Boolean).join("  ·  "),
    textX,
    60,
  );

  // doc label on the right
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.text(label, pageW - 40, 52, { align: "right" });
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor("#E6F3F6");
  doc.text(new Date().toISOString().slice(0, 10), pageW - 40, 68, { align: "right" });
}


function footerBlock(doc: jsPDF, text: string) {
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  doc.setDrawColor("#E5E7EB");
  doc.line(40, pageH - 60, pageW - 40, pageH - 60);
  doc.setTextColor(MUTED);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  const wrapped = doc.splitTextToSize(text, pageW - 80);
  doc.text(wrapped, 40, pageH - 42);
}

function metaBlock(
  doc: jsPDF,
  rows: Array<[string, string]>,
  y = 130,
): number {
  const pageW = doc.internal.pageSize.getWidth();
  doc.setFillColor(BRAND_SOFT);
  doc.roundedRect(pageW - 240, y, 200, rows.length * 18 + 14, 6, 6, "F");
  doc.setTextColor(INK);
  doc.setFontSize(9);
  rows.forEach(([label, value], i) => {
    doc.setFont("helvetica", "bold");
    doc.text(label.toUpperCase(), pageW - 230, y + 20 + i * 18);
    doc.setFont("helvetica", "normal");
    doc.text(value, pageW - 50, y + 20 + i * 18, { align: "right" });
  });
  return y + rows.length * 18 + 14;
}

function billToBlock(
  doc: jsPDF,
  title: string,
  lines: string[],
  y = 130,
): number {
  doc.setTextColor(MUTED);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text(title.toUpperCase(), 40, y + 4);
  doc.setTextColor(INK);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  lines.filter(Boolean).forEach((line, i) => {
    doc.text(line, 40, y + 22 + i * 14);
  });
  return y + 22 + lines.length * 14;
}

// ---------- INVOICE ----------
export interface InvoicePdfInput {
  id: string;
  customer: string;
  customerEmail?: string;
  customerPhone?: string;
  customerAddress?: string;
  amount: number;
  issued: string;
  due: string;
  status: string;
  lineItems?: Array<{ description: string; qty: number; rate: number }>;
}

export async function renderInvoicePdf(
  input: InvoicePdfInput,
  company: CompanyProfile,
  docs: DocTemplates,
): Promise<jsPDF> {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const logo = await loadLogoDataUrl();
  headerBlock(doc, company, docs.invoiceHeader || "INVOICE", logo);

  const bottomOfBill = billToBlock(doc, "Bill To", [
    input.customer,
    input.customerEmail || "",
    input.customerPhone || "",
    ...(input.customerAddress ? input.customerAddress.split("\n") : []),
  ]);

  metaBlock(doc, [
    ["Invoice #", input.id],
    ["Issued", input.issued],
    ["Due", input.due],
    ["Status", input.status],
  ]);

  const items =
    input.lineItems && input.lineItems.length
      ? input.lineItems
      : [{ description: "Services rendered", qty: 1, rate: input.amount }];

  autoTable(doc, {
    startY: Math.max(bottomOfBill, 240),
    head: [["Description", "Qty", "Rate", "Amount"]],
    body: items.map((li) => [
      li.description,
      String(li.qty),
      `$${li.rate.toFixed(2)}`,
      `$${(li.qty * li.rate).toFixed(2)}`,
    ]),
    theme: "grid",
    headStyles: { fillColor: BRAND, textColor: "#ffffff", fontStyle: "bold" },
    bodyStyles: { textColor: INK },
    styles: { fontSize: 10, cellPadding: 8 },
    columnStyles: {
      1: { halign: "right", cellWidth: 60 },
      2: { halign: "right", cellWidth: 80 },
      3: { halign: "right", cellWidth: 90 },
    },
    margin: { left: 40, right: 40 },
  });

  const finalY =
    (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable
      .finalY + 16;
  const pageW = doc.internal.pageSize.getWidth();

  doc.setFillColor(BRAND);
  doc.roundedRect(pageW - 240, finalY, 200, 44, 6, 6, "F");
  doc.setTextColor("#ffffff");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("TOTAL DUE", pageW - 230, finalY + 20);
  doc.setFontSize(18);
  doc.text(`$${input.amount.toFixed(2)}`, pageW - 50, finalY + 32, {
    align: "right",
  });

  if (company.paymentInstructions) {
    doc.setTextColor(MUTED);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    const wrapped = doc.splitTextToSize(
      `Payment: ${company.paymentInstructions}`,
      pageW - 280,
    );
    doc.text(wrapped, 40, finalY + 24);
  }

  const footerText = interpolate(
    docs.invoiceFooter,
    buildVars(company, {
      invoice_id: input.id,
      customer_name: input.customer,
      amount: input.amount.toFixed(2),
      due_date: input.due,
    }),
  );
  footerBlock(doc, footerText);

  return doc;
}

// ---------- QUOTE ----------
export interface QuotePdfInput {
  id: string;
  customer: string;
  customerEmail?: string;
  service: string;
  amount: number;
  sentAt: string;
  status: string;
}

export async function renderQuotePdf(
  q: QuotePdfInput,
  company: CompanyProfile,
  docs: DocTemplates,
): Promise<jsPDF> {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const logo = await loadLogoDataUrl();
  headerBlock(doc, company, docs.quoteHeader || "QUOTE", logo);

  const bottom = billToBlock(doc, "Prepared For", [
    q.customer,
    q.customerEmail || "",
  ]);
  metaBlock(doc, [
    ["Quote #", q.id],
    ["Date", q.sentAt || new Date().toISOString().slice(0, 10)],
    ["Status", q.status],
  ]);

  autoTable(doc, {
    startY: Math.max(bottom, 240),
    head: [["Service", "Amount"]],
    body: [[q.service, `$${q.amount.toFixed(2)}`]],
    theme: "grid",
    headStyles: { fillColor: BRAND, textColor: "#ffffff", fontStyle: "bold" },
    styles: { fontSize: 11, cellPadding: 10 },
    columnStyles: { 1: { halign: "right", cellWidth: 120 } },
    margin: { left: 40, right: 40 },
  });

  const finalY =
    (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable
      .finalY + 16;
  const pageW = doc.internal.pageSize.getWidth();
  doc.setFillColor(BRAND);
  doc.roundedRect(pageW - 240, finalY, 200, 44, 6, 6, "F");
  doc.setTextColor("#ffffff");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("TOTAL", pageW - 230, finalY + 20);
  doc.setFontSize(18);
  doc.text(`$${q.amount.toFixed(2)}`, pageW - 50, finalY + 32, {
    align: "right",
  });

  const footerText = interpolate(
    docs.quoteFooter,
    buildVars(company, {
      quote_id: q.id,
      customer_name: q.customer,
      service: q.service,
      amount: q.amount.toFixed(2),
    }),
  );
  footerBlock(doc, footerText);
  return doc;
}

// ---------- CONTRACT ----------
export interface ContractPdfInput {
  id: string;
  customer: string;
  customerEmail?: string;
  customerPhone?: string;
  customerAddress?: string;
  service: string;
  amount: number;
  startDate: string;
  endDate: string;
  body?: string; // overrides docs.contractBody
}

export async function renderContractPdf(
  c: ContractPdfInput,
  company: CompanyProfile,
  docs: DocTemplates,
): Promise<jsPDF> {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const logo = await loadLogoDataUrl();
  headerBlock(doc, company, "CONTRACT", logo);

  const vars = buildVars(company, {
    contract_id: c.id,
    customer_name: c.customer,
    customer_email: c.customerEmail ?? "",
    customer_phone: c.customerPhone ?? "",
    customer_address: c.customerAddress ?? "",
    service: c.service,
    amount: c.amount.toFixed(2),
    start_date: c.startDate,
    end_date: c.endDate,
  });

  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const marginX = 48;
  const contentW = pageW - marginX * 2;
  let y = 120;

  const ensureSpace = (needed: number) => {
    if (y + needed > pageH - 80) {
      doc.addPage();
      headerBlock(doc, company, "CONTRACT (cont.)", logo);
      y = 120;
    }
  };

  const sectionLabel = (label: string) => {
    ensureSpace(28);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(BRAND_DEEP);
    doc.text(label.toUpperCase(), marginX, y);
    // underline
    doc.setDrawColor(BRAND);
    doc.setLineWidth(0.8);
    doc.line(marginX, y + 4, marginX + 40, y + 4);
    y += 16;
    doc.setTextColor(INK);
  };

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(INK);
  doc.text("Service Agreement", marginX, y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(MUTED);
  y += 18;
  doc.text(
    `This Service Agreement is entered into on ${vars.today} by and between the parties below.`,
    marginX,
    y,
    { maxWidth: contentW },
  );
  y += 26;

  // Parties: two columns
  const colW = (contentW - 16) / 2;
  const partyBoxH = 118;
  ensureSpace(partyBoxH + 20);

  const drawParty = (
    x: number,
    title: string,
    lines: string[],
  ) => {
    doc.setFillColor(BRAND_SOFT);
    doc.roundedRect(x, y, colW, partyBoxH, 8, 8, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(BRAND_DEEP);
    doc.text(title.toUpperCase(), x + 14, y + 18);
    doc.setTextColor(INK);
    doc.setFontSize(10);
    let ly = y + 34;
    lines.filter(Boolean).forEach((ln, i) => {
      doc.setFont("helvetica", i === 0 ? "bold" : "normal");
      const wrapped = doc.splitTextToSize(ln, colW - 28);
      doc.text(wrapped, x + 14, ly);
      ly += 14 * wrapped.length;
    });
  };

  drawParty(marginX, "Service Provider", [
    company.name,
    ...(company.address ? company.address.split("\n") : []),
    company.email,
    company.phone,
  ]);
  drawParty(marginX + colW + 16, "Client", [
    c.customer,
    ...(c.customerAddress ? c.customerAddress.split("\n") : []),
    c.customerEmail || "",
    c.customerPhone || "",
  ]);
  y += partyBoxH + 20;

  // Highlighted service / value / term card
  ensureSpace(74);
  doc.setFillColor(BRAND);
  doc.roundedRect(marginX, y, contentW, 62, 8, 8, "F");
  const cellW = contentW / 3;
  const cells: Array<[string, string]> = [
    ["SERVICE", c.service || "—"],
    ["CONTRACT VALUE", `$${c.amount.toFixed(2)}`],
    ["TERM", `${c.startDate} → ${c.endDate}`],
  ];
  cells.forEach(([label, value], i) => {
    const cx = marginX + cellW * i + 16;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor("#CFEEF3");
    doc.text(label, cx, y + 22);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor("#ffffff");
    const val = doc.splitTextToSize(value, cellW - 24);
    doc.text(val, cx, y + 42);
  });
  // accent divider stripe
  doc.setFillColor(ACCENT);
  doc.rect(marginX, y + 62, contentW, 3, "F");
  y += 62 + 3 + 22;
  doc.setTextColor(INK);

  // Agreement body
  const bodyText = interpolate(
    (c.body && c.body.trim().length > 0 ? c.body : docs.contractBody),
    vars,
  );
  sectionLabel("Agreement");
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  const bodyParas = bodyText.split(/\n\s*\n/);
  for (const para of bodyParas) {
    const wrapped = doc.splitTextToSize(para.trim(), contentW);
    ensureSpace(wrapped.length * 13 + 8);
    doc.text(wrapped, marginX, y);
    y += wrapped.length * 13 + 8;
  }

  // Terms
  const termsText = interpolate(docs.contractTerms, vars)
    // strip default signature block; we'll draw a nicer one
    .split(/\n\s*Signed:\s*\n/)[0]
    .trim();
  y += 6;
  sectionLabel("Terms & Conditions");
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  const termParas = termsText.split(/\n\s*\n/);
  for (const para of termParas) {
    const wrapped = doc.splitTextToSize(para.trim(), contentW);
    ensureSpace(wrapped.length * 13 + 8);
    doc.text(wrapped, marginX, y);
    y += wrapped.length * 13 + 8;
  }

  // Signature block
  y += 14;
  ensureSpace(90);
  sectionLabel("Signatures");
  const sigColW = (contentW - 24) / 2;
  const sigY = y + 30;
  doc.setDrawColor("#94A3B8");
  doc.setLineWidth(0.6);
  doc.line(marginX, sigY, marginX + sigColW, sigY);
  doc.line(marginX + sigColW + 24, sigY, marginX + contentW, sigY);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(INK);
  doc.text(company.name, marginX, sigY + 14);
  doc.text(c.customer, marginX + sigColW + 24, sigY + 14);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(MUTED);
  doc.text(`Date: ${vars.today}`, marginX, sigY + 28);
  doc.text("Date: ______________", marginX + sigColW + 24, sigY + 28);
  y = sigY + 44;

  footerBlock(
    doc,
    `Contract ${c.id} · Generated ${vars.today} · ${company.name} · ${company.email}`,
  );
  return doc;
}
// keep assembleContract import used elsewhere
void assembleContract;

// ---------- helpers ----------
export function downloadPdf(doc: jsPDF, filename: string) {
  doc.save(filename);
}

/** Open the user's mail client pre-filled. PDF is downloaded separately for attaching. */
export function openMailto(
  to: string,
  subject: string,
  body: string,
): void {
  const url = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(
    subject,
  )}&body=${encodeURIComponent(body)}`;
  window.location.href = url;
}
