// Pending WooCommerce bookings queue.
// Uses MariaDB (app_state row id=wc_pending) when DB is configured; falls back
// to in-memory storage for the preview sandbox.

export interface PendingBooking {
  id: string;
  orderId: string;
  customer: string;
  contact: string;
  email: string;
  phone: string;
  service: string;
  date: string;
  time: string;
  amount: number;
  status: string;
  createdAt: number;
}

const memory: PendingBooking[] = [];

const dbConfigured = () => Boolean(process.env.DB_HOST && process.env.DB_NAME);

async function readDb(): Promise<PendingBooking[] | null> {
  if (!dbConfigured()) return null;
  try {
    const { getPool, ensureSchema } = await import("@/lib/db.server");
    await ensureSchema();
    const pool = getPool();
    const [rows] = (await pool.query(
      "SELECT data FROM app_state WHERE id = ? LIMIT 1",
      ["wc_pending"],
    )) as unknown as [Array<{ data: string }>, unknown];
    if (!rows || rows.length === 0) return [];
    try {
      return JSON.parse(rows[0].data) as PendingBooking[];
    } catch {
      return [];
    }
  } catch (err) {
    console.error("wc-store read failed:", err);
    return null;
  }
}

async function writeDb(list: PendingBooking[]) {
  if (!dbConfigured()) return;
  try {
    const { getPool, ensureSchema } = await import("@/lib/db.server");
    await ensureSchema();
    const pool = getPool();
    await pool.query(
      `INSERT INTO app_state (id, data) VALUES (?, ?)
       ON DUPLICATE KEY UPDATE data = VALUES(data)`,
      ["wc_pending", JSON.stringify(list)],
    );
  } catch (err) {
    console.error("wc-store write failed:", err);
  }
}

export async function pushPending(item: PendingBooking) {
  const existing = (await readDb()) ?? memory.slice();
  existing.push(item);
  if (dbConfigured()) await writeDb(existing);
  else memory.push(item);
}

export async function listPending(): Promise<PendingBooking[]> {
  const dbList = await readDb();
  return dbList ?? memory.slice();
}

export async function consumePending(ids: string[]) {
  const set = new Set(ids);
  if (dbConfigured()) {
    const existing = (await readDb()) ?? [];
    await writeDb(existing.filter((p) => !set.has(p.id)));
  } else {
    for (let i = memory.length - 1; i >= 0; i--) {
      if (set.has(memory[i].id)) memory.splice(i, 1);
    }
  }
}
