/**
 * Frontend-only invite / password-reset tokens.
 * Tokens live in localStorage next to the user list. When a teammate opens
 * the emailed link they land on /setup-password/:token which lets them set
 * (or reset) their password without knowing the old one.
 */

export type InviteKind = "invite" | "reset";

export interface InviteToken {
  token: string;
  userId: string;
  email: string;
  kind: InviteKind;
  createdAt: number;
  expiresAt: number;
  usedAt?: number;
}

const KEY = "tsquare_crm_invites_v1";
const TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function read(): InviteToken[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as InviteToken[]) : [];
  } catch {
    return [];
  }
}

function write(list: InviteToken[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(KEY, JSON.stringify(list));
}

function randomToken() {
  const bytes = new Uint8Array(24);
  (globalThis.crypto ?? window.crypto).getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

export function createInvite(input: { userId: string; email: string; kind: InviteKind }): InviteToken {
  const now = Date.now();
  const invite: InviteToken = {
    token: randomToken(),
    userId: input.userId,
    email: input.email.trim().toLowerCase(),
    kind: input.kind,
    createdAt: now,
    expiresAt: now + TTL_MS,
  };
  // prune expired + previous unused of same kind for this user
  const kept = read().filter(
    (i) => i.expiresAt > now && !(i.userId === input.userId && i.kind === input.kind && !i.usedAt),
  );
  write([...kept, invite]);
  return invite;
}

export function findInvite(token: string): InviteToken | null {
  const now = Date.now();
  const inv = read().find((i) => i.token === token);
  if (!inv) return null;
  if (inv.usedAt) return null;
  if (inv.expiresAt < now) return null;
  return inv;
}

export function getPendingInvite(userId: string, kind: InviteKind = "invite"): InviteToken | null {
  const now = Date.now();
  return (
    read().find(
      (i) => i.userId === userId && i.kind === kind && !i.usedAt && i.expiresAt > now,
    ) ?? null
  );
}

export type InviteStatus = "none" | "pending" | "used" | "expired";

export interface InviteState {
  status: InviteStatus;
  sentAt?: number;
  usedAt?: number;
  expiresAt?: number;
}

export function getInviteState(userId: string, kind: InviteKind = "invite"): InviteState {
  const now = Date.now();
  const mine = read()
    .filter((i) => i.userId === userId && i.kind === kind)
    .sort((a, b) => b.createdAt - a.createdAt);
  if (mine.length === 0) return { status: "none" };
  const latest = mine[0];
  const base = { sentAt: latest.createdAt, usedAt: latest.usedAt, expiresAt: latest.expiresAt };
  if (latest.usedAt) return { status: "used", ...base };
  if (latest.expiresAt < now) return { status: "expired", ...base };
  return { status: "pending", ...base };
}


export function markInviteUsed(token: string) {
  const list = read();
  const next = list.map((i) => (i.token === token ? { ...i, usedAt: Date.now() } : i));
  write(next);
}

export function inviteUrl(token: string): string {
  const base = typeof window !== "undefined" ? window.location.origin : "";
  return `${base}/setup-password/${token}`;
}
