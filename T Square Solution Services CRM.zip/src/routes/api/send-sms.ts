import { createFileRoute } from "@tanstack/react-router";

interface Body {
  provider: "twilio" | "gatewayapi";
  from: string;
  creds: Record<string, string>;
  to: string;
  text: string;
}

function normalize(to: string) {
  const t = to.trim().replace(/[^\d+]/g, "");
  return t.startsWith("+") ? t : `+${t}`;
}

export const Route = createFileRoute("/api/send-sms")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: Body;
        try { body = (await request.json()) as Body; }
        catch { return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 }); }

        if (!body?.provider || !body.to || !body.text) {
          return Response.json({ ok: false, error: "Missing provider/to/text" }, { status: 400 });
        }
        const to = normalize(body.to);

        try {
          if (body.provider === "twilio") {
            const sid = body.creds.accountSid;
            const token = body.creds.authToken;
            if (!sid || !token) return Response.json({ ok: false, error: "Twilio credentials missing" }, { status: 400 });
            const form = new URLSearchParams({ To: to, From: body.from, Body: body.text });
            const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
              method: "POST",
              headers: {
                Authorization: `Basic ${btoa(`${sid}:${token}`)}`,
                "Content-Type": "application/x-www-form-urlencoded",
              },
              body: form,
            });
            const json = await res.json().catch(() => ({}));
            if (!res.ok) return Response.json({ ok: false, error: (json as { message?: string }).message ?? `Twilio ${res.status}` }, { status: res.status });
            return Response.json({ ok: true, id: (json as { sid?: string }).sid });
          }

          if (body.provider === "gatewayapi") {
            const apiToken = body.creds.apiToken;
            if (!apiToken) return Response.json({ ok: false, error: "GatewayAPI token missing" }, { status: 400 });
            const recipient = Number(to.replace(/[^\d]/g, ""));
            const res = await fetch("https://gatewayapi.com/rest/mtsms", {
              method: "POST",
              headers: { Authorization: `Token ${apiToken}`, "Content-Type": "application/json" },
              body: JSON.stringify({ sender: body.from || "CRM", message: body.text, recipients: [{ msisdn: recipient }] }),
            });
            const json = await res.json().catch(() => ({}));
            if (!res.ok) return Response.json({ ok: false, error: (json as { message?: string }).message ?? `GatewayAPI ${res.status}` }, { status: res.status });
            return Response.json({ ok: true, id: JSON.stringify(json).slice(0, 200) });
          }

          return Response.json({ ok: false, error: "Unknown provider" }, { status: 400 });
        } catch (err) {
          return Response.json({ ok: false, error: err instanceof Error ? err.message : String(err) }, { status: 500 });
        }
      },
    },
  },
});
