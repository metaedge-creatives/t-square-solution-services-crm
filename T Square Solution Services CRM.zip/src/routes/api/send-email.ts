import { createFileRoute } from "@tanstack/react-router";

interface SendMessage {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  replyTo?: string;
}

interface SendBody {
  provider: string;
  creds: Record<string, string>;
  message: SendMessage;
}

const toArray = (t: string | string[]) => (Array.isArray(t) ? t : [t]).filter(Boolean);
const htmlToText = (h: string) => h.replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();

async function sendBrevo(creds: any, m: SendMessage) {
  const res = await fetch("https://api.brevo.com/v3/smtp/email", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "api-key": creds.apiKey,
      accept: "application/json",
    },
    body: JSON.stringify({
      sender: { name: creds.fromName, email: creds.fromEmail },
      to: toArray(m.to).map((email) => ({ email })),
      subject: m.subject,
      htmlContent: m.html,
      textContent: m.text ?? htmlToText(m.html),
      replyTo: m.replyTo ? { email: m.replyTo } : undefined,
    }),
  });
  if (!res.ok) throw new Error(`Brevo ${res.status}: ${await res.text()}`);
}

async function sendResend(creds: any, m: SendMessage) {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${creds.apiKey}`,
    },
    body: JSON.stringify({
      from: `${creds.fromName} <${creds.fromEmail}>`,
      to: toArray(m.to),
      subject: m.subject,
      html: m.html,
      text: m.text,
      reply_to: m.replyTo,
    }),
  });
  if (!res.ok) throw new Error(`Resend ${res.status}: ${await res.text()}`);
}

async function sendSendgrid(creds: any, m: SendMessage) {
  const res = await fetch("https://api.sendgrid.com/v3/mail/send", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${creds.apiKey}`,
    },
    body: JSON.stringify({
      personalizations: [{ to: toArray(m.to).map((email) => ({ email })) }],
      from: { email: creds.fromEmail, name: creds.fromName },
      reply_to: m.replyTo ? { email: m.replyTo } : undefined,
      subject: m.subject,
      content: [
        { type: "text/plain", value: m.text ?? htmlToText(m.html) },
        { type: "text/html", value: m.html },
      ],
    }),
  });
  if (!res.ok && res.status !== 202)
    throw new Error(`SendGrid ${res.status}: ${await res.text()}`);
}

async function sendMailgun(creds: any, m: SendMessage) {
  const base = creds.region === "eu" ? "https://api.eu.mailgun.net" : "https://api.mailgun.net";
  const form = new URLSearchParams();
  form.set("from", `${creds.fromName} <${creds.fromEmail}>`);
  for (const t of toArray(m.to)) form.append("to", t);
  form.set("subject", m.subject);
  form.set("html", m.html);
  if (m.text) form.set("text", m.text);
  if (m.replyTo) form.set("h:Reply-To", m.replyTo);
  const res = await fetch(`${base}/v3/${creds.domain}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`api:${creds.apiKey}`)}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: form.toString(),
  });
  if (!res.ok) throw new Error(`Mailgun ${res.status}: ${await res.text()}`);
}

async function sendMailchimp(creds: any, m: SendMessage) {
  // Mailchimp Transactional (Mandrill) — the marketing API can't send arbitrary transactional email.
  const res = await fetch("https://mandrillapp.com/api/1.0/messages/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      key: creds.apiKey,
      message: {
        html: m.html,
        text: m.text ?? htmlToText(m.html),
        subject: m.subject,
        from_email: creds.fromEmail,
        from_name: creds.fromName,
        to: toArray(m.to).map((email) => ({ email, type: "to" })),
        headers: m.replyTo ? { "Reply-To": m.replyTo } : undefined,
      },
    }),
  });
  if (!res.ok) throw new Error(`Mailchimp ${res.status}: ${await res.text()}`);
}

export const Route = createFileRoute("/api/send-email")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: SendBody;
        try {
          body = (await request.json()) as SendBody;
        } catch {
          return Response.json({ ok: false, error: "Invalid JSON" }, { status: 400 });
        }
        const { provider, creds, message } = body;
        if (!provider || !creds || !message?.to || !message?.subject) {
          return Response.json(
            { ok: false, error: "provider, creds, message.to and message.subject required" },
            { status: 400 },
          );
        }
        const recipients = toArray(message.to);
        const errors: string[] = [];
        let sent = 0;
        for (const to of recipients) {
          try {
            const single = { ...message, to };
            switch (provider) {
              case "brevo": await sendBrevo(creds, single); break;
              case "resend": await sendResend(creds, single); break;
              case "sendgrid": await sendSendgrid(creds, single); break;
              case "mailgun": await sendMailgun(creds, single); break;
              case "mailchimp": await sendMailchimp(creds, single); break;
              default:
                errors.push(`Unknown provider: ${provider}`);
                continue;
            }
            sent++;
          } catch (err) {
            errors.push(String(err));
          }
        }
        return Response.json({
          ok: errors.length === 0,
          provider,
          sent,
          failed: recipients.length - sent,
          errors: errors.length ? errors : undefined,
        });
      },
    },
  },
});
