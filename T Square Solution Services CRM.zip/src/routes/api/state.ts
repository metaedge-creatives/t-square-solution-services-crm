import { createFileRoute } from "@tanstack/react-router";

// MariaDB persistence is only configured on the self-hosted deployment
// (CloudPanel). In the preview sandbox there is no DB, so we
// respond with graceful no-ops instead of throwing 500s.
const dbConfigured = () => Boolean(process.env.DB_HOST && process.env.DB_NAME);

export const Route = createFileRoute("/api/state")({
  server: {
    handlers: {
      GET: async () => {
        if (!dbConfigured()) return Response.json({ data: null });
        try {
          const { getPool, ensureSchema } = await import("@/lib/db.server");
          await ensureSchema();
          const pool = getPool();
          const [rows] = (await pool.query(
            "SELECT data FROM app_state WHERE id = ? LIMIT 1",
            ["default"],
          )) as unknown as [Array<{ data: string }>, unknown];
          if (!rows || rows.length === 0) return Response.json({ data: null });
          try {
            return Response.json({ data: JSON.parse(rows[0].data) });
          } catch {
            return Response.json({ data: null });
          }
        } catch (err) {
          console.error("GET /api/state failed:", err);
          return Response.json({ data: null });
        }
      },
      PUT: async ({ request }) => {
        if (!dbConfigured()) return Response.json({ ok: true, persisted: false });
        try {
          const { getPool, ensureSchema } = await import("@/lib/db.server");
          await ensureSchema();
          const body = await request.text();
          const pool = getPool();
          await pool.query(
            `INSERT INTO app_state (id, data) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE data = VALUES(data)`,
            ["default", body],
          );
          return Response.json({ ok: true });
        } catch (err) {
          console.error("PUT /api/state failed:", err);
          return Response.json({ ok: true, persisted: false });
        }
      },
    },
  },
});
