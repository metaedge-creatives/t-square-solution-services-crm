import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { pushPending } from "@/lib/wc-store.server";

export const Route = createFileRoute("/api/public/woocommerce")({
  server: {
    handlers: {
      OPTIONS: async () =>
        new Response(null, {
          status: 204,
          headers: {
            "access-control-allow-origin": "*",
            "access-control-allow-methods": "POST, OPTIONS",
            "access-control-allow-headers": "content-type, x-wc-webhook-signature, x-wc-webhook-topic, x-wc-webhook-event, x-wc-webhook-source",
          },
        }),

      POST: async ({ request }) => {
        const raw = await request.text();
        const secret = process.env.WC_WEBHOOK_SECRET;

        if (secret) {
          const sig = request.headers.get("x-wc-webhook-signature") || "";
          const expected = createHmac("sha256", secret).update(raw).digest("base64");
          try {
            const a = Buffer.from(sig);
            const b = Buffer.from(expected);
            if (a.length !== b.length || !timingSafeEqual(a, b)) {
              return new Response("Invalid signature", { status: 401 });
            }
          } catch {
            return new Response("Invalid signature", { status: 401 });
          }
        }

        let order: Record<string, unknown> = {};
        try {
          order = JSON.parse(raw);
        } catch {
          return new Response("Invalid JSON", { status: 400 });
        }

        const billing = (order.billing as Record<string, string>) || {};
        const first = billing.first_name || "";
        const last = billing.last_name || "";
        const items = (order.line_items as Array<{ name: string; quantity?: number }>) || [];
        const serviceName = items.map((i) => i.name).join(", ") || "WooCommerce order";
        const dateIso = String(order.date_created || new Date().toISOString());
        const dateOnly = dateIso.slice(0, 10);
        const timeOnly = /T(\d{2}:\d{2})/.exec(dateIso)?.[1] || "09:00";

        await pushPending({
          id: `wc_${order.id ?? Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          orderId: String(order.id ?? ""),
          customer: `${first} ${last}`.trim() || (billing.email as string) || "WooCommerce customer",
          contact: `${first} ${last}`.trim(),
          email: (billing.email as string) || "",
          phone: (billing.phone as string) || "",
          service: serviceName,
          date: dateOnly,
          time: timeOnly,
          amount: Number(order.total) || 0,
          status: String(order.status || "processing"),
          createdAt: Date.now(),
        });

        return Response.json(
          { ok: true },
          { headers: { "access-control-allow-origin": "*" } },
        );
      },
    },
  },
});
