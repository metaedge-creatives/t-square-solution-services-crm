import { createFileRoute } from "@tanstack/react-router";
import { consumePending, listPending } from "@/lib/wc-store.server";

export const Route = createFileRoute("/api/wc-pending")({
  server: {
    handlers: {
      GET: async () => {
        const items = await listPending();
        return Response.json({ items });
      },
      POST: async ({ request }) => {
        try {
          const body = (await request.json()) as { consumed?: string[] };
          if (Array.isArray(body.consumed) && body.consumed.length > 0) {
            await consumePending(body.consumed);
          }
        } catch {
          /* ignore */
        }
        return Response.json({ ok: true });
      },
    },
  },
});
