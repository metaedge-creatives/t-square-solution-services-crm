import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Loader2, ShieldCheck } from "lucide-react";

import { BrandLogo } from "@/components/brand-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/lib/auth";
import { findInvite, markInviteUsed, type InviteToken } from "@/lib/invites";

export const Route = createFileRoute("/setup-password/$token")({
  ssr: false,
  component: SetupPasswordPage,
});

function SetupPasswordPage() {
  const { token } = Route.useParams();
  const { updateUser, login } = useAuth();
  const navigate = useNavigate();
  const [invite, setInvite] = useState<InviteToken | null | undefined>(undefined);
  const [pw1, setPw1] = useState("");
  const [pw2, setPw2] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setInvite(findInvite(token));
  }, [token]);

  const heading = useMemo(
    () => (invite?.kind === "reset" ? "Reset your password" : "Set up your account"),
    [invite],
  );

  if (invite === undefined) {
    return <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">Loading…</div>;
  }

  if (invite === null) {
    return (
      <div className="grid min-h-screen place-items-center px-6">
        <div className="max-w-sm text-center">
          <BrandLogo className="justify-center" />
          <h1 className="mt-6 font-display text-2xl font-bold">Link no longer valid</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            This invite or reset link has expired or already been used. Ask an admin to send you a new one.
          </p>
          <Button className="mt-6" onClick={() => navigate({ to: "/login" })}>Back to sign in</Button>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw1.length < 8) return toast.error("Use at least 8 characters.");
    if (pw1 !== pw2) return toast.error("Passwords don't match.");
    setSubmitting(true);
    try {
      updateUser(invite.userId, { password: pw1 });
      markInviteUsed(invite.token);
      try {
        await login(invite.email, pw1);
        toast.success("Password saved — you're signed in");
        navigate({ to: "/dashboard", replace: true });
      } catch {
        toast.success("Password saved — please sign in");
        navigate({ to: "/login", replace: true });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to save password.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="grid min-h-screen place-items-center bg-muted/30 px-6">
      <div className="w-full max-w-md rounded-2xl border bg-background p-8 shadow-sm">
        <BrandLogo />
        <div className="mt-6 flex items-center gap-2 text-xs text-primary">
          <ShieldCheck className="h-4 w-4" /> Secure setup link
        </div>
        <h1 className="mt-2 font-display text-2xl font-bold">{heading}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          For <span className="font-medium text-foreground">{invite.email}</span>. Choose a password you'll remember.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="pw1">New password</Label>
            <Input id="pw1" type="password" value={pw1} onChange={(e) => setPw1(e.target.value)} autoComplete="new-password" placeholder="At least 8 characters" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pw2">Confirm password</Label>
            <Input id="pw2" type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} autoComplete="new-password" />
          </div>
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving…</> : "Save password"}
          </Button>
        </form>
      </div>
    </div>
  );
}
