import { createFileRoute, useParams, Navigate } from "@tanstack/react-router";
import { BookingForm } from "@/components/booking-form";
import { useStore } from "@/lib/data-store";

export const Route = createFileRoute("/_authenticated/bookings/$id/edit")({
  component: EditBookingPage,
});

function EditBookingPage() {
  const { id } = useParams({ from: "/_authenticated/bookings/$id/edit" });
  const { bookings } = useStore();
  const booking = bookings.find((b) => b.id === id);
  if (!booking) return <Navigate to="/bookings" />;
  return <BookingForm editing={booking} />;
}
