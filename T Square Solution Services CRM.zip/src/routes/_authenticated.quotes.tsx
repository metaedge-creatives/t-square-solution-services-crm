import { createFileRoute } from "@tanstack/react-router";
import { Plus, Send, Trash2, Pencil, Download, Mail } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { useStore, type Quote, type QuoteStatus } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";
import { useCompanyProfile, useDocTemplates, interpolate, buildVars } from "@/lib/company-profile";
import { renderQuotePdf, openMailto } from "@/lib/pdf";

export const Route = createFileRoute("/_authenticated/quotes")({
  component: QuotesPage,
});

const STATUSES: QuoteStatus[] = ["Draft", "Sent", "Accepted", "Declined"];
const emptyForm = { customer: "", service: "", amount: 0, status: "Draft" as QuoteStatus, sentAt: "" };

const toneFor = (status: string) => {
  switch (status) {
    case "Accepted": return "bg-success/20 text-success-foreground";
    case "Declined": return "bg-destructive/15 text-destructive";
    case "Draft": return "bg-muted text-muted-foreground";
    default: return "bg-secondary/40 text-secondary-foreground";
  }
};

function nextQuoteId(existing: Quote[]) {
  const nums = existing.map((q) => Number(q.id.replace(/\D/g, ""))).filter(Boolean);
  const next = (nums.length ? Math.max(...nums) : 1040) + 1;
  return `Q-${next}`;
}

function QuotesPage() {
  const { quotes, customers, services, add, update, remove } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const dlg = useDialogState<Quote>();
  const [form, setForm] = useState(emptyForm);

  const findCustomer = (name: string) => customers.find((c) => c.name === name);

  const downloadPdf = async (q: Quote) => {
    const c = findCustomer(q.customer);
    const doc = await renderQuotePdf(
      { id: q.id, customer: q.customer, customerEmail: c?.email, service: q.service, amount: q.amount, sentAt: q.sentAt === "—" ? "" : q.sentAt, status: q.status },
      company,
      docs,
    );
    doc.save(`${q.id}-${q.customer.replace(/\s+/g, "-")}.pdf`);
    toast.success("PDF downloaded");
  };

  const emailQuote = (q: Quote) => {
    const c = findCustomer(q.customer);
    if (!c?.email) return toast.error("Customer has no email on file");
    downloadPdf(q);
    const vars = buildVars(company, { quote_id: q.id, customer_name: q.customer, service: q.service, amount: q.amount.toFixed(2) });
    openMailto(c.email, interpolate(docs.quoteEmailSubject, vars), interpolate(docs.quoteEmailBody, vars));
    update("quotes", q.id, { status: "Sent", sentAt: new Date().toISOString().slice(0, 10) });
    toast.success("Email drafted — attach the PDF that just downloaded");
  };

  const totals = {
    sent: quotes.filter((q) => q.status === "Sent").length,
    accepted: quotes.filter((q) => q.status === "Accepted").length,
    value: quotes.reduce((sum, q) => sum + q.amount, 0),
  };

  const openNew = () => {
    setForm({ ...emptyForm, customer: customers[0]?.name ?? "", service: services[0]?.name ?? "" });
    dlg.openCreate();
  };
  const openEdit = (q: Quote) => {
    setForm({ customer: q.customer, service: q.service, amount: q.amount, status: q.status, sentAt: q.sentAt === "—" ? "" : q.sentAt });
    dlg.openEdit(q);
  };
  const submit = () => {
    if (!form.customer.trim()) return toast.error("Customer is required");
    const payload = { ...form, sentAt: form.sentAt || (form.status === "Draft" ? "—" : new Date().toISOString().slice(0, 10)) };
    if (dlg.editing) {
      update("quotes", dlg.editing.id, payload);
      toast.success("Quote updated");
    } else {
      add("quotes", { id: nextQuoteId(quotes), ...payload });
      toast.success("Quote created");
    }
    dlg.close();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Quotes"
        description="Build, send and track proposals across every service line."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => { downloadCsv("quotes", quotes); toast.success("Exported quotes"); }}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> New quote
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Awaiting response" value={totals.sent} />
        <StatCard label="Accepted" value={totals.accepted} accent />
        <StatCard label="Pipeline value" value={`$${totals.value.toLocaleString()}`} />
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Quote #</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Sent</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-28 text-right" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {quotes.map((q) => (
                <TableRow key={q.id}>
                  <TableCell className="font-medium">{q.id}</TableCell>
                  <TableCell>{q.customer}</TableCell>
                  <TableCell className="text-muted-foreground">{q.service}</TableCell>
                  <TableCell className="text-muted-foreground">{q.sentAt}</TableCell>
                  <TableCell className="text-right font-display font-semibold">${q.amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Select value={q.status} onValueChange={(v) => update("quotes", q.id, { status: v as QuoteStatus })}>
                      <SelectTrigger className="h-8 w-32">
                        <Badge variant="secondary" className={toneFor(q.status)}>{q.status}</Badge>
                      </SelectTrigger>
                      <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" title="Download PDF" onClick={() => downloadPdf(q)}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" title="Email to customer" onClick={() => emailQuote(q)}>
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => {
                      update("quotes", q.id, { status: "Sent", sentAt: new Date().toISOString().slice(0, 10) });
                      toast.success("Marked as sent");
                    }} title="Mark sent">
                      <Send className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => openEdit(q)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => { remove("quotes", q.id); toast.success("Removed"); }}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {quotes.length === 0 && (
                <TableRow><TableCell colSpan={7} className="py-8 text-center text-sm text-muted-foreground">No quotes yet.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit quote" : "New quote"}
        onSubmit={submit}
      >
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Customer</Label>
            <Input value={form.customer} onChange={(e) => setForm({ ...form, customer: e.target.value })} />
          </div>
          <div>
            <Label>Service</Label>
            <Select value={form.service || services[0]?.name} onValueChange={(v) => setForm({ ...form, service: v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{services.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Amount ($)</Label>
            <Input type="number" min={0} value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) || 0 })} />
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as QuoteStatus })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </EntityDialog>
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string | number; accent?: boolean }) {
  return (
    <Card className={accent ? "border-secondary bg-secondary/20" : ""}>
      <CardContent className="p-5">
        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="mt-2 font-display text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}
