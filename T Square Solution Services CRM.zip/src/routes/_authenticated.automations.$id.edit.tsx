import { createFileRoute, useParams } from "@tanstack/react-router";
import { AutomationForm } from "@/components/automation-form";

export const Route = createFileRoute("/_authenticated/automations/$id/edit")({
  component: EditAutomationPage,
});

function EditAutomationPage() {
  const { id } = useParams({ from: "/_authenticated/automations/$id/edit" });
  return <AutomationForm editingId={id} />;
}
