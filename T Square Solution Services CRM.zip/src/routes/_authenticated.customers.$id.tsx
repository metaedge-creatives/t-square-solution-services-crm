import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Mail, Phone, MapPin, Calendar, FileText, Save, Trash2, X, Pencil } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, type Customer } from "@/lib/data-store";

export const Route = createFileRoute("/_authenticated/customers/$id")({
  component: CustomerDetail,
});

const TYPES = ["Commercial", "Residential", "Airbnb", "Office"];

function CustomerDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { customers, bookings, invoices, contracts, quotes, update, remove } = useStore();

  const customer = useMemo(() => customers.find((c) => c.id === id), [customers, id]);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState<Customer | null>(customer ?? null);

  useEffect(() => { setForm(customer ?? null); }, [customer]);

  const custBookings = useMemo(() => (customer ? bookings.filter((b) => b.customer === customer.name) : []), [bookings, customer]);
  const custInvoices = useMemo(() => (customer ? invoices.filter((i) => i.customer === customer.name) : []), [invoices, customer]);
  const custContracts = useMemo(() => (customer ? contracts.filter((c) => c.customer === customer.name) : []), [contracts, customer]);
  const custQuotes = useMemo(() => (customer ? quotes.filter((q) => q.customer === customer.name) : []), [quotes, customer]);

  if (!customer || !form) {
    return (
      <div className="space-y-4">
        <Button asChild variant="ghost" size="sm"><Link to="/customers"><ArrowLeft className="mr-2 h-4 w-4" /> Back</Link></Button>
        <Card><CardContent className="p-10 text-center text-muted-foreground">Customer not found.</CardContent></Card>
      </div>
    );
  }

  const totalPaid = custInvoices.filter((i) => i.status === "Paid").reduce((s, i) => s + i.amount, 0);
  const outstanding = custInvoices.filter((i) => i.status !== "Paid").reduce((s, i) => s + i.amount, 0);

  const save = () => {
    if (!form.name.trim()) return toast.error("Name is required");
    update("customers", customer.id, { ...form });
    setEditing(false);
    toast.success("Customer saved");
  };
  const cancel = () => { setForm(customer); setEditing(false); };
  const del = () => {
    if (!confirm(`Delete ${customer.name}? This cannot be undone.`)) return;
    remove("customers", customer.id);
    toast.success("Customer removed");
    navigate({ to: "/customers" });
  };

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="w-fit"><Link to="/customers"><ArrowLeft className="mr-2 h-4 w-4" /> All customers</Link></Button>
      <PageHeader
        title={customer.name}
        description={customer.contact ? `Primary contact: ${customer.contact}` : "Customer profile"}
        actions={
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-primary-soft text-primary">{customer.type}</Badge>
            {editing ? (
              <>
                <Button size="sm" variant="outline" onClick={cancel}><X className="mr-2 h-4 w-4" /> Cancel</Button>
                <Button size="sm" onClick={save}><Save className="mr-2 h-4 w-4" /> Save</Button>
              </>
            ) : (
              <>
                <Button size="sm" variant="outline" onClick={() => setEditing(true)}><Pencil className="mr-2 h-4 w-4" /> Edit</Button>
                <Button size="sm" variant="destructive" onClick={del}><Trash2 className="mr-2 h-4 w-4" /> Delete</Button>
              </>
            )}
          </div>
        }
      />

      <div className="grid gap-4 md:grid-cols-3">
        <Card><CardContent className="p-4"><div className="text-xs uppercase text-muted-foreground">Jobs</div><div className="mt-1 font-display text-2xl font-bold">{custBookings.length || customer.jobs}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs uppercase text-muted-foreground">Paid</div><div className="mt-1 font-display text-2xl font-bold">${totalPaid.toLocaleString()}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs uppercase text-muted-foreground">Outstanding</div><div className="mt-1 font-display text-2xl font-bold">${outstanding.toLocaleString()}</div></CardContent></Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader><CardTitle className="font-display text-base">Profile</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            {editing ? (
              <>
                <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><Label>Primary contact</Label><Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} /></div>
                <div>
                  <Label>Type</Label>
                  <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
                <div><Label>Address</Label><Input value={form.address ?? ""} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><Label>City</Label><Input value={form.city ?? ""} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
                  <div><Label>ZIP</Label><Input value={form.zip ?? ""} onChange={(e) => setForm({ ...form, zip: e.target.value })} /></div>
                </div>
                <div><Label>Tags</Label><Input value={form.tags ?? ""} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="vip, weekly" /></div>
                <div><Label>Notes</Label><Textarea rows={3} value={form.notes ?? ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
                <div className="grid grid-cols-3 gap-2">
                  <div><Label>Jobs</Label><Input type="number" value={form.jobs} onChange={(e) => setForm({ ...form, jobs: Number(e.target.value) || 0 })} /></div>
                  <div><Label>LTV ($)</Label><Input type="number" value={form.lifetime} onChange={(e) => setForm({ ...form, lifetime: Number(e.target.value) || 0 })} /></div>
                  <div><Label>Since</Label><Input type="date" value={form.since} onChange={(e) => setForm({ ...form, since: e.target.value })} /></div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2"><Mail className="h-4 w-4 text-muted-foreground" /> {customer.email || "—"}</div>
                <div className="flex items-center gap-2"><Phone className="h-4 w-4 text-muted-foreground" /> {customer.phone || "—"}</div>
                <div className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 text-muted-foreground" /><div>{customer.address || "—"}{customer.city ? `, ${customer.city}` : ""}{customer.zip ? ` ${customer.zip}` : ""}</div></div>
                <div className="flex items-center gap-2"><Calendar className="h-4 w-4 text-muted-foreground" /> Since {customer.since}</div>
                {customer.tags && <div className="pt-2"><div className="flex flex-wrap gap-1">{customer.tags.split(",").map((t) => <Badge key={t} variant="outline">{t.trim()}</Badge>)}</div></div>}
                {customer.notes && <div className="pt-2 text-xs text-muted-foreground">{customer.notes}</div>}
              </>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="font-display text-base">Booking history ({custBookings.length})</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {custBookings.length === 0 && <p className="text-sm text-muted-foreground">No bookings yet.</p>}
            {custBookings.map((b) => (
              <div key={b.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                <div>
                  <div className="font-medium">{b.service}</div>
                  <div className="text-xs text-muted-foreground">{b.date} · {b.time} · {b.assignee}</div>
                </div>
                <Badge variant="outline">{b.status}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader><CardTitle className="font-display text-base flex items-center gap-2"><FileText className="h-4 w-4" /> Invoices & documents</CardTitle></CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-3">
            <div>
              <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Invoices</div>
              {custInvoices.length === 0 && <p className="text-xs text-muted-foreground">None</p>}
              {custInvoices.map((i) => (
                <div key={i.id} className="mb-1 flex justify-between rounded border p-2 text-xs">
                  <span>{i.id}</span><span className="font-semibold">${i.amount}</span>
                </div>
              ))}
            </div>
            <div>
              <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Quotes</div>
              {custQuotes.length === 0 && <p className="text-xs text-muted-foreground">None</p>}
              {custQuotes.map((q) => (
                <div key={q.id} className="mb-1 flex justify-between rounded border p-2 text-xs">
                  <span>{q.service}</span><span className="font-semibold">${q.amount}</span>
                </div>
              ))}
            </div>
            <div>
              <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Contracts</div>
              {custContracts.length === 0 && <p className="text-xs text-muted-foreground">None</p>}
              {custContracts.map((c) => (
                <div key={c.id} className="mb-1 flex justify-between rounded border p-2 text-xs">
                  <span>{c.service}</span><Badge variant="outline" className="h-4 text-[10px]">{c.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
