import { createFileRoute } from "@tanstack/react-router";
import { Star, MessageSquare, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { useStore, newId, type Review } from "@/lib/data-store";

export const Route = createFileRoute("/_authenticated/reviews")({
  component: ReviewsPage,
});

const emptyForm = { customer: "", rating: 5, text: "", date: new Date().toISOString().slice(0, 10) };

function ReviewsPage() {
  const { reviews, add, update, remove } = useStore();
  const dlg = useDialogState<Review>();
  const [form, setForm] = useState(emptyForm);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");

  const avg = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : "—";

  const openNew = () => { setForm(emptyForm); dlg.openCreate(); };
  const submit = () => {
    if (!form.customer.trim() || !form.text.trim()) return toast.error("Customer and review required");
    add("reviews", { id: newId("r"), ...form });
    toast.success("Review added");
    dlg.close();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Reviews"
        description="What customers say — respond, share, learn."
        actions={
          <Button size="sm" onClick={openNew}>
            <MessageSquare className="mr-2 h-4 w-4" /> Add review
          </Button>
        }
      />

      <Card className="bg-gradient-to-br from-primary to-[#036A80] text-primary-foreground">
        <CardContent className="flex flex-col items-start justify-between gap-4 p-6 sm:flex-row sm:items-center">
          <div>
            <div className="text-xs font-medium uppercase tracking-[0.14em] text-primary-foreground/70">Average rating</div>
            <div className="mt-2 flex items-baseline gap-3">
              <div className="font-display text-5xl font-bold">{avg}</div>
              <div className="flex text-secondary">
                {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-5 w-5 fill-current" />)}
              </div>
            </div>
            <p className="mt-2 text-sm text-primary-foreground/85">Across {reviews.length} recent reviews</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        {reviews.map((r) => (
          <Card key={r.id}>
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-primary/10 text-sm text-primary">
                    {r.customer.split(" ").map((p) => p[0]).join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="font-medium">{r.customer}</div>
                  <div className="text-xs text-muted-foreground">{r.date}</div>
                </div>
                <div className="flex text-secondary">
                  {Array.from({ length: r.rating }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
                </div>
              </div>
              <p className="mt-3 text-sm text-foreground">"{r.text}"</p>
              {r.reply && (
                <div className="mt-3 rounded-lg bg-muted/50 p-3 text-xs">
                  <div className="font-semibold text-foreground">Your reply</div>
                  <div className="mt-1 text-muted-foreground">{r.reply}</div>
                </div>
              )}
              {replyingTo === r.id ? (
                <div className="mt-3 space-y-2">
                  <Textarea value={replyText} onChange={(e) => setReplyText(e.target.value)} placeholder="Write a reply…" />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => {
                      update("reviews", r.id, { reply: replyText });
                      setReplyingTo(null); setReplyText("");
                      toast.success("Reply saved");
                    }}>Save reply</Button>
                    <Button variant="ghost" size="sm" onClick={() => { setReplyingTo(null); setReplyText(""); }}>Cancel</Button>
                  </div>
                </div>
              ) : (
                <div className="mt-4 flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => { setReplyingTo(r.id); setReplyText(r.reply ?? ""); }}>
                    {r.reply ? "Edit reply" : "Reply"}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => { remove("reviews", r.id); toast.success("Removed"); }}>
                    <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Delete
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        {reviews.length === 0 && (
          <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">No reviews yet.</CardContent></Card>
        )}
      </div>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title="Add review"
        onSubmit={submit}
      >
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Customer</Label>
            <Input value={form.customer} onChange={(e) => setForm({ ...form, customer: e.target.value })} />
          </div>
          <div>
            <Label>Rating (1-5)</Label>
            <Input type="number" min={1} max={5} value={form.rating} onChange={(e) => setForm({ ...form, rating: Math.min(5, Math.max(1, Number(e.target.value) || 1)) })} />
          </div>
        </div>
        <div>
          <Label>Date</Label>
          <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        </div>
        <div>
          <Label>Review</Label>
          <Textarea value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} />
        </div>
      </EntityDialog>
    </div>
  );
}
