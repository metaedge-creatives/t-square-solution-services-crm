import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Sparkles, ShieldCheck, Clock3, Loader2, Mail, Copy, ExternalLink } from "lucide-react";

import { BrandLogo } from "@/components/brand-logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAuth } from "@/lib/auth";
import { createInvite, inviteUrl } from "@/lib/invites";
import { sendEmail } from "@/lib/email-provider";
import { getCompany } from "@/lib/company-profile";


export const Route = createFileRoute("/login")({
  ssr: false,
  component: LoginPage,
});

function LoginPage() {
  const { login, isAuthenticated, users } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotBusy, setForgotBusy] = useState(false);
  const [forgotLink, setForgotLink] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated) navigate({ to: "/dashboard", replace: true });
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please enter both email and password.");
      return;
    }
    setSubmitting(true);
    try {
      const user = await login(email, password);
      toast.success(`Welcome back, ${user.name.split(" ")[0]}`);
      navigate({ to: "/dashboard", replace: true });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Sign-in failed.");
    } finally {
      setSubmitting(false);
    }
  };

  const openForgot = () => {
    setForgotEmail(email);
    setForgotLink(null);
    setForgotOpen(true);
  };

  const submitForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    const target = forgotEmail.trim().toLowerCase();
    if (!target) {
      toast.error("Enter your account email.");
      return;
    }
    const found = users.find((u) => u.email.trim().toLowerCase() === target);
    if (!found) {
      toast.error("No account with that email.");
      return;
    }
    setForgotBusy(true);
    try {
      const invite = createInvite({ userId: found.id, email: found.email, kind: "reset" });
      const link = inviteUrl(invite.token);
      const company = getCompany();
      const html = `<!doctype html><html><body style="font-family:Arial,sans-serif;background:#f6f8fa;padding:24px;color:#111">
  <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:12px;padding:28px;border:1px solid #e5e7eb">
    <h1 style="margin:0 0 8px;font-size:20px;color:#036A80">Reset your password</h1>
    <p style="margin:0 0 16px;font-size:14px;line-height:1.5">Hi ${found.name || "there"}, use the button below to choose a new password. This link expires in 7 days.</p>
    <p style="text-align:center;margin:24px 0"><a href="${link}" style="background:#036A80;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;font-weight:600">Reset password</a></p>
    <p style="margin:0;font-size:12px;word-break:break-all;color:#374151">${link}</p>
  </div>
  <p style="text-align:center;font-size:11px;color:#9ca3af;margin-top:16px">© ${new Date().getFullYear()} ${company.name}</p>
</body></html>`;
      const res = await sendEmail({ to: found.email, subject: `Reset your password — ${company.name}`, html });
      setForgotLink(link);
      if (res.ok) {
        toast.success(`Reset link sent to ${found.email}`);
      } else {
        try { await navigator.clipboard.writeText(link); } catch { /* ignore */ }
        toast.message("Email provider not connected — link copied below", { duration: 8000 });
      }
    } finally {
      setForgotBusy(false);
    }
  };

  const copyForgotLink = async () => {
    if (!forgotLink) return;
    try {
      await navigator.clipboard.writeText(forgotLink);
      toast.success("Link copied");
    } catch {
      toast.error("Copy failed — select the link manually.");
    }
  };



  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Left — form */}
      <div className="flex flex-col justify-between px-6 py-10 sm:px-12 lg:px-16">
        <BrandLogo />

        <div className="mx-auto w-full max-w-sm">
          <h1 className="font-display text-3xl font-bold tracking-tight text-foreground">
            Welcome back
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Sign in to run today's jobs, dispatch your crews, and keep every client sparkling.
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@tsquare.co"
              />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <button
                  type="button"
                  className="text-xs font-medium text-primary hover:underline"
                  onClick={openForgot}
                >
                  Forgot password?
                </button>

              </div>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>

            <label className="flex items-center gap-2 text-sm text-muted-foreground">
              <Checkbox defaultChecked /> Keep me signed in on this device
            </label>

            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Signing you in…
                </>
              ) : (
                "Sign in"
              )}
            </Button>
          </form>

        </div>

        <div className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} T Square Solution Services
        </div>
      </div>

      {/* Right — brand panel */}
      <div className="relative hidden overflow-hidden bg-gradient-to-br from-primary via-primary to-[#036A80] p-12 text-primary-foreground lg:flex lg:flex-col lg:justify-between">
        <div className="absolute -right-24 -top-24 h-96 w-96 rounded-full bg-secondary/30 blur-3xl" />
        <div className="absolute -bottom-32 -left-16 h-96 w-96 rounded-full bg-white/10 blur-3xl" />

        <div className="relative">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-medium backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-secondary" />
            T Square Operations Cloud
          </div>
          <h2 className="mt-6 font-display text-4xl font-bold leading-tight">
            Every job, every crew, every clean —
            <span className="block text-secondary">in one command center.</span>
          </h2>
          <p className="mt-4 max-w-md text-primary-foreground/85">
            Route your team, chase quotes, and never miss an invoice again.
          </p>
        </div>

        <div className="relative grid gap-4 sm:grid-cols-3">
          {[
            { icon: Sparkles, title: "6 service types", body: "Commercial to Airbnb, priced and ready." },
            { icon: Clock3, title: "Real-time schedule", body: "Dispatch changes reach crews instantly." },
            { icon: ShieldCheck, title: "QA built-in", body: "Inspections & photo checklists per job." },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="rounded-2xl bg-white/10 p-4 backdrop-blur">
              <Icon className="h-5 w-5 text-secondary" />
              <div className="mt-2 font-display text-sm font-semibold">{title}</div>
              <p className="mt-1 text-xs text-primary-foreground/80">{body}</p>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={forgotOpen} onOpenChange={setForgotOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reset your password</DialogTitle>
            <DialogDescription>
              Enter your account email and we'll send you a secure link to choose a new password.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submitForgot} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="forgot-email">Email</Label>
              <Input
                id="forgot-email"
                type="email"
                autoComplete="email"
                value={forgotEmail}
                onChange={(e) => setForgotEmail(e.target.value)}
                placeholder="you@tsquare.co"
                autoFocus
              />
            </div>
            {forgotLink ? (
              <div className="space-y-2 rounded-lg border bg-muted/40 p-3 text-xs">
                <div className="font-medium text-foreground">Your reset link</div>
                <div className="break-all text-muted-foreground">{forgotLink}</div>
                <div className="flex gap-2 pt-1">
                  <Button type="button" size="sm" variant="secondary" onClick={copyForgotLink}>
                    <Copy className="mr-1.5 h-3.5 w-3.5" /> Copy link
                  </Button>
                  <Button type="button" size="sm" variant="outline" asChild>
                    <a href={forgotLink}>
                      <ExternalLink className="mr-1.5 h-3.5 w-3.5" /> Open now
                    </a>
                  </Button>
                </div>
              </div>
            ) : null}
            <DialogFooter className="gap-2 sm:gap-2">
              <Button type="button" variant="ghost" onClick={() => setForgotOpen(false)}>
                Close
              </Button>
              <Button type="submit" disabled={forgotBusy}>
                {forgotBusy ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending…</>
                ) : (
                  <><Mail className="mr-2 h-4 w-4" /> Send reset link</>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
