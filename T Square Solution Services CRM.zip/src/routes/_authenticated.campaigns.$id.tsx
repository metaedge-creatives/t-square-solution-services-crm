import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import {
  ArrowLeft,
  Check,
  Eye,
  Pencil,
  Send,
  Loader2,
  Mail,
  Calendar,
  Users2,
  Sparkles,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  EmailBlockEditor,
  DEFAULT_BLOCKS,
  compileEmail,
  type EmailBlock,
} from "@/components/email-editor";
import { useStore, type CampaignStatus } from "@/lib/data-store";
import { loadIntegrations, sendEmail } from "@/lib/email-provider";

export const Route = createFileRoute("/_authenticated/campaigns/$id")({
  component: CampaignEditorPage,
});

const STATUSES: CampaignStatus[] = ["Draft", "Scheduled", "Sent"];

function CampaignEditorPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { campaigns, audiences, templates, update } = useStore();
  const campaign = campaigns.find((c) => c.id === id);

  const [mode, setMode] = useState<"preview" | "design">("preview");
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<Date | null>(null);

  const initialBlocks = useMemo<EmailBlock[]>(() => {
    if (campaign?.blocks && Array.isArray(campaign.blocks) && campaign.blocks.length > 0) {
      return campaign.blocks as EmailBlock[];
    }
    return DEFAULT_BLOCKS;
  }, [campaign?.id]);

  const [form, setForm] = useState(() => ({
    name: campaign?.name ?? "Untitled campaign",
    subject: campaign?.subject ?? "",
    previewText: campaign?.previewText ?? "",
    fromName: campaign?.fromName ?? "T Square Solutions",
    fromEmail: campaign?.fromEmail ?? "",
    audience: campaign?.audience ?? (audiences[0]?.name ?? ""),
    scheduledAt: campaign?.scheduledAt ?? new Date().toISOString().slice(0, 10),
    status: (campaign?.status ?? "Draft") as CampaignStatus,
  }));
  const [blocks, setBlocks] = useState<EmailBlock[]>(initialBlocks);

  const compiled = useMemo(() => compileEmail(blocks, form.subject), [blocks, form.subject]);

  // Auto-save with debounce
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const first = useRef(true);
  useEffect(() => {
    if (!campaign) return;
    if (first.current) { first.current = false; return; }
    setSaving(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      const audSize = audiences.find((a) => a.name === form.audience)?.contacts.length ?? 0;
      update("campaigns", campaign.id, {
        name: form.name,
        subject: form.subject,
        previewText: form.previewText,
        fromName: form.fromName,
        fromEmail: form.fromEmail,
        audience: form.audience,
        scheduledAt: form.scheduledAt,
        status: form.status,
        recipients: audSize,
        body: compiled,
        blocks,
      });
      setSaving(false);
      setSavedAt(new Date());
    }, 600);
    return () => { if (timer.current) clearTimeout(timer.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form, blocks]);

  if (!campaign) {
    return (
      <div className="mx-auto max-w-md p-8 text-center">
        <p className="text-sm text-muted-foreground">Campaign not found.</p>
        <Button className="mt-4" onClick={() => navigate({ to: "/email-marketing" })}>
          Back to campaigns
        </Button>
      </div>
    );
  }

  const audience = audiences.find((a) => a.name === form.audience);
  const audienceCount = audience?.contacts.length ?? 0;

  const applyTemplate = (tid: string) => {
    const t = templates.find((x) => x.id === tid);
    if (!t) return;
    setForm((f) => ({ ...f, subject: f.subject || t.subject }));
    // If template contains blocks (future), respect. Else keep current blocks and inject subject only.
    toast.success(`Template "${t.name}" applied to subject line.`);
  };

  const sendNow = async () => {
    const cfg = loadIntegrations();
    if (!cfg.active) {
      toast.error("Connect an email provider first (Email Marketing → Integrations).");
      return;
    }
    const recipients = (audience?.contacts ?? []).map((x) => x.email).filter(Boolean);
    if (recipients.length === 0) {
      toast.error("Audience has no contacts with email addresses.");
      return;
    }
    const t = toast.loading(`Sending to ${recipients.length} contact(s)…`);
    const res = await sendEmail({ to: recipients, subject: form.subject, html: compiled });
    toast.dismiss(t);
    if (res.ok) {
      setForm((f) => ({ ...f, status: "Sent", scheduledAt: new Date().toISOString().slice(0, 10) }));
      toast.success(`Sent to ${res.sent} contact(s) via ${res.provider}.`);
    } else {
      toast.error(`Sent ${res.sent}, failed ${res.failed}. ${res.errors?.[0] ?? ""}`.trim());
    }
  };

  return (
    <div className="flex h-[calc(100vh-6rem)] flex-col">
      {/* Top bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b bg-background px-4 py-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/email-marketing">
              <ArrowLeft className="mr-1.5 h-4 w-4" /> Campaigns
            </Link>
          </Button>
          <div>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-72 rounded border-transparent bg-transparent px-2 py-1 text-lg font-semibold hover:border-border focus:border-primary focus:outline-none"
              placeholder="Untitled campaign"
            />
            <div className="ml-2 flex items-center gap-2 text-xs text-muted-foreground">
              {saving ? (
                <><Loader2 className="h-3 w-3 animate-spin" /> Saving…</>
              ) : savedAt ? (
                <><Check className="h-3 w-3 text-emerald-600" /> Saved {savedAt.toLocaleTimeString()}</>
              ) : (
                <>Auto-saves as you type</>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-md border p-0.5">
            <button
              onClick={() => setMode("preview")}
              className={
                "inline-flex items-center gap-1.5 rounded px-3 py-1.5 text-xs font-medium transition " +
                (mode === "preview" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")
              }
            >
              <Eye className="h-3.5 w-3.5" /> Preview
            </button>
            <button
              onClick={() => setMode("design")}
              className={
                "inline-flex items-center gap-1.5 rounded px-3 py-1.5 text-xs font-medium transition " +
                (mode === "design" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")
              }
            >
              <Pencil className="h-3.5 w-3.5" /> Design
            </button>
          </div>
          <Button size="sm" onClick={sendNow} disabled={form.status === "Sent"}>
            <Send className="mr-1.5 h-4 w-4" />
            {form.status === "Sent" ? "Sent" : "Send now"}
          </Button>
        </div>
      </div>

      {/* Body: left settings + right canvas */}
      <div className="grid flex-1 gap-0 overflow-hidden lg:grid-cols-[340px_1fr]">
        {/* Left sidebar */}
        <aside className="overflow-y-auto border-r bg-muted/20 p-4">
          <div className="space-y-4">
            <Card>
              <CardContent className="space-y-3 p-4">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Mail className="h-4 w-4 text-primary" /> Email details
                </div>
                <div>
                  <Label className="text-xs">From name</Label>
                  <Input value={form.fromName} onChange={(e) => setForm({ ...form, fromName: e.target.value })} />
                </div>
                <div>
                  <Label className="text-xs">From email</Label>
                  <Input type="email" placeholder="hello@yourdomain.com" value={form.fromEmail} onChange={(e) => setForm({ ...form, fromEmail: e.target.value })} />
                </div>
                <div>
                  <Label className="text-xs">Subject line</Label>
                  <Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="What's this email about?" />
                </div>
                <div>
                  <Label className="text-xs">Preview text</Label>
                  <Input value={form.previewText} onChange={(e) => setForm({ ...form, previewText: e.target.value })} placeholder="Shown in the inbox after the subject" />
                  <p className="mt-1 text-[11px] text-muted-foreground">Appears in inboxes next to the subject. Keep under 90 characters.</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="space-y-3 p-4">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Users2 className="h-4 w-4 text-primary" /> Audience
                </div>
                <Select value={form.audience} onValueChange={(v) => setForm({ ...form, audience: v })}>
                  <SelectTrigger><SelectValue placeholder="Pick an audience" /></SelectTrigger>
                  <SelectContent>
                    {audiences.map((a) => (
                      <SelectItem key={a.id} value={a.name}>
                        {a.name} ({a.contacts.length})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="rounded-md bg-primary-soft px-3 py-2 text-xs text-primary">
                  {audienceCount} contact{audienceCount === 1 ? "" : "s"} will receive this email.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="space-y-3 p-4">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Calendar className="h-4 w-4 text-primary" /> Delivery
                </div>
                <div>
                  <Label className="text-xs">Status</Label>
                  <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as CampaignStatus })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Send / schedule date</Label>
                  <Input type="date" value={form.scheduledAt} onChange={(e) => setForm({ ...form, scheduledAt: e.target.value })} />
                </div>
              </CardContent>
            </Card>

            {templates.length > 0 && (
              <Card>
                <CardContent className="space-y-3 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold">
                    <Sparkles className="h-4 w-4 text-primary" /> Start from template
                  </div>
                  <Select onValueChange={applyTemplate}>
                    <SelectTrigger><SelectValue placeholder="Choose a template" /></SelectTrigger>
                    <SelectContent>
                      {templates.map((t) => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            )}
          </div>
        </aside>

        {/* Right canvas */}
        <main className="overflow-y-auto bg-[#EEF3F5]">
          {mode === "preview" ? (
            <div className="mx-auto max-w-3xl p-6">
              {/* Inbox-style header */}
              <div className="rounded-t-xl border border-b-0 bg-white p-4 text-sm">
                <div className="flex items-baseline justify-between">
                  <div className="font-semibold">{form.fromName || "Sender"}</div>
                  <div className="text-xs text-muted-foreground">{form.scheduledAt}</div>
                </div>
                <div className="text-muted-foreground">
                  {form.fromEmail ? <>&lt;{form.fromEmail}&gt;</> : <span className="italic">Add a from email in the sidebar</span>}
                </div>
                <div className="mt-2 text-base font-semibold">
                  {form.subject || <span className="italic text-muted-foreground">No subject</span>}
                </div>
                {form.previewText && (
                  <div className="text-xs text-muted-foreground">{form.previewText}</div>
                )}
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-primary-soft text-primary">
                    To: {form.audience || "—"} · {audienceCount} recipient{audienceCount === 1 ? "" : "s"}
                  </Badge>
                </div>
              </div>
              {/* Rendered email — clickable to jump into design mode */}
              <button
                type="button"
                onClick={() => setMode("design")}
                className="block w-full rounded-b-xl border bg-white p-0 text-left transition hover:ring-2 hover:ring-primary/30"
                title="Click to edit"
              >
                <div dangerouslySetInnerHTML={{ __html: compiled }} />
              </button>
              <div className="mt-3 text-center text-xs text-muted-foreground">
                Click the email above to open the visual editor.
              </div>
            </div>
          ) : (
            <div className="p-4">
              <EmailBlockEditor blocks={blocks} onChange={setBlocks} subject={form.subject} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
