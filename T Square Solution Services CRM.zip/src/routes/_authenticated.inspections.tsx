import { createFileRoute } from "@tanstack/react-router";
import { ClipboardCheck, Plus, Trash2, Pencil } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { useStore, newId, type Inspection } from "@/lib/data-store";

export const Route = createFileRoute("/_authenticated/inspections")({
  component: InspectionsPage,
});

const STATUSES: Inspection["status"][] = ["Passed", "Needs rework"];
const emptyForm = { job: "", inspector: "", score: 90, status: "Passed" as Inspection["status"] };

function InspectionsPage() {
  const { inspections, staff, add, update, remove } = useStore();
  const dlg = useDialogState<Inspection>();
  const [form, setForm] = useState(emptyForm);

  // per-inspection checklist state stored in-memory (page-level)
  const [checklist, setChecklist] = useState([
    { label: "Floors vacuumed & mopped", done: true },
    { label: "Bathrooms disinfected", done: true },
    { label: "Kitchen surfaces & appliances", done: true },
    { label: "Windows & mirrors streak-free", done: false },
    { label: "Trash removed, liners replaced", done: true },
    { label: "Final walkthrough with photos", done: false },
  ]);
  const [newItem, setNewItem] = useState("");

  const openNew = () => {
    setForm({ ...emptyForm, inspector: staff[0]?.name ?? "" });
    dlg.openCreate();
  };
  const openEdit = (i: Inspection) => {
    setForm({ job: i.job, inspector: i.inspector, score: i.score, status: i.status });
    dlg.openEdit(i);
  };
  const submit = () => {
    if (!form.job.trim()) return toast.error("Job label is required");
    const status: Inspection["status"] = form.score >= 80 ? "Passed" : "Needs rework";
    const payload = { ...form, status };
    if (dlg.editing) {
      update("inspections", dlg.editing.id, payload);
      toast.success("Inspection updated");
    } else {
      add("inspections", { id: newId("i"), ...payload });
      toast.success("Inspection added");
    }
    dlg.close();
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Inspections"
        description="Quality checks per job — keep every clean sparkling."
        actions={
          <Button size="sm" onClick={openNew}>
            <Plus className="mr-2 h-4 w-4" /> New inspection
          </Button>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-3 lg:col-span-2">
          {inspections.map((i) => (
            <Card key={i.id}>
              <CardContent className="flex items-center gap-4 p-4">
                <div className="rounded-xl bg-primary-soft p-2.5 text-primary">
                  <ClipboardCheck className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-medium">{i.job}</div>
                  <div className="text-xs text-muted-foreground">Inspector · {i.inspector}</div>
                </div>
                <div className="w-40">
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Score</span>
                    <span className="font-display font-semibold">{i.score}</span>
                  </div>
                  <Progress value={i.score} />
                </div>
                <Badge variant="secondary" className={i.status === "Passed" ? "bg-success/20 text-success-foreground" : "bg-destructive/15 text-destructive"}>
                  {i.status}
                </Badge>
                <Button variant="ghost" size="icon" onClick={() => openEdit(i)}><Pencil className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" onClick={() => { remove("inspections", i.id); toast.success("Removed"); }}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
          {inspections.length === 0 && (
            <Card><CardContent className="p-8 text-center text-sm text-muted-foreground">No inspections yet.</CardContent></Card>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="font-display">Standard checklist</CardTitle>
            <CardDescription>Applied to every residential job</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {checklist.map((c, idx) => (
                <li key={idx} className="flex items-center gap-3 rounded-lg border p-2.5 text-sm">
                  <button
                    onClick={() => setChecklist(checklist.map((it, i) => i === idx ? { ...it, done: !it.done } : it))}
                    className={"flex h-5 w-5 items-center justify-center rounded-md border " + (c.done ? "border-primary bg-primary text-primary-foreground" : "border-input")}
                    aria-label="Toggle item"
                  >
                    {c.done && (
                      <svg viewBox="0 0 20 20" fill="currentColor" className="h-3 w-3">
                        <path fillRule="evenodd" clipRule="evenodd" d="M16.7 5.3a1 1 0 010 1.4l-7.5 7.5a1 1 0 01-1.4 0L3.3 9.7a1 1 0 011.4-1.4L8.5 12l6.8-6.8a1 1 0 011.4.1z" />
                      </svg>
                    )}
                  </button>
                  <span className={"flex-1 " + (c.done ? "text-foreground" : "text-muted-foreground")}>{c.label}</span>
                  <button
                    onClick={() => setChecklist(checklist.filter((_, i) => i !== idx))}
                    className="text-muted-foreground hover:text-destructive"
                    aria-label="Remove"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
            <div className="mt-3 flex gap-2">
              <Input placeholder="Add checklist item…" value={newItem} onChange={(e) => setNewItem(e.target.value)} />
              <Button
                type="button"
                onClick={() => {
                  if (!newItem.trim()) return;
                  setChecklist([...checklist, { label: newItem.trim(), done: false }]);
                  setNewItem("");
                }}
              >
                Add
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit inspection" : "New inspection"}
        onSubmit={submit}
      >
        <div>
          <Label>Job</Label>
          <Input value={form.job} onChange={(e) => setForm({ ...form, job: e.target.value })} placeholder="e.g. Nova Coworking — 07/12" />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2">
            <Label>Inspector</Label>
            <Select value={form.inspector || staff[0]?.name} onValueChange={(v) => setForm({ ...form, inspector: v })}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>{staff.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Score</Label>
            <Input type="number" min={0} max={100} value={form.score} onChange={(e) => setForm({ ...form, score: Number(e.target.value) || 0 })} />
          </div>
        </div>
        <div>
          <Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as Inspection["status"] })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </EntityDialog>
    </div>
  );
}
