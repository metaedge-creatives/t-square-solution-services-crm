import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { History, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { readActivity, clearActivity, type Activity } from "@/lib/activity-log";

export const Route = createFileRoute("/_authenticated/activity")({
  component: ActivityPage,
});

function ActivityPage() {
  const [items, setItems] = useState<Activity[]>([]);

  useEffect(() => {
    setItems(readActivity());
    const on = () => setItems(readActivity());
    window.addEventListener("tsquare:activity", on);
    return () => window.removeEventListener("tsquare:activity", on);
  }, []);

  const clear = () => { clearActivity(); setItems([]); toast.success("Activity cleared"); };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Activity log"
        description="Every change across the CRM — timestamped and traceable."
        actions={<Button variant="outline" size="sm" onClick={clear}><Trash2 className="mr-2 h-4 w-4" /> Clear</Button>}
      />

      <Card>
        <CardContent className="p-0">
          {items.length === 0 ? (
            <div className="p-10 text-center">
              <History className="mx-auto mb-3 h-8 w-8 text-muted-foreground" />
              <div className="text-sm text-muted-foreground">No activity recorded yet.</div>
            </div>
          ) : (
            <ul className="divide-y">
              {items.map((a) => (
                <li key={a.id} className="flex items-start gap-3 p-4">
                  <Badge variant="secondary" className="mt-0.5 shrink-0 bg-primary-soft text-primary uppercase text-[10px]">
                    {a.entity}
                  </Badge>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm">
                      <span className="font-medium">{a.actor}</span>{" "}
                      <span className="text-muted-foreground">{a.action}</span>{" "}
                      <span>{a.summary}</span>
                    </div>
                    <div className="mt-0.5 text-xs text-muted-foreground">{new Date(a.ts).toLocaleString()}</div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
