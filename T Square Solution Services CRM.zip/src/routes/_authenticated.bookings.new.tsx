import { createFileRoute } from "@tanstack/react-router";
import { BookingForm } from "@/components/booking-form";

export const Route = createFileRoute("/_authenticated/bookings/new")({
  component: () => <BookingForm />,
});
