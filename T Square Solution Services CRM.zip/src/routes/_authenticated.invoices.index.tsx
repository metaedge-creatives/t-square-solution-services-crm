import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Plus, Send, Trash2, Pencil, Download, Mail, Check, Repeat, Eye } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { useStore, type Invoice, type InvoiceStatus } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";
import { useCompanyProfile, useDocTemplates, interpolate, buildVars } from "@/lib/company-profile";
import { renderInvoicePdf, openMailto } from "@/lib/pdf";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";

export const Route = createFileRoute("/_authenticated/invoices/")({
  component: InvoicesPage,
});

const STATUSES: InvoiceStatus[] = ["Draft", "Pending Approval", "Sent", "Paid", "Overdue"];

const tone = (s: string) =>
  s === "Paid" ? "bg-success/20 text-success-foreground"
    : s === "Overdue" ? "bg-destructive/15 text-destructive"
      : s === "Pending Approval" ? "bg-amber-100 text-amber-800"
        : "bg-secondary/40 text-secondary-foreground";

function InvoicesPage() {
  const { invoices, customers, update, remove } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const navigate = useNavigate();

  const findCustomer = (name: string) => customers.find((c) => c.name === name);

  const downloadPdf = async (inv: Invoice) => {
    const c = findCustomer(inv.customer);
    const doc = await renderInvoicePdf(
      {
        id: inv.id,
        customer: inv.customer,
        customerEmail: inv.email || c?.email,
        customerPhone: inv.phone || c?.phone,
        customerAddress: inv.address || (c as { address?: string } | undefined)?.address,
        amount: inv.amount,
        issued: inv.issued,
        due: inv.due,
        status: inv.status,
        lineItems: inv.service
          ? [{ description: inv.service + (inv.notes ? ` — ${inv.notes}` : ""), qty: 1, rate: inv.amount }]
          : undefined,
      },
      company,
      docs,
    );
    doc.save(`${inv.id}-${inv.customer.replace(/\s+/g, "-")}.pdf`);
    toast.success("PDF downloaded");
  };

  const emailInvoice = (inv: Invoice) => {
    const c = findCustomer(inv.customer);
    if (!c?.email) return toast.error("Customer has no email on file");
    downloadPdf(inv);
    const vars = buildVars(company, {
      invoice_id: inv.id,
      customer_name: inv.customer,
      amount: inv.amount.toFixed(2),
      due_date: inv.due,
    });
    openMailto(c.email, interpolate(docs.invoiceEmailSubject, vars), interpolate(docs.invoiceEmailBody, vars));
    update("invoices", inv.id, { status: "Sent" });
    toast.success("Email drafted — attach the PDF that just downloaded");
  };

  const paid = invoices.filter((i) => i.status === "Paid").reduce((s, i) => s + i.amount, 0);
  const outstanding = invoices.filter((i) => i.status !== "Paid").reduce((s, i) => s + i.amount, 0);
  const overdue = invoices.filter((i) => i.status === "Overdue").reduce((s, i) => s + i.amount, 0);

  const approve = (inv: Invoice) => {
    update("invoices", inv.id, { status: "Sent" });
    logActivity({ actor: "You", entity: "invoice", entityId: inv.id, action: "approved", summary: `${inv.id} · $${inv.amount}` });
    fireEvent({ trigger: "invoice.approved", payload: { id: inv.id, customer: inv.customer, amount: inv.amount, phone: inv.phone ?? "" } });
    toast.success("Invoice approved and marked as sent");
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Invoices"
        description="Bill jobs, track payments, chase down overdue."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => { downloadCsv("invoices", invoices); toast.success("Exported invoices"); }}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={() => navigate({ to: "/invoices/new" })}>
              <Plus className="mr-2 h-4 w-4" /> New invoice
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <MetricCard label="Paid" value={`$${paid.toLocaleString()}`} />
        <MetricCard label="Outstanding" value={`$${outstanding.toLocaleString()}`} accent />
        <MetricCard label="Overdue" value={`$${overdue.toLocaleString()}`} danger />
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Issued</TableHead>
                  <TableHead>Due</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-32 text-right" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((i) => (
                  <TableRow key={i.id}>
                    <TableCell className="font-medium">
                      <Link to="/invoices/$id" params={{ id: i.id }} className="inline-flex items-center gap-1 text-primary hover:underline">
                        {i.id}
                        {i.recurring && <Repeat className="h-3 w-3 text-primary" aria-label={`Recurring ${i.recurring.frequency}`} />}
                      </Link>
                    </TableCell>
                    <TableCell>{i.customer}</TableCell>
                    <TableCell className="text-muted-foreground">{i.issued}</TableCell>
                    <TableCell className="text-muted-foreground">{i.due}</TableCell>
                    <TableCell className="text-right font-display font-semibold">${i.amount.toLocaleString()}</TableCell>
                    <TableCell>
                      <Select value={i.status} onValueChange={(v) => update("invoices", i.id, { status: v as InvoiceStatus })}>
                        <SelectTrigger className="h-8 w-32">
                          <Badge variant="secondary" className={tone(i.status)}>{i.status}</Badge>
                        </SelectTrigger>
                        <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button asChild variant="ghost" size="icon" title="Open invoice page">
                        <Link to="/invoices/$id" params={{ id: i.id }}><Eye className="h-4 w-4" /></Link>
                      </Button>
                      {i.status === "Pending Approval" && (
                        <Button variant="ghost" size="icon" title="Approve invoice" onClick={() => approve(i)}>
                          <Check className="h-4 w-4 text-success" />
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" title="Download PDF" onClick={() => downloadPdf(i)}>
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Email to customer" onClick={() => emailInvoice(i)}>
                        <Mail className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => { update("invoices", i.id, { status: "Sent" }); toast.success("Marked as sent"); }} title="Mark sent">
                        <Send className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => navigate({ to: "/invoices/$id/edit", params: { id: i.id } })}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => { remove("invoices", i.id); toast.success("Removed"); }}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {invoices.length === 0 && (
                  <TableRow><TableCell colSpan={7} className="py-8 text-center text-sm text-muted-foreground">No invoices yet.</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function MetricCard({ label, value, accent, danger }: { label: string; value: string; accent?: boolean; danger?: boolean }) {
  return (
    <Card className={danger ? "border-destructive/40 bg-destructive/5" : accent ? "border-secondary bg-secondary/20" : ""}>
      <CardContent className="p-5">
        <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="mt-2 font-display text-2xl font-bold">{value}</div>
      </CardContent>
    </Card>
  );
}
