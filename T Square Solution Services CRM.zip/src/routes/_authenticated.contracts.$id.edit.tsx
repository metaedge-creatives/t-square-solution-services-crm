import { createFileRoute, Link } from "@tanstack/react-router";
import { ContractForm } from "@/components/contract-form";
import { useStore } from "@/lib/data-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/contracts/$id/edit")({
  component: EditContract,
});

function EditContract() {
  const { id } = Route.useParams();
  const { contracts } = useStore();
  const c = contracts.find((x) => x.id === id);
  if (!c) {
    return (
      <div className="space-y-4">
        <Button asChild variant="ghost" size="sm"><Link to="/contracts"><ArrowLeft className="mr-2 h-4 w-4" /> Back</Link></Button>
        <Card><CardContent className="p-10 text-center text-muted-foreground">Contract not found.</CardContent></Card>
      </div>
    );
  }
  return <ContractForm editing={c} />;
}
