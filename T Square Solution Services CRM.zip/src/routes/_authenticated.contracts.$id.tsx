import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, CalendarDays, Download, Edit, Mail, MapPin, Phone, Trash2 } from "lucide-react";
import type { ReactNode } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { assembleContract, buildVars, interpolate, useCompanyProfile, useDocTemplates } from "@/lib/company-profile";
import { type Contract, type ContractStatus, useStore } from "@/lib/data-store";
import { openMailto, renderContractPdf } from "@/lib/pdf";

export const Route = createFileRoute("/_authenticated/contracts/$id")({
  component: ContractDetailPage,
});

const STATUSES: ContractStatus[] = ["Draft", "Sent", "Signed", "Expired"];
const today = () => new Date().toISOString().slice(0, 10);

function tone(status: ContractStatus) {
  return status === "Signed" ? "bg-success/20 text-success-foreground"
    : status === "Expired" ? "bg-destructive/15 text-destructive"
      : status === "Sent" ? "bg-primary-soft text-primary"
        : "bg-muted text-muted-foreground";
}

function money(value: number) {
  return `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function ContractDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { contracts, customers, update, remove } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const contract = contracts.find((c) => c.id === id);

  if (!contract) {
    return (
      <div className="space-y-4">
        <Button asChild variant="ghost" size="sm" className="w-fit"><Link to="/contracts"><ArrowLeft className="mr-2 h-4 w-4" /> All contracts</Link></Button>
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">Contract not found.</CardContent></Card>
      </div>
    );
  }

  const customer = customers.find((c) => c.name === contract.customer || c.email === contract.customerEmail);
  const vars = buildVars(company, {
    contract_id: contract.id,
    customer_name: contract.customer,
    customer_email: contract.customerEmail ?? "",
    service: contract.service,
    amount: contract.amount.toFixed(2),
    start_date: contract.startDate,
    end_date: contract.endDate,
  });
  const previewText = assembleContract(docs, vars, contract.body);

  const downloadPdf = async (c: Contract) => {
    const doc = await renderContractPdf(
      { id: c.id, customer: c.customer, customerEmail: c.customerEmail, service: c.service, amount: c.amount, startDate: c.startDate, endDate: c.endDate, body: c.body },
      company,
      docs,
    );
    doc.save(`${c.id}-${c.customer.replace(/\s+/g, "-")}.pdf`);
    toast.success("PDF downloaded");
  };

  const sendEmail = (c: Contract) => {
    if (!c.customerEmail) return toast.error("Add a customer email first");
    downloadPdf(c);
    openMailto(c.customerEmail, interpolate(docs.contractEmailSubject, vars), interpolate(docs.contractEmailBody, vars));
    update("contracts", c.id, { status: "Sent", sentAt: today() });
    toast.success("Email drafted — attach the PDF that just downloaded");
  };

  const deleteContract = () => {
    if (!confirm(`Delete contract ${contract.id}?`)) return;
    remove("contracts", contract.id);
    toast.success("Contract removed");
    navigate({ to: "/contracts" });
  };

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="w-fit"><Link to="/contracts"><ArrowLeft className="mr-2 h-4 w-4" /> All contracts</Link></Button>
      <PageHeader
        title={`Contract ${contract.id}`}
        description={`${contract.service} agreement for ${contract.customer}`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className={tone(contract.status)}>{contract.status}</Badge>
            <Button variant="outline" size="sm" onClick={() => downloadPdf(contract)}><Download className="mr-2 h-4 w-4" /> PDF</Button>
            <Button variant="outline" size="sm" onClick={() => sendEmail(contract)}><Mail className="mr-2 h-4 w-4" /> Email</Button>
            <Button asChild variant="outline" size="sm"><Link to="/contracts/$id/edit" params={{ id: contract.id }}><Edit className="mr-2 h-4 w-4" /> Edit</Link></Button>
            <Button variant="destructive" size="sm" onClick={deleteContract}><Trash2 className="mr-2 h-4 w-4" /> Delete</Button>
          </div>
        }
      />

      <div className="grid gap-4 md:grid-cols-3">
        <Metric label="Contract value" value={money(contract.amount)} />
        <Metric label="Start date" value={contract.startDate} icon={<CalendarDays className="h-4 w-4" />} />
        <Metric label="End date" value={contract.endDate} icon={<CalendarDays className="h-4 w-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-[360px_minmax(0,1fr)]">
        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="font-display text-base">Client</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="text-lg font-semibold">{contract.customer}</div>
              <Info icon={<Mail className="h-4 w-4" />} text={contract.customerEmail || customer?.email || "No email"} />
              <Info icon={<Phone className="h-4 w-4" />} text={contract.customerPhone || customer?.phone || "No phone"} />
              <Info icon={<MapPin className="h-4 w-4" />} text={contract.customerAddress || customer?.address || "No address"} />
              {customer && <Button asChild variant="outline" size="sm" className="w-full"><Link to="/customers/$id" params={{ id: customer.id }}>Open customer page</Link></Button>}
            </CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle className="font-display text-base">Controls</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div><div className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Status</div><Select value={contract.status} onValueChange={(v) => update("contracts", contract.id, { status: v as ContractStatus, signedAt: v === "Signed" ? today() : contract.signedAt })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
              <Separator />
              <Detail label="Service" value={contract.service} />
              <Detail label="Sent" value={contract.sentAt || "Not sent"} />
              <Detail label="Signed" value={contract.signedAt || "Not signed"} />
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle className="font-display text-base">Contract preview</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-hidden rounded-lg border bg-background shadow-sm">
              <div className="bg-primary px-6 py-5 text-primary-foreground">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img src="/tsquare-logo.png" alt="" className="h-11 w-auto object-contain" />
                    <div>
                      <div className="font-display text-xl font-bold leading-tight">{company.name}</div>
                      <div className="mt-0.5 text-xs opacity-90">{[company.email, company.phone, company.website].filter(Boolean).join(" · ")}</div>
                    </div>
                  </div>
                  <div className="text-right"><div className="font-display text-2xl font-bold tracking-wide">CONTRACT</div><div className="text-sm opacity-90">{contract.id}</div></div>
                </div>
              </div>
              <div className="h-0.5 w-full bg-secondary" />

              <div className="grid gap-4 bg-primary-soft p-5 text-sm md:grid-cols-3">
                <Detail label="Client" value={contract.customer} />
                <Detail label="Service" value={contract.service} />
                <Detail label="Value" value={money(contract.amount)} />
              </div>
              <div className="prose prose-sm max-w-none whitespace-pre-wrap p-6 leading-7 text-foreground">
                {previewText}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Metric({ label, value, icon }: { label: string; value: string; icon?: ReactNode }) {
  return <Card><CardContent className="p-4"><div className="mb-2 flex items-center gap-2 text-xs uppercase text-muted-foreground">{icon}{label}</div><div className="font-display text-2xl font-bold">{value}</div></CardContent></Card>;
}

function Info({ icon, text }: { icon: ReactNode; text: string }) {
  return <div className="flex items-start gap-2 text-sm text-muted-foreground"><span className="mt-0.5">{icon}</span><span className="break-words">{text}</span></div>;
}

function Detail({ label, value }: { label: string; value: string }) {
  return <div><div className="text-xs font-semibold uppercase text-muted-foreground">{label}</div><div className="font-medium">{value}</div></div>;
}