import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, CalendarDays, Download, Edit, Mail, MapPin, Phone, Send, Trash2 } from "lucide-react";
import type { ReactNode } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";
import { buildVars, interpolate, useCompanyProfile, useDocTemplates } from "@/lib/company-profile";
import { type Invoice, type InvoiceStatus, useStore } from "@/lib/data-store";
import { openMailto, renderInvoicePdf } from "@/lib/pdf";

export const Route = createFileRoute("/_authenticated/invoices/$id")({
  component: InvoiceDetailPage,
});

const STATUSES: InvoiceStatus[] = ["Draft", "Pending Approval", "Sent", "Paid", "Overdue"];

function tone(status: InvoiceStatus) {
  return status === "Paid" ? "bg-success/20 text-success-foreground"
    : status === "Overdue" ? "bg-destructive/15 text-destructive"
      : status === "Pending Approval" ? "bg-amber-100 text-amber-800"
        : status === "Sent" ? "bg-primary-soft text-primary"
          : "bg-muted text-muted-foreground";
}

function money(value: number) {
  return `$${value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function InvoiceDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { invoices, customers, update, remove } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const invoice = invoices.find((i) => i.id === id);

  if (!invoice) {
    return (
      <div className="space-y-4">
        <Button asChild variant="ghost" size="sm" className="w-fit"><Link to="/invoices"><ArrowLeft className="mr-2 h-4 w-4" /> All invoices</Link></Button>
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">Invoice not found.</CardContent></Card>
      </div>
    );
  }

  const customer = customers.find((c) => c.name === invoice.customer || c.email === invoice.email);
  const customerEmail = invoice.email ?? customer?.email;
  const customerPhone = invoice.phone ?? customer?.phone;
  const customerAddress = invoice.address ?? customer?.address;
  const lineDescription = invoice.service ? invoice.service + (invoice.notes ? ` — ${invoice.notes}` : "") : "Services rendered";
  const displayItems = invoice.items && invoice.items.length
    ? invoice.items
    : [{ description: lineDescription, qty: 1, rate: invoice.amount }];

  const downloadPdf = async (inv: Invoice) => {
    const items = inv.items && inv.items.length
      ? inv.items
      : [{ description: lineDescription, qty: 1, rate: inv.amount }];
    const doc = await renderInvoicePdf(
      {
        id: inv.id,
        customer: inv.customer,
        customerEmail,
        customerPhone,
        customerAddress,
        amount: inv.amount,
        issued: inv.issued,
        due: inv.due,
        status: inv.status,
        lineItems: items,
      },
      company,
      docs,
    );
    doc.save(`${inv.id}-${inv.customer.replace(/\s+/g, "-")}.pdf`);
    toast.success("PDF downloaded");
  };

  const emailInvoice = (inv: Invoice) => {
    if (!customerEmail) return toast.error("Customer has no email on file");
    downloadPdf(inv);
    const vars = buildVars(company, { invoice_id: inv.id, customer_name: inv.customer, amount: inv.amount.toFixed(2), due_date: inv.due });
    openMailto(customerEmail, interpolate(docs.invoiceEmailSubject, vars), interpolate(docs.invoiceEmailBody, vars));
    update("invoices", inv.id, { status: "Sent" });
    toast.success("Email drafted — attach the PDF that just downloaded");
  };

  const markSent = () => {
    update("invoices", invoice.id, { status: "Sent" });
    logActivity({ actor: "You", entity: "invoice", entityId: invoice.id, action: "sent", summary: `${invoice.id} · ${money(invoice.amount)}` });
    fireEvent({ trigger: "invoice.approved", payload: { id: invoice.id, customer: invoice.customer, amount: invoice.amount, phone: customerPhone ?? "" } });
    toast.success("Invoice marked as sent");
  };

  const deleteInvoice = () => {
    if (!confirm(`Delete invoice ${invoice.id}?`)) return;
    remove("invoices", invoice.id);
    toast.success("Invoice removed");
    navigate({ to: "/invoices" });
  };

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="w-fit"><Link to="/invoices"><ArrowLeft className="mr-2 h-4 w-4" /> All invoices</Link></Button>
      <PageHeader
        title={`Invoice ${invoice.id}`}
        description={`${invoice.customer} · ${money(invoice.amount)}`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className={tone(invoice.status)}>{invoice.status}</Badge>
            <Button variant="outline" size="sm" onClick={() => downloadPdf(invoice)}><Download className="mr-2 h-4 w-4" /> PDF</Button>
            <Button variant="outline" size="sm" onClick={() => emailInvoice(invoice)}><Mail className="mr-2 h-4 w-4" /> Email</Button>
            <Button asChild variant="outline" size="sm"><Link to="/invoices/$id/edit" params={{ id: invoice.id }}><Edit className="mr-2 h-4 w-4" /> Edit</Link></Button>
            <Button variant="destructive" size="sm" onClick={deleteInvoice}><Trash2 className="mr-2 h-4 w-4" /> Delete</Button>
          </div>
        }
      />

      <div className="grid gap-4 md:grid-cols-3">
        <Metric label="Amount due" value={money(invoice.amount)} />
        <Metric label="Issued" value={invoice.issued} icon={<CalendarDays className="h-4 w-4" />} />
        <Metric label="Due" value={invoice.due} icon={<CalendarDays className="h-4 w-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
        <Card>
          <CardHeader><CardTitle className="font-display text-base">Invoice preview</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-hidden rounded-lg border bg-background shadow-sm">
              <div className="bg-primary px-6 py-5 text-primary-foreground">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img src="/tsquare-logo.png" alt="" className="h-11 w-auto object-contain" />
                    <div>
                      <div className="font-display text-xl font-bold leading-tight">{company.name}</div>
                      <div className="mt-0.5 text-xs opacity-90">{[company.email, company.phone, company.website].filter(Boolean).join(" · ")}</div>
                    </div>
                  </div>
                  <div className="text-right"><div className="font-display text-2xl font-bold tracking-wide">INVOICE</div><div className="text-sm opacity-90">{invoice.id}</div></div>
                </div>
              </div>
              <div className="h-0.5 w-full bg-secondary" />

              <div className="grid gap-6 p-6 md:grid-cols-2">
                <div>
                  <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Bill to</div>
                  <div className="font-semibold">{invoice.customer}</div>
                  <div className="text-sm text-muted-foreground">{customerEmail || "No email"}</div>
                  <div className="text-sm text-muted-foreground">{customerPhone || "No phone"}</div>
                  <div className="text-sm text-muted-foreground">{customerAddress || "No address"}</div>
                </div>
                <div className="rounded-lg bg-primary-soft p-4 text-sm">
                  <PreviewMeta label="Issued" value={invoice.issued} />
                  <PreviewMeta label="Due" value={invoice.due} />
                  <PreviewMeta label="Status" value={invoice.status} />
                </div>
              </div>
              <div className="px-6 pb-6">
                <Table>
                  <TableHeader><TableRow><TableHead>Description</TableHead><TableHead className="text-right">Qty</TableHead><TableHead className="text-right">Rate</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                  <TableBody>{displayItems.map((it, i) => (<TableRow key={i}><TableCell>{it.description}</TableCell><TableCell className="text-right">{it.qty}</TableCell><TableCell className="text-right">{money(it.rate)}</TableCell><TableCell className="text-right font-semibold">{money(it.qty * it.rate)}</TableCell></TableRow>))}</TableBody>
                </Table>
                <div className="mt-6 flex justify-end"><div className="rounded-lg bg-primary px-5 py-3 text-primary-foreground"><div className="text-xs font-semibold uppercase opacity-90">Total due</div><div className="font-display text-2xl font-bold">{money(invoice.amount)}</div></div></div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="font-display text-base">Controls</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div><div className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Status</div><Select value={invoice.status} onValueChange={(v) => update("invoices", invoice.id, { status: v as InvoiceStatus })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
              <Button className="w-full" onClick={markSent}><Send className="mr-2 h-4 w-4" /> Mark sent</Button>
              <Separator />
              <Info icon={<Mail className="h-4 w-4" />} text={customerEmail || "No email"} />
              <Info icon={<Phone className="h-4 w-4" />} text={customerPhone || "No phone"} />
              <Info icon={<MapPin className="h-4 w-4" />} text={customerAddress || "No address"} />
              {customer && <Button asChild variant="outline" size="sm" className="w-full"><Link to="/customers/$id" params={{ id: customer.id }}>Open customer page</Link></Button>}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value, icon }: { label: string; value: string; icon?: ReactNode }) {
  return <Card><CardContent className="p-4"><div className="mb-2 flex items-center gap-2 text-xs uppercase text-muted-foreground">{icon}{label}</div><div className="font-display text-2xl font-bold">{value}</div></CardContent></Card>;
}

function PreviewMeta({ label, value }: { label: string; value: string }) {
  return <div className="flex items-center justify-between gap-3 py-1"><span className="font-semibold uppercase text-muted-foreground">{label}</span><span>{value}</span></div>;
}

function Info({ icon, text }: { icon: ReactNode; text: string }) {
  return <div className="flex items-start gap-2 text-sm text-muted-foreground"><span className="mt-0.5">{icon}</span><span className="break-words">{text}</span></div>;
}