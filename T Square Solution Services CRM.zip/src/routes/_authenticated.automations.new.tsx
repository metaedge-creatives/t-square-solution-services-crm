import { createFileRoute } from "@tanstack/react-router";
import { AutomationForm } from "@/components/automation-form";

export const Route = createFileRoute("/_authenticated/automations/new")({
  component: () => <AutomationForm />,
});
