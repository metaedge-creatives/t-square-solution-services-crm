import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowLeft, CalendarDays, Clock, DollarSign, Edit, FileText, Mail, MapPin, Phone, Trash2, UserRound } from "lucide-react";
import type { ReactNode } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";
import { newId, type Booking, useStore } from "@/lib/data-store";

export const Route = createFileRoute("/_authenticated/bookings/$id")({
  component: BookingDetailPage,
});

const STATUSES = ["Scheduled", "In progress", "Completed", "Cancelled"];

function statusTone(status: string) {
  if (status === "Completed") return "bg-success/20 text-success-foreground";
  if (status === "Cancelled") return "bg-destructive/15 text-destructive";
  if (status === "In progress") return "bg-amber-100 text-amber-800";
  return "bg-primary-soft text-primary";
}

function money(value?: number) {
  return `$${(value ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function BookingDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { bookings, customers, services, invoices, contracts, update, remove, add } = useStore();
  const booking = bookings.find((b) => b.id === id);

  if (!booking) {
    return (
      <div className="space-y-4">
        <Button asChild variant="ghost" size="sm" className="w-fit">
          <Link to="/bookings"><ArrowLeft className="mr-2 h-4 w-4" /> All bookings</Link>
        </Button>
        <Card><CardContent className="p-10 text-center text-sm text-muted-foreground">Booking not found.</CardContent></Card>
      </div>
    );
  }

  const customer = customers.find((c) => c.name === booking.customer || c.email === booking.email);
  const service = services.find((s) => s.name === booking.service);
  const relatedInvoices = invoices.filter((i) => i.notes?.includes(`booking:${booking.id}`) || i.customer === booking.customer);
  const relatedContracts = contracts.filter((c) => c.customer === booking.customer);

  const changeStatus = (next: string) => {
    update("bookings", booking.id, { status: next });
    logActivity({ actor: "You", entity: "booking", entityId: booking.id, action: "status", summary: `${booking.customer}: ${next}` });
    if (next === "Completed" && booking.status !== "Completed") {
      const already = invoices.some((i) => i.notes?.includes(`booking:${booking.id}`));
      if (!already) {
        const today = new Date().toISOString().slice(0, 10);
        const due = new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10);
        add("invoices", {
          id: newId("inv"),
          customer: booking.customer,
          amount: booking.price ?? service?.basePrice ?? 0,
          issued: today,
          due,
          status: "Pending Approval",
          email: booking.email ?? customer?.email,
          phone: booking.phone ?? customer?.phone,
          address: booking.address ?? customer?.address,
          service: booking.service,
          notes: `Auto-generated from booking:${booking.id}`,
        });
      }
      fireEvent({ trigger: "booking.completed", payload: { id: booking.id, customer: booking.customer, service: booking.service, date: booking.date, phone: booking.phone ?? customer?.phone ?? "" } });
      toast.success("Job completed — invoice queued for approval");
    } else {
      toast.success("Booking updated");
    }
  };

  const deleteBooking = (b: Booking) => {
    if (!confirm(`Delete booking for ${b.customer}?`)) return;
    remove("bookings", b.id);
    toast.success("Booking removed");
    navigate({ to: "/bookings" });
  };

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm" className="w-fit">
        <Link to="/bookings"><ArrowLeft className="mr-2 h-4 w-4" /> All bookings</Link>
      </Button>

      <PageHeader
        title={`Booking ${booking.id}`}
        description={`${booking.service} for ${booking.customer}`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className={statusTone(booking.status)}>{booking.status}</Badge>
            <Button asChild variant="outline" size="sm"><Link to="/bookings/$id/edit" params={{ id: booking.id }}><Edit className="mr-2 h-4 w-4" /> Edit</Link></Button>
            <Button variant="destructive" size="sm" onClick={() => deleteBooking(booking)}><Trash2 className="mr-2 h-4 w-4" /> Delete</Button>
          </div>
        }
      />

      <div className="grid gap-4 md:grid-cols-3">
        <SummaryCard icon={<CalendarDays className="h-4 w-4" />} label="Service date" value={booking.date} detail={booking.time} />
        <SummaryCard icon={<UserRound className="h-4 w-4" />} label="Assigned to" value={booking.assignee} detail={booking.status} />
        <SummaryCard icon={<DollarSign className="h-4 w-4" />} label="Job value" value={money(booking.price ?? service?.basePrice)} detail={booking.orderId ? `Order ${booking.orderId}` : "Manual booking"} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader><CardTitle className="font-display text-base">Customer</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <div className="text-lg font-semibold">{booking.customer}</div>
            <InfoLine icon={<Mail className="h-4 w-4" />} value={booking.email ?? customer?.email ?? "No email"} />
            <InfoLine icon={<Phone className="h-4 w-4" />} value={booking.phone ?? customer?.phone ?? "No phone"} />
            <InfoLine icon={<MapPin className="h-4 w-4" />} value={booking.address ?? customer?.address ?? "No address"} />
            {customer && <Button asChild variant="outline" size="sm" className="w-full"><Link to="/customers/$id" params={{ id: customer.id }}>Open customer page</Link></Button>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="font-display text-base">Job details</CardTitle></CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <Detail label="Service" value={booking.service} />
              <Detail label="Time" value={booking.time} />
              <Detail label="Assignee" value={booking.assignee} />
              <Detail label="Price" value={money(booking.price ?? service?.basePrice)} />
            </div>
            <Separator />
            <div>
              <div className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Status</div>
              <Select value={booking.status} onValueChange={changeStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {booking.notes && <p className="rounded-md bg-muted/40 p-3 text-muted-foreground">{booking.notes}</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="font-display text-base">Related documents</CardTitle></CardHeader>
          <CardContent className="space-y-3 text-sm">
            <DocumentList title="Invoices" items={relatedInvoices.map((i) => ({ id: i.id, text: `${i.status} · ${money(i.amount)}`, to: "/invoices/$id" as const }))} />
            <DocumentList title="Contracts" items={relatedContracts.map((c) => ({ id: c.id, text: `${c.status} · ${money(c.amount)}`, to: "/contracts/$id" as const }))} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function SummaryCard({ icon, label, value, detail }: { icon: ReactNode; label: string; value: string; detail: string }) {
  return <Card><CardContent className="p-4"><div className="mb-2 flex items-center gap-2 text-xs uppercase text-muted-foreground">{icon}{label}</div><div className="font-display text-xl font-bold">{value}</div><div className="text-xs text-muted-foreground">{detail}</div></CardContent></Card>;
}

function InfoLine({ icon, value }: { icon: ReactNode; value: string }) {
  return <div className="flex items-start gap-2 text-muted-foreground"><span className="mt-0.5">{icon}</span><span className="min-w-0 break-words">{value}</span></div>;
}

function Detail({ label, value }: { label: string; value: string }) {
  return <div><div className="text-xs font-semibold uppercase text-muted-foreground">{label}</div><div className="font-medium">{value}</div></div>;
}

function DocumentList({ title, items }: { title: string; items: Array<{ id: string; text: string; to: "/invoices/$id" | "/contracts/$id" }> }) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground"><FileText className="h-3.5 w-3.5" />{title}</div>
      {items.length === 0 ? <p className="text-xs text-muted-foreground">None yet</p> : items.map((item) => (
        <Button key={item.id} asChild variant="outline" size="sm" className="mb-2 w-full justify-between">
          <Link to={item.to} params={{ id: item.id }}><span>{item.id}</span><span>{item.text}</span></Link>
        </Button>
      ))}
    </div>
  );
}