import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Plus, Trash2, Pencil, Download, Mail, FileSignature, Eye, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useStore, type Contract, type ContractStatus } from "@/lib/data-store";
import { useCompanyProfile, useDocTemplates, interpolate, buildVars, assembleContract } from "@/lib/company-profile";
import { renderContractPdf, openMailto } from "@/lib/pdf";
import { downloadCsv } from "@/lib/export";

export const Route = createFileRoute("/_authenticated/contracts/")({
  component: ContractsPage,
});

const STATUSES: ContractStatus[] = ["Draft", "Sent", "Signed", "Expired"];

const tone = (s: ContractStatus) => {
  switch (s) {
    case "Signed": return "bg-success/20 text-success-foreground";
    case "Expired": return "bg-destructive/15 text-destructive";
    case "Draft": return "bg-muted text-muted-foreground";
    default: return "bg-secondary/40 text-secondary-foreground";
  }
};

const today = () => new Date().toISOString().slice(0, 10);

function ContractsPage() {
  const { contracts, update, remove } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const navigate = useNavigate();
  const [preview, setPreview] = useState<Contract | null>(null);

  const downloadPdf = async (c: Contract) => {
    const doc = await renderContractPdf(
      {
        id: c.id,
        customer: c.customer,
        customerEmail: c.customerEmail,
        service: c.service,
        amount: c.amount,
        startDate: c.startDate,
        endDate: c.endDate,
        body: c.body,
      },
      company,
      docs,
    );
    doc.save(`${c.id}-${c.customer.replace(/\s+/g, "-")}.pdf`);
    toast.success("PDF downloaded");
  };

  const sendEmail = (c: Contract) => {
    if (!c.customerEmail) return toast.error("Add a customer email first");
    downloadPdf(c);
    const vars = buildVars(company, {
      contract_id: c.id,
      customer_name: c.customer,
      customer_email: c.customerEmail,
      service: c.service,
      amount: c.amount.toFixed(2),
      start_date: c.startDate,
      end_date: c.endDate,
    });
    openMailto(c.customerEmail, interpolate(docs.contractEmailSubject, vars), interpolate(docs.contractEmailBody, vars));
    update("contracts", c.id, { status: "Sent", sentAt: today() });
    toast.success("Email drafted — attach the PDF that just downloaded");
  };

  const previewText = useMemo(() => {
    if (!preview) return "";
    const vars = buildVars(company, {
      contract_id: preview.id,
      customer_name: preview.customer,
      customer_email: preview.customerEmail ?? "",
      service: preview.service,
      amount: preview.amount.toFixed(2),
      start_date: preview.startDate,
      end_date: preview.endDate,
    });
    return assembleContract(docs, vars, preview.body);
  }, [preview, company, docs]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Contracts"
        description="Service agreements — generate a PDF from the shared template and email it to your client in one click."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => { downloadCsv("contracts", contracts); toast.success("Exported"); }}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={() => navigate({ to: "/contracts/new" })}>
              <Plus className="mr-2 h-4 w-4" /> New contract
            </Button>
          </>
        }
      />

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Contract #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Term</TableHead>
                  <TableHead className="text-right">Value</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {contracts.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium"><Link to="/contracts/$id" params={{ id: c.id }} className="text-primary hover:underline">{c.id}</Link></TableCell>
                    <TableCell>
                      <div>{c.customer}</div>
                      <div className="text-xs text-muted-foreground">{c.customerEmail}</div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{c.service}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{c.startDate} → {c.endDate}</TableCell>
                    <TableCell className="text-right font-display font-semibold">${c.amount.toLocaleString()}</TableCell>
                    <TableCell>
                      <Select value={c.status} onValueChange={(v) => update("contracts", c.id, { status: v as ContractStatus })}>
                        <SelectTrigger className="h-8 w-32">
                          <Badge variant="secondary" className={tone(c.status)}>{c.status}</Badge>
                        </SelectTrigger>
                        <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button asChild variant="ghost" size="icon" title="Open contract page"><Link to="/contracts/$id" params={{ id: c.id }}><Eye className="h-4 w-4" /></Link></Button>
                      <Button variant="ghost" size="icon" title="Quick preview" onClick={() => setPreview(c)}><FileSignature className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" title="Download PDF" onClick={() => downloadPdf(c)}><Download className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" title="Email to client" onClick={() => sendEmail(c)}><Mail className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" title="Edit" onClick={() => navigate({ to: "/contracts/$id/edit", params: { id: c.id } })}><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => { remove("contracts", c.id); toast.success("Removed"); }}><Trash2 className="h-4 w-4" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
                {contracts.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">
                      <FileSignature className="mx-auto mb-2 h-6 w-6 opacity-50" />
                      No contracts yet. Create one — it'll use the template you edit in Settings → Documents.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {preview && (
        <Card>
          <CardContent className="p-6">
            <div className="mb-3 flex items-center justify-between">
              <div className="font-display text-lg font-semibold">Preview — {preview.id}</div>
              <Button variant="ghost" size="icon" onClick={() => setPreview(null)}><X className="h-4 w-4" /></Button>
            </div>
            <div className="max-h-[60vh] overflow-y-auto rounded-md border bg-muted/30 p-4 font-mono text-xs whitespace-pre-wrap">
              {previewText}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
