import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowUpRight, CalendarDays, DollarSign, Target, Users, Plus, Download, Sparkles } from "lucide-react";
import { lazy, Suspense, useMemo } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useStore } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";
import { activity } from "@/lib/mock-data";

const RevenueChart = lazy(() =>
  import("@/components/dashboard-charts").then((m) => ({ default: m.RevenueChart })),
);
const ServicesBarChart = lazy(() =>
  import("@/components/dashboard-charts").then((m) => ({ default: m.ServicesBarChart })),
);

const ChartFallback = () => <div className="h-full w-full animate-pulse rounded-md bg-muted/40" />;

export const Route = createFileRoute("/_authenticated/dashboard")({
  component: DashboardPage,
});

function DashboardPage() {
  const navigate = useNavigate();
  const { customers, leads, bookings, invoices, services } = useStore();

  const outstanding = useMemo(() => invoices.filter((i) => i.status !== "Paid"), [invoices]);
  const revenue = useMemo(
    () => invoices.filter((i) => i.status === "Paid").reduce((s, i) => s + i.amount, 0),
    [invoices],
  );
  const openLeads = leads.filter((l) => l.stage !== "Won" && l.stage !== "Lost").length;
  const todayJobs = bookings.slice(0, 4);

  const jobsByService = useMemo(() => {
    const map = new Map<string, number>();
    for (const b of bookings) map.set(b.service, (map.get(b.service) ?? 0) + 1);
    // include catalog services with 0 for context
    for (const s of services) if (!map.has(s.name)) map.set(s.name, 0);
    return Array.from(map.entries()).map(([service, jobs]) => ({ service, jobs }));
  }, [bookings, services]);

  const stats = [
    { label: "Paid revenue", value: `$${revenue.toLocaleString()}`, change: `${invoices.filter((i) => i.status === "Paid").length} invoices`, icon: DollarSign, tone: "text-success" },
    { label: "Active customers", value: customers.length, change: `${customers.length}`, icon: Users, tone: "text-primary" },
    { label: "Open leads", value: openLeads, change: `${leads.length} total`, icon: Target, tone: "text-secondary-foreground" },
    { label: "Bookings", value: bookings.length, change: `${bookings.filter((b) => b.status === "Scheduled").length} scheduled`, icon: CalendarDays, tone: "text-primary" },
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        description="The pulse of your operation — jobs, revenue and things that need a nudge."
        actions={
          <>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                downloadCsv("dashboard-invoices", invoices);
                toast.success("Exported invoices as CSV");
              }}
            >
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={() => navigate({ to: "/bookings" })}>
              <Plus className="mr-2 h-4 w-4" /> New booking
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="overflow-hidden">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{s.label}</div>
                    <div className="mt-2 font-display text-2xl font-bold text-foreground">{s.value}</div>
                  </div>
                  <div className={`rounded-xl bg-primary-soft p-2 ${s.tone}`}><Icon className="h-5 w-5" /></div>
                </div>
                <div className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-success">
                  <ArrowUpRight className="h-3 w-3" /> {s.change}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-start justify-between space-y-0">
            <div>
              <CardTitle className="font-display">Revenue trend</CardTitle>
              <CardDescription>Historical last 6 months</CardDescription>
            </div>
            <Badge variant="secondary" className="bg-secondary/40 text-secondary-foreground">+18% YoY</Badge>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Suspense fallback={<ChartFallback />}>
                <RevenueChart />
              </Suspense>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-display">Bookings by service</CardTitle>
            <CardDescription>From your live booking data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <Suspense fallback={<ChartFallback />}>
                <ServicesBarChart data={jobsByService} />
              </Suspense>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <div>
              <CardTitle className="font-display">Today's schedule</CardTitle>
              <CardDescription>Assigned crews & jobs</CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={() => navigate({ to: "/bookings" })}>View all</Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {todayJobs.map((job) => (
              <div key={job.id} className="flex items-center gap-4 rounded-xl border bg-card p-3 transition hover:border-primary/50">
                <div className="flex h-12 w-14 flex-col items-center justify-center rounded-lg bg-primary-soft text-primary">
                  <span className="text-[10px] font-semibold uppercase">{new Date(job.date).toLocaleString("en", { month: "short" })}</span>
                  <span className="font-display text-lg font-bold leading-none">{job.date.slice(-2)}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium text-foreground">{job.customer}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">{job.time} · {job.service}</div>
                </div>
                <div className="hidden items-center gap-2 sm:flex">
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="bg-secondary/50 text-[10px] text-secondary-foreground">
                      {job.assignee.split(" ").map((p) => p[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-muted-foreground">{job.assignee}</span>
                </div>
                <Badge variant="secondary" className="bg-muted text-foreground">{job.status}</Badge>
              </div>
            ))}
            {todayJobs.length === 0 && <div className="p-4 text-center text-sm text-muted-foreground">No bookings.</div>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-display">Attention</CardTitle>
            <CardDescription>Invoices needing a follow-up</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {outstanding.slice(0, 5).map((inv) => (
              <div key={inv.id} className="flex items-center justify-between gap-3 rounded-xl border bg-card p-3">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{inv.customer}</div>
                  <div className="text-xs text-muted-foreground">{inv.id} · due {inv.due}</div>
                </div>
                <div className="text-right">
                  <div className="font-display text-sm font-semibold">${inv.amount.toLocaleString()}</div>
                  <Badge variant="secondary" className={inv.status === "Overdue" ? "bg-destructive/15 text-destructive" : "bg-secondary/40 text-secondary-foreground"}>
                    {inv.status}
                  </Badge>
                </div>
              </div>
            ))}
            {outstanding.length === 0 && <div className="p-3 text-center text-sm text-muted-foreground">All paid up!</div>}
            <Button variant="outline" size="sm" className="w-full" onClick={() => toast.success("Reminders sent")}>
              <Sparkles className="mr-2 h-4 w-4" /> Send reminders
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-display">Activity</CardTitle>
          <CardDescription>What your team has been up to</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="divide-y">
            {activity.map((a) => (
              <li key={a.id} className="flex items-center gap-3 py-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary/10 text-xs text-primary">
                    {a.who.split(" ").map((p) => p[0]).join("").slice(0, 2)}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1 text-sm">
                  <span className="font-medium text-foreground">{a.who}</span>{" "}
                  <span className="text-muted-foreground">{a.what}</span>
                </div>
                <span className="text-xs text-muted-foreground">{a.when}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
