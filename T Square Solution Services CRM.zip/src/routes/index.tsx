import { createFileRoute, Navigate } from "@tanstack/react-router";

import { getStoredUser } from "@/lib/auth";

export const Route = createFileRoute("/")({
  ssr: false,
  component: IndexRedirect,
});

function IndexRedirect() {
  const user = getStoredUser();
  return <Navigate to={user ? "/dashboard" : "/login"} replace />;
}
