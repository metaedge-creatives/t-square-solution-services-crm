import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Plus, Trash2, Zap } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { readRules, writeRules, type AutomationRule, type TriggerType, type ActionType } from "@/lib/automations";

export const Route = createFileRoute("/_authenticated/automations/")({
  component: AutomationsPage,
});

const TRIGGERS: { value: TriggerType; label: string }[] = [
  { value: "booking.created", label: "When a booking is created" },
  { value: "booking.completed", label: "When a booking is completed" },
  { value: "invoice.created", label: "When an invoice is created" },
  { value: "invoice.approved", label: "When an invoice is approved" },
  { value: "invoice.paid", label: "When an invoice is paid" },
  { value: "contract.sent", label: "When a contract is sent" },
  { value: "customer.created", label: "When a new customer is added" },
  { value: "lead.created", label: "When a new lead comes in" },
];
const ACTIONS: { value: ActionType; label: string }[] = [
  { value: "send_email", label: "Send an email" },
  { value: "log", label: "Log to activity feed" },
];

function AutomationsPage() {
  const [rules, setRules] = useState<AutomationRule[]>([]);
  const navigate = useNavigate();

  useEffect(() => { setRules(readRules()); }, []);
  const persist = (list: AutomationRule[]) => { setRules(list); writeRules(list); };

  const openNew = () => navigate({ to: "/automations/new" });
  const openEdit = (r: AutomationRule) => navigate({ to: "/automations/$id/edit", params: { id: r.id } });
  const toggle = (r: AutomationRule) => persist(rules.map((x) => x.id === r.id ? { ...x, enabled: !x.enabled } : x));
  const del = (r: AutomationRule) => { persist(rules.filter((x) => x.id !== r.id)); toast.success("Removed"); };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Automations"
        description="Send emails automatically when things happen in the CRM."
        actions={<Button size="sm" onClick={openNew}><Plus className="mr-2 h-4 w-4" /> New rule</Button>}
      />

      <div className="grid gap-3">
        {rules.length === 0 && (
          <Card>
            <CardContent className="p-10 text-center">
              <Zap className="mx-auto mb-3 h-8 w-8 text-primary" />
              <div className="font-display text-lg font-semibold">No automations yet</div>
              <p className="mt-1 text-sm text-muted-foreground">Create your first rule to save hours every week.</p>
              <Button className="mt-4" onClick={openNew}><Plus className="mr-2 h-4 w-4" /> Create rule</Button>
            </CardContent>
          </Card>
        )}
        {rules.map((r) => (
          <Card key={r.id}>
            <CardContent className="flex flex-wrap items-center gap-4 p-4">
              <div className="rounded-lg bg-primary-soft p-2 text-primary"><Zap className="h-5 w-5" /></div>
              <div className="min-w-0 flex-1">
                <div className="font-medium">{r.name}</div>
                <div className="text-xs text-muted-foreground">
                  {TRIGGERS.find((t) => t.value === r.trigger)?.label} → {ACTIONS.find((a) => a.value === r.action)?.label}
                </div>
              </div>
              <Switch checked={r.enabled} onCheckedChange={() => toggle(r)} />
              <Button variant="outline" size="sm" onClick={() => openEdit(r)}>Edit</Button>
              <Button variant="ghost" size="icon" onClick={() => del(r)}><Trash2 className="h-4 w-4" /></Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
