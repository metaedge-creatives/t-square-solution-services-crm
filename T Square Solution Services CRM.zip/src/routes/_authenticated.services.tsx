import { createFileRoute } from "@tanstack/react-router";
import { CalendarIcon, Minus, Plus, Sparkles, Pencil, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { format } from "date-fns";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import {
  useStore,
  newId,
  type Service,
  type ServiceOption,
} from "@/lib/data-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/services")({
  component: ServicesPage,
});

const emptyForm = {
  name: "",
  tagline: "",
  basePrice: 0,
  unit: "/ visit",
  color: "bg-primary/10 text-primary",
};

function ServicesPage() {
  const { services, bookings, add, update, remove } = useStore();
  const dlg = useDialogState<Service>();
  const [form, setForm] = useState(emptyForm);

  const openNew = () => {
    setForm(emptyForm);
    dlg.openCreate();
  };
  const openEdit = (s: Service) => {
    setForm({
      name: s.name,
      tagline: s.tagline ?? "",
      basePrice: s.basePrice,
      unit: s.unit,
      color: s.color,
    });
    dlg.openEdit(s);
  };
  const submit = () => {
    if (!form.name.trim()) return toast.error("Name is required");
    if (dlg.editing) {
      update("services", dlg.editing.id, { ...form });
      toast.success("Service updated");
    } else {
      add("services", {
        id: newId("s"),
        ...form,
        options: [{ name: form.name, price: form.basePrice }],
        addOns: [],
      });
      toast.success("Service added");
    }
    dlg.close();
  };

  const book = (payload: {
    service: Service;
    option: ServiceOption;
    addOns: ServiceOption[];
    date: Date;
    quantity: number;
    total: number;
  }) => {
    const label =
      payload.addOns.length > 0
        ? `${payload.service.name} — ${payload.option.name} (+${payload.addOns.length} add-on${payload.addOns.length > 1 ? "s" : ""})`
        : `${payload.service.name} — ${payload.option.name}`;
    add("bookings", {
      id: newId("b"),
      customer: "Website booking",
      service: label,
      date: format(payload.date, "yyyy-MM-dd"),
      time: "09:00",
      assignee: "Unassigned",
      status: "Pending",
    });
    toast.success(
      `Booked ${payload.service.name} · $${payload.total.toFixed(2)} · ${format(payload.date, "PP")}`,
    );
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Services"
        description="Your live service catalog. Customers can pick an option, add-ons, a date, and book — all totals flow into bookings."
        actions={
          <Button size="sm" onClick={openNew}>
            <Plus className="mr-2 h-4 w-4" /> New service
          </Button>
        }
      />

      <div className="text-xs text-muted-foreground">
        {bookings.length} booking{bookings.length === 1 ? "" : "s"} in the pipeline
      </div>

      <div className="grid gap-5 lg:grid-cols-2 xl:grid-cols-3">
        {services.map((s) => (
          <ServiceBookingCard
            key={s.id}
            service={s}
            onEdit={() => openEdit(s)}
            onRemove={() => {
              remove("services", s.id);
              toast.success("Removed");
            }}
            onBook={book}
          />
        ))}
      </div>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit service" : "New service"}
        onSubmit={submit}
      >
        <div>
          <Label>Service name</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div>
          <Label>Tagline</Label>
          <Input
            value={form.tagline}
            onChange={(e) => setForm({ ...form, tagline: e.target.value })}
            placeholder="Custom Contracts Available"
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Base price ($)</Label>
            <Input
              type="number"
              min={0}
              value={form.basePrice}
              onChange={(e) => setForm({ ...form, basePrice: Number(e.target.value) || 0 })}
            />
          </div>
          <div>
            <Label>Unit</Label>
            <Input
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
              placeholder="/ visit"
            />
          </div>
        </div>
      </EntityDialog>
    </div>
  );
}

interface BookingCardProps {
  service: Service;
  onEdit: () => void;
  onRemove: () => void;
  onBook: (p: {
    service: Service;
    option: ServiceOption;
    addOns: ServiceOption[];
    date: Date;
    quantity: number;
    total: number;
  }) => void;
}

function ServiceBookingCard({ service, onEdit, onRemove, onBook }: BookingCardProps) {
  const options = service.options ?? [{ name: service.name, price: service.basePrice }];
  const addOns = service.addOns ?? [];
  const [selectedName, setSelectedName] = useState<string>(options[0]?.name ?? "");
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [date, setDate] = useState<Date | undefined>();
  const [qty, setQty] = useState(1);

  const selectedOption =
    options.find((o) => o.name === selectedName) ?? options[0];
  const activeAddOns = addOns.filter((a) => selectedAddOns.includes(a.name));
  const addOnTotal = activeAddOns.reduce((sum, a) => sum + a.price, 0);
  const total = useMemo(
    () => (selectedOption.price + addOnTotal) * qty,
    [selectedOption.price, addOnTotal, qty],
  );

  const toggleAddOn = (name: string) => {
    setSelectedAddOns((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name],
    );
  };

  const handleBook = () => {
    if (!date) return toast.error("Please choose a booking date");
    if (!selectedOption) return toast.error("Please select an option");
    onBook({ service, option: selectedOption, addOns: activeAddOns, date, quantity: qty, total });
  };

  return (
    <Card className="group flex flex-col overflow-hidden transition hover:border-primary/50 hover:shadow-md">
      <CardContent className="flex flex-1 flex-col gap-4 p-5">
        <div className="flex items-start justify-between">
          <div className={`rounded-xl p-2.5 ${service.color}`}>
            <Sparkles className="h-5 w-5" />
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="sm" onClick={onEdit}>
              <Pencil className="h-3.5 w-3.5" />
            </Button>
            <Button variant="ghost" size="sm" onClick={onRemove}>
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>

        <div>
          <div className="font-display text-lg font-semibold">{service.name}</div>
          {service.tagline ? (
            <p className="mt-1 text-xs text-muted-foreground">{service.tagline}</p>
          ) : null}
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">Select an Option</Label>
          <Select value={selectedName} onValueChange={setSelectedName}>
            <SelectTrigger>
              <SelectValue placeholder="Choose an option" />
            </SelectTrigger>
            <SelectContent>
              {options.map((o) => (
                <SelectItem key={o.name} value={o.name}>
                  {o.name} — ${o.price.toFixed(2)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {addOns.length > 0 ? (
          <div className="space-y-1.5">
            <Label className="text-xs">Add-On Services</Label>
            <div className="grid grid-cols-1 gap-1.5 rounded-md border p-2 sm:grid-cols-2">
              {addOns.map((a) => {
                const id = `${service.id}-${a.name}`;
                const checked = selectedAddOns.includes(a.name);
                return (
                  <label
                    key={a.name}
                    htmlFor={id}
                    className="flex cursor-pointer items-center justify-between gap-2 rounded px-1.5 py-1 text-xs hover:bg-muted"
                  >
                    <span className="flex items-center gap-2">
                      <Checkbox id={id} checked={checked} onCheckedChange={() => toggleAddOn(a.name)} />
                      <span>{a.name}</span>
                    </span>
                    <span className="text-muted-foreground">+${a.price}</span>
                  </label>
                );
              })}
            </div>
          </div>
        ) : null}

        <div className="space-y-1.5">
          <Label className="text-xs">Choose Booking date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full justify-start text-left font-normal",
                  !date && "text-muted-foreground",
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                initialFocus
                className={cn("p-3 pointer-events-auto")}
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="flex items-center justify-between">
          <Label className="text-xs">Quantity</Label>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-7 w-7"
              onClick={() => setQty((q) => Math.max(1, q - 1))}
            >
              <Minus className="h-3 w-3" />
            </Button>
            <span className="w-6 text-center text-sm font-medium">{qty}</span>
            <Button
              type="button"
              variant="outline"
              size="icon"
              className="h-7 w-7"
              onClick={() => setQty((q) => q + 1)}
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>
        </div>

        <div className="mt-auto rounded-lg border bg-muted/40 p-3">
          <div className="mb-1 flex items-center justify-between text-xs text-muted-foreground">
            <span>Total</span>
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              {selectedOption.name}
            </Badge>
          </div>
          <div className="flex items-baseline justify-between">
            <span className="text-xs text-muted-foreground">
              {qty} × ${(selectedOption.price + addOnTotal).toFixed(2)}
            </span>
            <span className="font-display text-2xl font-bold">${total.toFixed(2)}</span>
          </div>
        </div>

        <Button onClick={handleBook} className="w-full">
          Book Now
        </Button>
      </CardContent>
    </Card>
  );
}
