import { createFileRoute } from "@tanstack/react-router";
import { Plus, Star, Pencil, Trash2, Download } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { useStore, newId, ALL_PERMISSIONS, type Permission, type Staff } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";

export const Route = createFileRoute("/_authenticated/staff")({
  component: StaffPage,
});

const ROLES = ["Owner", "Manager", "Cleaner", "Inspector", "Dispatcher"];
const STATUSES = ["Active", "Time off", "Inactive"];

const PRESET_PERMS: Record<string, Permission[]> = {
  Owner: [...ALL_PERMISSIONS],
  Manager: ["dashboard","customers","leads","bookings","invoices","quotes","contracts","services","inspections","email","reports","activity","staff"],
  Cleaner: ["dashboard","bookings","customers"],
  Inspector: ["dashboard","bookings","inspections","customers"],
  Dispatcher: ["dashboard","bookings","customers","leads","staff"],
};

const emptyForm = {
  name: "",
  email: "",
  role: "Cleaner",
  jobs: 0,
  rating: 5,
  status: "Active",
  permissions: PRESET_PERMS["Cleaner"] as Permission[],
};


function StaffPage() {
  const { staff, add, update, remove } = useStore();
  const dlg = useDialogState<Staff>();
  const [form, setForm] = useState(emptyForm);

  const openNew = () => { setForm(emptyForm); dlg.openCreate(); };
  const openEdit = (s: Staff) => {
    setForm({
      name: s.name, email: s.email, role: s.role, jobs: s.jobs, rating: s.rating, status: s.status,
      permissions: s.permissions ?? PRESET_PERMS[s.role] ?? [],
    });
    dlg.openEdit(s);
  };
  const setRole = (role: string) =>
    setForm((f) => ({ ...f, role, permissions: PRESET_PERMS[role] ?? f.permissions }));
  const togglePerm = (p: Permission) =>
    setForm((f) => ({
      ...f,
      permissions: f.permissions.includes(p)
        ? f.permissions.filter((x) => x !== p)
        : [...f.permissions, p],
    }));
  const submit = () => {
    if (!form.name.trim()) return toast.error("Name is required");
    if (dlg.editing) {
      update("staff", dlg.editing.id, { ...form });
      toast.success("Teammate updated");
    } else {
      add("staff", { id: newId("u"), ...form });
      toast.success("Teammate added");
    }
    dlg.close();
  };


  return (
    <div className="space-y-6">
      <PageHeader
        title="Staff"
        description="Your crew — managers, cleaners, availability and ratings."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => { downloadCsv("staff", staff); toast.success("Exported staff"); }}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> Invite teammate
            </Button>
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {staff.map((s) => (
          <Card key={s.id} className="transition hover:border-primary/50 hover:shadow-md">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="bg-primary text-sm text-primary-foreground">
                    {s.name.split(" ").map((p) => p[0]).join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="font-display font-semibold">{s.name}</div>
                  <div className="text-xs text-muted-foreground">{s.email}</div>
                </div>
                <Badge variant="secondary" className={s.status === "Active" ? "bg-success/20 text-success-foreground" : "bg-muted text-muted-foreground"}>
                  {s.status}
                </Badge>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-muted/50 p-3 text-center">
                <div>
                  <div className="font-display text-sm font-semibold">{s.role}</div>
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Role</div>
                </div>
                <div>
                  <div className="font-display text-sm font-semibold">{s.jobs}</div>
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Jobs</div>
                </div>
                <div>
                  <div className="inline-flex items-center gap-1 font-display text-sm font-semibold">
                    <Star className="h-3.5 w-3.5 fill-secondary text-secondary" /> {s.rating}
                  </div>
                  <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Rating</div>
                </div>
              </div>

              <div className="mt-4 flex justify-end gap-2">
                <Button variant="outline" size="sm" onClick={() => openEdit(s)}>
                  <Pencil className="mr-1.5 h-3.5 w-3.5" /> Edit
                </Button>
                <Button variant="ghost" size="sm" onClick={() => { remove("staff", s.id); toast.success("Removed"); }}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit teammate" : "Invite teammate"}
        onSubmit={submit}
      >
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Name</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <Label>Email</Label>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Role</Label>
            <Select value={form.role} onValueChange={setRole}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Jobs</Label>
            <Input type="number" min={0} value={form.jobs} onChange={(e) => setForm({ ...form, jobs: Number(e.target.value) || 0 })} />
          </div>
          <div>
            <Label>Rating</Label>
            <Input type="number" min={0} max={5} step={0.1} value={form.rating} onChange={(e) => setForm({ ...form, rating: Number(e.target.value) || 0 })} />
          </div>
        </div>
        <div>
          <div className="mb-2 flex items-center justify-between">
            <Label className="text-sm">Permissions</Label>
            <div className="flex gap-2 text-xs">
              <button type="button" className="text-primary hover:underline" onClick={() => setForm((f) => ({ ...f, permissions: [...ALL_PERMISSIONS] }))}>Select all</button>
              <span className="text-muted-foreground">·</span>
              <button type="button" className="text-primary hover:underline" onClick={() => setForm((f) => ({ ...f, permissions: [] }))}>Clear</button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 rounded-lg border p-3 sm:grid-cols-3">
            {ALL_PERMISSIONS.map((p) => (
              <label key={p} className="flex items-center gap-2 text-sm capitalize">
                <input type="checkbox" className="h-4 w-4 accent-primary" checked={form.permissions.includes(p)} onChange={() => togglePerm(p)} />
                {p}
              </label>
            ))}
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">Controls which modules this teammate can open in the CRM.</p>
        </div>
      </EntityDialog>
    </div>
  );
}

