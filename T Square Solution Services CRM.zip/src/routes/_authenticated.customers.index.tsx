import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Plus, Search, Pencil, Trash2, Mail, Phone, Download, Eye, ChevronDown, Upload } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { BulkImportDialog } from "@/components/bulk-import-dialog";
import { useStore, newId, type Customer } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";

export const Route = createFileRoute("/_authenticated/customers/")({
  component: CustomersPage,
});

const TYPES = ["Commercial", "Residential", "Airbnb", "Office"];

const emptyForm = {
  name: "",
  contact: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  zip: "",
  notes: "",
  tags: "",
  type: "Residential",
  jobs: 0,
  lifetime: 0,
  since: new Date().toISOString().slice(0, 10),
};


function CustomersPage() {
  const { customers, add, update, remove } = useStore();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("All");
  const [sortBy, setSortBy] = useState<string>("name");
  const [bulkOpen, setBulkOpen] = useState(false);
  const dlg = useDialogState<Customer>();
  const [form, setForm] = useState(emptyForm);

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    let list = customers.filter((c) => {
      const hay = `${c.name} ${c.contact} ${c.email} ${c.phone} ${c.address ?? ""} ${c.city ?? ""} ${c.zip ?? ""} ${c.tags ?? ""} ${c.notes ?? ""}`.toLowerCase();
      const matchesQuery = !q || hay.includes(q);
      const matchesType = typeFilter === "All" || c.type === typeFilter;
      return matchesQuery && matchesType;
    });
    list = [...list].sort((a, b) => {
      if (sortBy === "ltv") return b.lifetime - a.lifetime;
      if (sortBy === "jobs") return b.jobs - a.jobs;
      if (sortBy === "recent") return (b.since || "").localeCompare(a.since || "");
      return a.name.localeCompare(b.name);
    });
    return list;
  }, [customers, query, typeFilter, sortBy]);

  const openNew = () => {
    setForm(emptyForm);
    dlg.openCreate();
  };
  const openEdit = (c: Customer) => {
    setForm({
      name: c.name,
      contact: c.contact,
      email: c.email,
      phone: c.phone,
      address: c.address ?? "",
      city: c.city ?? "",
      zip: c.zip ?? "",
      notes: c.notes ?? "",
      tags: c.tags ?? "",
      type: c.type,
      jobs: c.jobs,
      lifetime: c.lifetime,
      since: c.since,
    });
    dlg.openEdit(c);
  };
  const submit = () => {
    if (!form.name.trim()) return toast.error("Name is required");
    if (dlg.editing) {
      update("customers", dlg.editing.id, { ...form });
      toast.success("Customer updated");
    } else {
      add("customers", { id: newId("c"), ...form });
      toast.success("Customer added");
    }
    dlg.close();
  };
  const del = (c: Customer) => {
    remove("customers", c.id);
    toast.success("Customer removed");
  };

  const exportRows = (rows: Customer[], label: string) => {
    if (!rows.length) return toast.error("Nothing to export");
    downloadCsv(`customers-${label}`, rows);
    toast.success(`Exported ${rows.length} customers`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Customers"
        description="Your book of business — commercial, residential and short-term rental."
        actions={
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" /> Export <ChevronDown className="ml-1 h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>Export customers</DropdownMenuLabel>
                <DropdownMenuItem onClick={() => exportRows(filtered, "filtered")}>Current view ({filtered.length})</DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportRows(customers, "all")}>All customers ({customers.length})</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuLabel>By type</DropdownMenuLabel>
                {TYPES.map((t) => (
                  <DropdownMenuItem key={t} onClick={() => exportRows(customers.filter((c) => c.type === t), t.toLowerCase())}>
                    {t} ({customers.filter((c) => c.type === t).length})
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="sm" onClick={() => setBulkOpen(true)}>
              <Upload className="mr-2 h-4 w-4" /> Bulk import
            </Button>
            <Button size="sm" onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> Add customer
            </Button>
          </>
        }
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-sm flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search name, email, phone, address, tags…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All types</SelectItem>
              {TYPES.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name (A–Z)</SelectItem>
              <SelectItem value="ltv">Highest LTV</SelectItem>
              <SelectItem value="jobs">Most jobs</SelectItem>
              <SelectItem value="recent">Most recent</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <div className="min-w-[900px]">
              <div className="grid grid-cols-12 border-b bg-muted/50 px-4 py-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                <div className="col-span-3">Customer</div>
                <div className="col-span-2">Contact</div>
                <div className="col-span-3">Email / Phone</div>
                <div className="col-span-1">Type</div>
                <div className="col-span-1 text-right">Jobs</div>
                <div className="col-span-1 text-right">LTV</div>
                <div className="col-span-1 text-right">•</div>
              </div>
              {filtered.map((c) => (
                <div
                  key={c.id}
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate({ to: "/customers/$id", params: { id: c.id } })}
                  onKeyDown={(e) => { if (e.key === "Enter") navigate({ to: "/customers/$id", params: { id: c.id } }); }}
                  className="grid cursor-pointer grid-cols-12 items-center border-b px-4 py-3 text-sm last:border-b-0 hover:bg-muted/40"
                >
                  <div className="col-span-3">
                    <div className="font-medium">{c.name}</div>
                    <div className="text-xs text-muted-foreground">
                      since {c.since ? new Date(c.since).getFullYear() : "—"}
                    </div>
                  </div>
                  <div className="col-span-2 text-muted-foreground">{c.contact}</div>
                  <div className="col-span-3 space-y-0.5 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1.5">
                      <Mail className="h-3 w-3" /> {c.email || "—"}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Phone className="h-3 w-3" /> {c.phone || "—"}
                    </div>
                  </div>
                  <div className="col-span-1">
                    <Badge variant="secondary" className="bg-primary-soft text-primary">
                      {c.type}
                    </Badge>
                  </div>
                  <div className="col-span-1 text-right font-display font-semibold">{c.jobs}</div>
                  <div className="col-span-1 text-right font-display font-semibold">
                    ${c.lifetime.toLocaleString()}
                  </div>
                  <div className="col-span-1 flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                    <Button asChild variant="ghost" size="icon">
                      <Link to="/customers/$id" params={{ id: c.id }}><Eye className="h-4 w-4" /></Link>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => openEdit(c)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => del(c)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {filtered.length === 0 && (
                <div className="p-8 text-center text-sm text-muted-foreground">No customers match your filters.</div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit customer" : "Add customer"}
        onSubmit={submit}
      >
        <div>
          <Label>Business / customer name</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Primary contact</Label>
            <Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} />
          </div>
          <div>
            <Label>Type</Label>
            <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TYPES.map((t) => (
                  <SelectItem key={t} value={t}>
                    {t}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Email</Label>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
          <div>
            <Label>Phone</Label>
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
        </div>
        <div>
          <Label>Address</Label>
          <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label>City</Label>
            <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          </div>
          <div>
            <Label>ZIP</Label>
            <Input value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} />
          </div>
          <div>
            <Label>Tags</Label>
            <Input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} placeholder="vip, weekly" />
          </div>
        </div>
        <div>
          <Label>Notes</Label>
          <Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label>Jobs</Label>
            <Input
              type="number"
              min={0}
              value={form.jobs}
              onChange={(e) => setForm({ ...form, jobs: Number(e.target.value) || 0 })}
            />
          </div>
          <div>
            <Label>Lifetime ($)</Label>
            <Input
              type="number"
              min={0}
              value={form.lifetime}
              onChange={(e) => setForm({ ...form, lifetime: Number(e.target.value) || 0 })}
            />
          </div>
          <div>
            <Label>Since</Label>
            <Input
              type="date"
              value={form.since}
              onChange={(e) => setForm({ ...form, since: e.target.value })}
            />
          </div>
        </div>
      </EntityDialog>

      <BulkImportDialog
        open={bulkOpen}
        onOpenChange={setBulkOpen}
        title="Bulk import customers"
        description="Paste rows from a spreadsheet or upload a CSV. One customer per line."
        fields={[
          { key: "name", label: "Name", required: true },
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
          { key: "address", label: "Address" },
          { key: "city", label: "City" },
          { key: "type", label: "Type" },
          { key: "notes", label: "Notes" },
        ]}
        sampleRow="Bright Cafe, hello@brightcafe.com, 555-8899, 123 Main St, Austin, Commercial, Weekly clean"
        onImport={(rows) => {
          let n = 0;
          for (const r of rows) {
            const type = TYPES.includes(r.type) ? r.type : "Residential";
            add("customers", {
              id: newId("c"),
              name: r.name,
              contact: r.name,
              email: r.email || "",
              phone: r.phone || "",
              address: r.address || "",
              city: r.city || "",
              zip: "",
              notes: r.notes || "",
              tags: "",
              type,
              jobs: 0,
              lifetime: 0,
              since: new Date().toISOString().slice(0, 10),
            });
            n++;
          }
          return n;
        }}
      />
    </div>
  );
}
