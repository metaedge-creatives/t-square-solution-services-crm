import { createFileRoute, Link } from "@tanstack/react-router";
import { InvoiceForm } from "@/components/invoice-form";
import { useStore } from "@/lib/data-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/invoices/$id/edit")({
  component: EditInvoice,
});

function EditInvoice() {
  const { id } = Route.useParams();
  const { invoices } = useStore();
  const inv = invoices.find((i) => i.id === id);
  if (!inv) {
    return (
      <div className="space-y-4">
        <Button asChild variant="ghost" size="sm"><Link to="/invoices"><ArrowLeft className="mr-2 h-4 w-4" /> Back</Link></Button>
        <Card><CardContent className="p-10 text-center text-muted-foreground">Invoice not found.</CardContent></Card>
      </div>
    );
  }
  return <InvoiceForm editing={inv} />;
}
