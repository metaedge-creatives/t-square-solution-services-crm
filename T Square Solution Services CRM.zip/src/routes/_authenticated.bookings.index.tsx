import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Plus, CalendarPlus, Trash2, Pencil, Download, Eye } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, newId, type Booking } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";

export const Route = createFileRoute("/_authenticated/bookings/")({
  component: BookingsPage,
});

const HOURS = Array.from({ length: 13 }, (_, i) => i + 7);
const DAYS = [
  { key: "2026-07-06", label: "Mon 06" },
  { key: "2026-07-07", label: "Tue 07" },
  { key: "2026-07-08", label: "Wed 08" },
  { key: "2026-07-09", label: "Thu 09" },
  { key: "2026-07-10", label: "Fri 10" },
];
const STATUSES = ["Scheduled", "In progress", "Completed", "Cancelled"];

function BookingsPage() {
  const { bookings, customers, services, add, update, remove, invoices } = useStore();
  const navigate = useNavigate();

  const openNew = () => navigate({ to: "/bookings/new" });
  const openDetail = (b: Booking) => navigate({ to: "/bookings/$id", params: { id: b.id } });
  const openEdit = (b: Booking) => navigate({ to: "/bookings/$id/edit", params: { id: b.id } });
  const del = (b: Booking) => { remove("bookings", b.id); toast.success("Booking removed"); };

  const handleStatusChange = (b: Booking, next: string) => {
    update("bookings", b.id, { status: next });
    logActivity({ actor: "You", entity: "booking", entityId: b.id, action: "status", summary: `${b.customer}: ${next}` });
    if (next === "Completed" && b.status !== "Completed") {
      const svc = services.find((s) => s.name === b.service);
      const cust = customers.find((c) => c.name === b.customer);
      const already = invoices.some((i) => i.notes?.includes(`booking:${b.id}`));
      if (!already) {
        const today = new Date().toISOString().slice(0, 10);
        const due = new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10);
        const amount = svc?.basePrice ?? 0;
        add("invoices", {
          id: newId("inv"),
          customer: b.customer,
          amount,
          issued: today,
          due,
          status: "Pending Approval",
          email: cust?.email,
          phone: cust?.phone,
          service: b.service,
          notes: `Auto-generated from booking:${b.id}`,
        });
        toast.success("Job completed — invoice queued for approval");
      } else {
        toast.success("Job marked complete");
      }
      fireEvent({
        trigger: "booking.completed",
        payload: { id: b.id, customer: b.customer, service: b.service, date: b.date, phone: cust?.phone ?? "" },
      });
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Bookings"
        description="Every job on the calendar — drag, reschedule, dispatch."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => { downloadCsv("bookings", bookings); toast.success("Exported bookings"); }}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={openNew}>
              <CalendarPlus className="mr-2 h-4 w-4" /> New booking
            </Button>
          </>
        }
      />

      <Tabs defaultValue="calendar">
        <TabsList>
          <TabsTrigger value="calendar">Week view</TabsTrigger>
          <TabsTrigger value="list">List</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <div className="min-w-[720px]">
                  <div className="grid grid-cols-[64px_repeat(5,minmax(0,1fr))] border-b text-xs font-medium">
                    <div />
                    {DAYS.map((d) => (
                      <div key={d.key} className="border-l p-3 text-center text-muted-foreground">{d.label}</div>
                    ))}
                  </div>
                  <div className="grid grid-cols-[64px_repeat(5,minmax(0,1fr))]">
                    {HOURS.map((h) => (
                      <div key={h} className="contents">
                        <div className="border-b py-3 pr-2 text-right text-[10px] uppercase tracking-wide text-muted-foreground">
                          {h.toString().padStart(2, "0")}:00
                        </div>
                        {DAYS.map((d) => {
                          const jobs = bookings.filter((b) => b.date === d.key && Number(b.time.split(":")[0]) === h);
                          return (
                            <div key={d.key + h} className="min-h-12 border-b border-l p-1">
                              {jobs.map((j) => (
                                <button
                                  key={j.id}
                                  onClick={() => openDetail(j)}
                                  className="w-full rounded-md bg-primary/10 p-1.5 text-left text-[11px] leading-tight text-primary hover:bg-primary/20"
                                >
                                  <div className="font-semibold">{j.customer}</div>
                                  <div className="opacity-80">{j.assignee}</div>
                                </button>
                              ))}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Upcoming</CardTitle>
              <CardDescription>All scheduled jobs across the team</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {bookings.map((b) => (
                <div
                  key={b.id}
                  className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border p-3 sm:flex sm:gap-4"
                >
                  <div className="flex h-12 w-14 shrink-0 flex-col items-center justify-center rounded-lg bg-primary-soft text-primary">
                    <span className="text-[10px] font-semibold uppercase">{new Date(b.date).toLocaleString("en", { month: "short" })}</span>
                    <span className="font-display text-lg font-bold leading-none">{b.date.slice(-2)}</span>
                  </div>
                  <div className="min-w-0 sm:flex-1">
                    <Button asChild variant="link" className="h-auto justify-start p-0 font-medium text-foreground">
                      <Link to="/bookings/$id" params={{ id: b.id }}>{b.customer}</Link>
                    </Button>
                    <div className="truncate text-xs text-muted-foreground">{b.time} · {b.service}</div>
                    <div className="mt-1 flex items-center gap-1.5 sm:hidden">
                      <Avatar className="h-5 w-5">
                        <AvatarFallback className="bg-secondary/50 text-[9px] text-secondary-foreground">
                          {b.assignee.split(" ").map((p) => p[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{b.assignee}</span>
                    </div>
                  </div>
                  <div className="hidden items-center gap-2 sm:flex">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-secondary/50 text-[10px] text-secondary-foreground">
                        {b.assignee.split(" ").map((p) => p[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-xs">{b.assignee}</span>
                  </div>
                  <div className="col-span-3 flex items-center justify-end gap-1 sm:col-auto">
                    <Select value={b.status} onValueChange={(v) => handleStatusChange(b, v)}>
                      <SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger>
                      <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                    <Button asChild variant="ghost" size="icon" title="Open booking page">
                      <Link to="/bookings/$id" params={{ id: b.id }}><Eye className="h-4 w-4" /></Link>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => openEdit(b)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => del(b)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              {bookings.length === 0 && (
                <div className="p-6 text-center text-sm text-muted-foreground">No bookings yet.</div>
              )}
              <Button variant="ghost" size="sm" className="w-full" onClick={openNew}>
                <Plus className="mr-2 h-4 w-4" /> Add booking
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
