import { createFileRoute } from "@tanstack/react-router";
import { Plus, Download, Search, Trash2, Pencil, Upload } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { BulkImportDialog } from "@/components/bulk-import-dialog";
import { useStore, LEAD_STAGES, newId, type Lead, type LeadStage } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";

export const Route = createFileRoute("/_authenticated/leads")({
  component: LeadsPage,
});

const SOURCES = ["Website", "Referral", "Instagram", "Yelp", "Google", "WooCommerce", "Other"];

const emptyForm = {
  name: "",
  contact: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  serviceInterest: "",
  notes: "",
  source: "Website",
  value: 0,
  stage: "New" as LeadStage,
};

function LeadsPage() {
  const { leads, services, add, update, remove, ensureCustomer } = useStore();
  const [query, setQuery] = useState("");
  const [stageFilter, setStageFilter] = useState<LeadStage | "All">("All");
  const [bulkOpen, setBulkOpen] = useState(false);
  const dlg = useDialogState<Lead>();
  const [form, setForm] = useState(emptyForm);

  const filtered = useMemo(
    () => leads.filter((l) => (l.name + l.contact + l.email + (l.phone ?? "")).toLowerCase().includes(query.toLowerCase())),
    [leads, query],
  );

  const stageFiltered = useMemo(
    () => (stageFilter === "All" ? filtered : filtered.filter((l) => l.stage === stageFilter)),
    [filtered, stageFilter],
  );


  const openNew = () => {
    setForm(emptyForm);
    dlg.openCreate();
  };
  const openEdit = (l: Lead) => {
    setForm({
      name: l.name,
      contact: l.contact,
      email: l.email,
      phone: l.phone ?? "",
      address: l.address ?? "",
      city: l.city ?? "",
      serviceInterest: l.serviceInterest ?? "",
      notes: l.notes ?? "",
      source: l.source,
      value: l.value,
      stage: l.stage,
    });
    dlg.openEdit(l);
  };

  const submit = () => {
    if (!form.name.trim()) return toast.error("Name is required");
    if (dlg.editing) {
      update("leads", dlg.editing.id, { ...form });
      // If moved to Won, convert to customer
      if (form.stage === "Won" && dlg.editing.stage !== "Won") {
        ensureCustomer({ name: form.name, email: form.email, phone: form.phone, address: form.address });
        toast.success("Lead won — customer created");
      } else {
        toast.success("Lead updated");
      }
    } else {
      const id = newId("l");
      add("leads", { id, ...form });
      fireEvent({ trigger: "lead.created", payload: { id, customer: form.name, email: form.email, source: form.source } });
      logActivity({ actor: "You", entity: "lead", entityId: id, action: "created", summary: `${form.name} from ${form.source}` });
      toast.success("Lead added");
    }
    dlg.close();
  };

  const del = (l: Lead) => {
    remove("leads", l.id);
    toast.success("Lead removed");
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Leads"
        description="Track prospects from first touch to won deal."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => setBulkOpen(true)}>
              <Upload className="mr-2 h-4 w-4" /> Bulk import
            </Button>
            <Button variant="outline" size="sm" onClick={() => { downloadCsv("leads", stageFiltered); toast.success("Exported leads"); }}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> New lead
            </Button>
          </>
        }
      />

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search leads…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      <Tabs defaultValue="list">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <TabsList>
            <TabsTrigger value="list">List</TabsTrigger>
            <TabsTrigger value="kanban">Kanban</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="list" className="mt-4 space-y-4">
          <StageFilter
            counts={LEAD_STAGES.reduce(
              (acc, s) => ({ ...acc, [s]: filtered.filter((l) => l.stage === s).length }),
              { All: filtered.length } as Record<string, number>,
            )}
            value={stageFilter}
            onChange={setStageFilter}
          />
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <div className="min-w-[820px]">
                  <div className="grid grid-cols-12 border-b bg-muted/50 px-4 py-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                    <div className="col-span-3">Lead</div>
                    <div className="col-span-3">Contact</div>
                    <div className="col-span-2">Source</div>
                    <div className="col-span-1">Value</div>
                    <div className="col-span-2">Stage</div>
                    <div className="col-span-1 text-right">•</div>
                  </div>
                  {stageFiltered.map((l) => (
                    <div
                      key={l.id}
                      className="grid grid-cols-12 items-center border-b px-4 py-3 text-sm last:border-b-0 hover:bg-muted/40"
                    >
                      <div className="col-span-3 font-medium">{l.name}</div>
                      <div className="col-span-3 text-muted-foreground">
                        <div>{l.contact}</div>
                        <div className="text-xs">{l.email}</div>
                      </div>
                      <div className="col-span-2">
                        <Badge variant="secondary" className="bg-primary-soft text-primary">
                          {l.source}
                        </Badge>
                      </div>
                      <div className="col-span-1 font-display font-semibold">
                        ${l.value.toLocaleString()}
                      </div>
                      <div className="col-span-2">
                        <Select value={l.stage} onValueChange={(v) => update("leads", l.id, { stage: v as LeadStage })}>
                          <SelectTrigger className="h-8 w-32"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {LEAD_STAGES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-1 flex justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(l)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => del(l)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  {stageFiltered.length === 0 && (
                    <div className="p-8 text-center text-sm text-muted-foreground">No leads in this stage.</div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="kanban" className="mt-4">
          <div className="grid gap-4 md:grid-cols-3 xl:grid-cols-5">
            {LEAD_STAGES.map((stage) => {
              const items = filtered.filter((l) => l.stage === stage);
              return (
                <div key={stage} className="flex min-h-64 flex-col rounded-2xl bg-muted/60 p-3">
                  <div className="mb-3 flex items-center justify-between px-1">
                    <div className="font-display text-sm font-semibold">{stage}</div>
                    <Badge variant="secondary" className="bg-background">
                      {items.length}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    {items.map((l) => (
                      <Card
                        key={l.id}
                        className="cursor-pointer transition hover:border-primary/50"
                        onClick={() => openEdit(l)}
                      >
                        <CardContent className="space-y-2 p-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="font-medium">{l.name}</div>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                del(l);
                              }}
                              className="text-muted-foreground hover:text-destructive"
                              aria-label="Delete lead"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                          <div className="text-xs text-muted-foreground">{l.contact}</div>
                          <div className="flex items-center justify-between text-xs">
                            <span className="rounded-full bg-primary-soft px-2 py-0.5 text-primary">
                              {l.source}
                            </span>
                            <span className="font-display font-semibold text-foreground">
                              ${l.value.toLocaleString()}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                    {items.length === 0 && (
                      <div className="rounded-xl border border-dashed p-3 text-center text-xs text-muted-foreground">
                        Nothing here
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>


      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit lead" : "New lead"}
        onSubmit={submit}
      >
        <div>
          <Label>Business / lead name</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Contact person</Label>
            <Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} />
          </div>
          <div>
            <Label>Email</Label>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Phone</Label>
            <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </div>
          <div>
            <Label>City</Label>
            <Input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
          </div>
        </div>
        <div>
          <Label>Address</Label>
          <Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </div>
        <div>
          <Label>Service interest</Label>
          <Select value={form.serviceInterest} onValueChange={(v) => setForm({ ...form, serviceInterest: v })}>
            <SelectTrigger><SelectValue placeholder="Which service?" /></SelectTrigger>
            <SelectContent>{services.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label>Source</Label>
            <Select value={form.source} onValueChange={(v) => setForm({ ...form, source: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{SOURCES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Value ($)</Label>
            <Input type="number" min={0} value={form.value} onChange={(e) => setForm({ ...form, value: Number(e.target.value) || 0 })} />
          </div>
          <div>
            <Label>Stage</Label>
            <Select value={form.stage} onValueChange={(v) => setForm({ ...form, stage: v as LeadStage })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{LEAD_STAGES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label>Notes</Label>
          <Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </div>
      </EntityDialog>

      <BulkImportDialog
        open={bulkOpen}
        onOpenChange={setBulkOpen}
        title="Bulk import leads"
        description="Paste rows from a spreadsheet or upload a CSV. One lead per line."
        fields={[
          { key: "name", label: "Name", required: true },
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
          { key: "source", label: "Source" },
          { key: "value", label: "Value" },
          { key: "notes", label: "Notes" },
        ]}
        sampleRow="Acme Offices, sales@acme.com, 555-1200, Website, 1200, Wants weekly"
        onImport={(rows) => {
          let n = 0;
          for (const r of rows) {
            const id = newId("l");
            add("leads", {
              id,
              name: r.name,
              contact: r.name,
              email: r.email || "",
              phone: r.phone || "",
              address: "",
              city: "",
              serviceInterest: "",
              notes: r.notes || "",
              source: SOURCES.includes(r.source) ? r.source : "Website",
              value: Number(r.value) || 0,
              stage: "New",
            });
            fireEvent({ trigger: "lead.created", payload: { id, customer: r.name, email: r.email, source: r.source || "Bulk" } });
            n++;
          }
          logActivity({ actor: "You", entity: "lead", entityId: "bulk", action: "created", summary: `Bulk imported ${n} leads` });
          return n;
        }}
      />
    </div>
  );
}

function StageFilter({
  counts,
  value,
  onChange,
}: {
  counts: Record<string, number>;
  value: LeadStage | "All";
  onChange: (v: LeadStage | "All") => void;
}) {
  const options: (LeadStage | "All")[] = ["All", ...LEAD_STAGES];
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            onClick={() => onChange(opt)}
            className={
              "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition " +
              (active
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-background text-muted-foreground hover:text-foreground")
            }
          >
            <span>{opt}</span>
            <span
              className={
                "rounded-full px-1.5 text-[10px] " +
                (active ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-foreground")
              }
            >
              {counts[opt] ?? 0}
            </span>
          </button>
        );
      })}
    </div>
  );
}

