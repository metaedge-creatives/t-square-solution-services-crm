import { createFileRoute } from "@tanstack/react-router";
import { Plus, Trash2, RotateCcw, Mail, KeyRound } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useAuth, type Role, type AuthUser } from "@/lib/auth";
import { useStore, newId, ALL_PERMISSIONS, type Permission } from "@/lib/data-store";
import { createInvite, inviteUrl, getPendingInvite, getInviteState, type InviteKind, type InviteStatus } from "@/lib/invites";
import { sendEmail } from "@/lib/email-provider";



import {
  defaultCompany,
  defaultDocs,
  getCompany,
  getDocs,
  writeCompany,
  writeDocs,
  type CompanyProfile,
  type DocTemplates,
} from "@/lib/company-profile";

export const Route = createFileRoute("/_authenticated/settings")({
  component: SettingsPage,
});

const NOTIF_KEY = "tsquare_crm_notif_v1";

const defaultNotif: Record<string, boolean> = {
  "New lead assigned to me": true,
  "Booking rescheduled": true,
  "Inspection failed": true,
  "Invoice overdue": false,
  "SMS reminders to crews": false,
};

function readLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try { const raw = window.localStorage.getItem(key); return raw ? { ...fallback, ...JSON.parse(raw) } : fallback; }
  catch { return fallback; }
}

function SettingsPage() {
  const { user } = useAuth();
  const { serviceAreas, add, remove } = useStore();

  const [company, setCompany] = useState<CompanyProfile>(defaultCompany);
  const [docs, setDocs] = useState<DocTemplates>(defaultDocs);
  const [notif, setNotif] = useState<Record<string, boolean>>(defaultNotif);
  const [newArea, setNewArea] = useState({ zip: "", city: "", surcharge: 0 });
  const [account, setAccount] = useState({ name: user?.name ?? "", email: user?.email ?? "" });

  useEffect(() => {
    setCompany(getCompany());
    setDocs(getDocs());
    setNotif(readLS(NOTIF_KEY, defaultNotif));
  }, []);

  const saveCompany = () => {
    writeCompany(company);
    toast.success("Company details saved — will appear on new PDFs & emails");
  };
  const saveDocs = () => {
    writeDocs(docs);
    toast.success("Document templates saved");
  };
  const resetDocs = () => {
    setDocs(defaultDocs);
    writeDocs(defaultDocs);
    toast.success("Templates reset to defaults");
  };
  const saveNotif = (label: string, v: boolean) => {
    const next = { ...notif, [label]: v };
    setNotif(next);
    window.localStorage.setItem(NOTIF_KEY, JSON.stringify(next));
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Company details, service coverage, notifications and your account." />

      <Tabs defaultValue="company">
        <div className="overflow-x-auto">
          <TabsList>
            <TabsTrigger value="company">Company</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="users">Users & permissions</TabsTrigger>
            <TabsTrigger value="areas">Service areas</TabsTrigger>
            <TabsTrigger value="integrations">Integrations</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>

        </div>

        <TabsContent value="company" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Company profile</CardTitle>
              <CardDescription>These details flow into every quote, invoice, contract and client email — change once, updates everywhere.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <Field label="Business name" value={company.name} onChange={(e) => setCompany({ ...company, name: e.target.value })} />
              <Field label="Public email" value={company.email} onChange={(e) => setCompany({ ...company, email: e.target.value })} />
              <Field label="Phone" value={company.phone} onChange={(e) => setCompany({ ...company, phone: e.target.value })} />
              <Field label="Website" value={company.website} onChange={(e) => setCompany({ ...company, website: e.target.value })} />
              <Field label="Tax / VAT ID (optional)" value={company.taxId ?? ""} onChange={(e) => setCompany({ ...company, taxId: e.target.value })} />
              <div className="md:col-span-2 space-y-1.5">
                <Label>Business address</Label>
                <Textarea rows={3} value={company.address} onChange={(e) => setCompany({ ...company, address: e.target.value })} />
              </div>
              <div className="md:col-span-2 space-y-1.5">
                <Label>Payment instructions (shown on invoices)</Label>
                <Textarea rows={2} value={company.paymentInstructions ?? ""} onChange={(e) => setCompany({ ...company, paymentInstructions: e.target.value })} />
              </div>
              <div className="md:col-span-2 flex justify-end">
                <Button onClick={saveCompany}>Save changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="mt-4 space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-start justify-between gap-4">
              <div>
                <CardTitle className="font-display">Document & email templates</CardTitle>
                <CardDescription>
                  Edit the PDF headers/footers and client email copy for invoices, quotes and contracts.
                  Use variables like <code>{"{{customer_name}}"}</code>, <code>{"{{amount}}"}</code>, <code>{"{{company_name}}"}</code>, <code>{"{{today}}"}</code>.
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={resetDocs}>
                <RotateCcw className="mr-2 h-4 w-4" /> Reset to default
              </Button>
            </CardHeader>
            <CardContent className="space-y-6">
              <TemplateGroup title="Invoice">
                <Field label="PDF header label" value={docs.invoiceHeader} onChange={(e) => setDocs({ ...docs, invoiceHeader: e.target.value })} />
                <TextareaField label="PDF footer text" rows={2} value={docs.invoiceFooter} onChange={(e) => setDocs({ ...docs, invoiceFooter: e.target.value })} />
                <Field label="Email subject" value={docs.invoiceEmailSubject} onChange={(e) => setDocs({ ...docs, invoiceEmailSubject: e.target.value })} />
                <TextareaField label="Email body" rows={6} value={docs.invoiceEmailBody} onChange={(e) => setDocs({ ...docs, invoiceEmailBody: e.target.value })} />
              </TemplateGroup>

              <TemplateGroup title="Quote">
                <Field label="PDF header label" value={docs.quoteHeader} onChange={(e) => setDocs({ ...docs, quoteHeader: e.target.value })} />
                <TextareaField label="PDF footer text" rows={2} value={docs.quoteFooter} onChange={(e) => setDocs({ ...docs, quoteFooter: e.target.value })} />
                <Field label="Email subject" value={docs.quoteEmailSubject} onChange={(e) => setDocs({ ...docs, quoteEmailSubject: e.target.value })} />
                <TextareaField label="Email body" rows={6} value={docs.quoteEmailBody} onChange={(e) => setDocs({ ...docs, quoteEmailBody: e.target.value })} />
              </TemplateGroup>

              <TemplateGroup title="Contract">
                <TextareaField label="Intro / parties header (auto-shown at top)" rows={10} value={docs.contractIntro} onChange={(e) => setDocs({ ...docs, contractIntro: e.target.value })} />
                <TextareaField label="Default middle body (used when a contract has no custom body)" rows={6} value={docs.contractBody} onChange={(e) => setDocs({ ...docs, contractBody: e.target.value })} />
                <TextareaField label="Closing terms & signature block (auto-shown at bottom)" rows={10} value={docs.contractTerms} onChange={(e) => setDocs({ ...docs, contractTerms: e.target.value })} />
                <Field label="Email subject" value={docs.contractEmailSubject} onChange={(e) => setDocs({ ...docs, contractEmailSubject: e.target.value })} />
                <TextareaField label="Email body" rows={6} value={docs.contractEmailBody} onChange={(e) => setDocs({ ...docs, contractEmailBody: e.target.value })} />
              </TemplateGroup>

              <div className="flex justify-end">
                <Button onClick={saveDocs}>Save templates</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="mt-4">
          <UsersPermissionsCard />
        </TabsContent>

        <TabsContent value="areas" className="mt-4">

          <Card>
            <CardHeader>
              <CardTitle className="font-display">Service areas</CardTitle>
              <CardDescription>ZIP codes you serve and any travel surcharges.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-[1fr_2fr_1fr_auto]">
                <Input placeholder="ZIP" value={newArea.zip} onChange={(e) => setNewArea({ ...newArea, zip: e.target.value })} />
                <Input placeholder="City" value={newArea.city} onChange={(e) => setNewArea({ ...newArea, city: e.target.value })} />
                <Input type="number" placeholder="Surcharge $" value={newArea.surcharge} onChange={(e) => setNewArea({ ...newArea, surcharge: Number(e.target.value) || 0 })} />
                <Button
                  onClick={() => {
                    if (!newArea.zip.trim()) return toast.error("ZIP required");
                    add("serviceAreas", { id: newId("sa"), ...newArea });
                    setNewArea({ zip: "", city: "", surcharge: 0 });
                    toast.success("Area added");
                  }}
                >
                  <Plus className="mr-1 h-4 w-4" /> Add
                </Button>
              </div>
              {serviceAreas.map((a) => (
                <div key={a.id} className="flex items-center gap-4 rounded-xl border p-3">
                  <div className="font-display text-sm font-semibold">{a.zip}</div>
                  <div className="flex-1 text-sm text-muted-foreground">{a.city}</div>
                  <Badge variant="secondary" className={a.surcharge ? "bg-secondary/40 text-secondary-foreground" : "bg-muted"}>
                    {a.surcharge ? `+$${a.surcharge} travel` : "No surcharge"}
                  </Badge>
                  <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive" onClick={() => { remove("serviceAreas", a.id); toast.success("Removed"); }}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="mt-4 space-y-4">
          <WooCommerceCard />
          <SmsProvidersCard />
        </TabsContent>





        <TabsContent value="notifications" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Notifications</CardTitle>
              <CardDescription>What lands in your inbox and phone.</CardDescription>
            </CardHeader>
            <CardContent className="divide-y">
              {Object.keys(defaultNotif).map((label) => (
                <div key={label} className="flex items-center justify-between gap-4 py-3">
                  <div>
                    <div className="text-sm font-medium">{label}</div>
                  </div>
                  <Switch checked={notif[label] ?? false} onCheckedChange={(v) => saveNotif(label, v)} />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Your account</CardTitle>
              <CardDescription>Personal details.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <Field label="Full name" value={account.name} onChange={(e) => setAccount({ ...account, name: e.target.value })} />
              <Field label="Email" value={account.email} onChange={(e) => setAccount({ ...account, email: e.target.value })} />
              <div className="md:col-span-2 flex justify-end gap-2">
                <Button variant="outline" onClick={() => setAccount({ name: user?.name ?? "", email: user?.email ?? "" })}>Cancel</Button>
                <Button onClick={() => toast.success("Account updated")}>Update account</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Field({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input {...props} />
    </div>
  );
}

function TextareaField({ label, ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Textarea {...props} />
    </div>
  );
}

function TemplateGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border p-4 space-y-3">
      <div className="font-display text-sm font-semibold">{title}</div>
      {children}
    </div>
  );
}

function WooCommerceCard() {
  const [webhookUrl, setWebhookUrl] = useState("");
  useEffect(() => {
    if (typeof window !== "undefined") {
      setWebhookUrl(`${window.location.origin}/api/public/woocommerce`);
    }
  }, []);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(webhookUrl);
      toast.success("Webhook URL copied");
    } catch {
      toast.error("Copy failed — select and copy manually");
    }
  };
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display">WooCommerce integration</CardTitle>
        <CardDescription>
          Every order placed on your WooCommerce site can flow straight into your Bookings and Customers here — no plugin needed beyond WooCommerce's built-in webhooks.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-1.5">
          <Label>Your webhook URL</Label>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input readOnly value={webhookUrl} className="font-mono text-xs" />
            <Button onClick={copy} variant="outline">Copy</Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Paste this into WooCommerce → Settings → Advanced → Webhooks as the <em>Delivery URL</em>.
          </p>
        </div>

        <div className="space-y-2 rounded-xl border bg-muted/40 p-4 text-sm">
          <div className="font-display font-semibold">Setup in WooCommerce</div>
          <ol className="list-decimal space-y-1 pl-5 text-muted-foreground">
            <li>WordPress admin → <strong>WooCommerce → Settings → Advanced → Webhooks</strong>.</li>
            <li>Click <strong>Add webhook</strong>. Name it "T Square CRM".</li>
            <li>Status: <strong>Active</strong>. Topic: <strong>Order created</strong> (add another for "Order updated" if you want status changes too).</li>
            <li>Delivery URL: paste the URL above.</li>
            <li>Secret: leave empty, or set one and add <code>WC_WEBHOOK_SECRET</code> to your server env — the CRM will verify the signature.</li>
            <li>API Version: <strong>WP REST API Integration v3</strong>. Save.</li>
          </ol>
          <p className="text-xs text-muted-foreground">
            New orders appear in <strong>Bookings</strong> within ~20 seconds, and the buyer is added to <strong>Customers</strong> automatically.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}


function SmsProvidersCard() {
  const [list, setList] = useState<import("@/lib/sms-provider").SmsProviderConfig[]>([]);
  const [form, setForm] = useState<{ provider: "twilio" | "gatewayapi"; label: string; from: string; a: string; b: string }>({
    provider: "twilio", label: "", from: "", a: "", b: "",
  });

  useEffect(() => {
    import("@/lib/sms-provider").then((m) => setList(m.readProviders()));
  }, []);

  const persist = async (next: typeof list) => {
    const m = await import("@/lib/sms-provider");
    m.writeProviders(next);
    setList(next);
  };

  const add = async () => {
    if (!form.label.trim() || !form.from.trim() || !form.a.trim()) return toast.error("Fill in all fields");
    const creds: Record<string, string> = form.provider === "twilio"
      ? { accountSid: form.a, authToken: form.b }
      : { apiToken: form.a };

    const next = [
      ...list,
      { id: `sms_${Date.now()}`, provider: form.provider, label: form.label, from: form.from, creds, active: list.length === 0 },
    ];
    await persist(next);
    setForm({ provider: "twilio", label: "", from: "", a: "", b: "" });
    toast.success("SMS provider added");
  };

  const makeActive = async (id: string) => {
    await persist(list.map((p) => ({ ...p, active: p.id === id })));
    toast.success("Active SMS provider updated");
  };
  const del = async (id: string) => { await persist(list.filter((p) => p.id !== id)); toast.success("Removed"); };
  const test = async (id: string) => {
    const to = window.prompt("Send test SMS to (E.164, e.g. +15551234567):");
    if (!to) return;
    const p = list.find((x) => x.id === id);
    if (!p) return;
    const res = await fetch("/api/send-sms", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ provider: p.provider, from: p.from, creds: p.creds, to, text: "Test from your CRM ✔" }),
    }).then((r) => r.json()).catch((e) => ({ ok: false, error: String(e) }));
    if (res.ok) toast.success("Test sent"); else toast.error(res.error ?? "Failed");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display">SMS providers</CardTitle>
        <CardDescription>Connect Twilio or GatewayAPI to send SMS from automations and one-off actions.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-2 md:grid-cols-5">
          <div>
            <Label>Provider</Label>
            <select
              className="mt-1.5 w-full rounded-md border bg-background px-3 py-2 text-sm"
              value={form.provider}
              onChange={(e) => setForm({ ...form, provider: e.target.value as "twilio" | "gatewayapi" })}
            >
              <option value="twilio">Twilio</option>
              <option value="gatewayapi">GatewayAPI</option>
            </select>
          </div>
          <Field label="Label" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} />
          <Field label={form.provider === "twilio" ? "From (E.164 or MSID)" : "Sender name"} value={form.from} onChange={(e) => setForm({ ...form, from: e.target.value })} />
          <Field label={form.provider === "twilio" ? "Account SID" : "API Token"} value={form.a} onChange={(e) => setForm({ ...form, a: e.target.value })} />
          {form.provider === "twilio" ? (
            <Field label="Auth Token" type="password" value={form.b} onChange={(e) => setForm({ ...form, b: e.target.value })} />
          ) : <div />}
        </div>
        <div className="flex justify-end">
          <Button onClick={add}><Plus className="mr-2 h-4 w-4" /> Add provider</Button>
        </div>

        {list.length > 0 && (
          <div className="space-y-2">
            {list.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-3 rounded-xl border p-3">
                <Badge variant="secondary" className="uppercase text-[10px]">{p.provider}</Badge>
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-medium">{p.label}</div>
                  <div className="text-xs text-muted-foreground">From {p.from}</div>
                </div>
                {p.active ? (
                  <Badge className="bg-success text-success-foreground">Active</Badge>
                ) : (
                  <Button size="sm" variant="outline" onClick={() => makeActive(p.id)}>Make active</Button>
                )}
                <Button size="sm" variant="outline" onClick={() => test(p.id)}>Send test</Button>
                <Button size="icon" variant="ghost" onClick={() => del(p.id)}><Trash2 className="h-4 w-4" /></Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

const ROLES: Role[] = ["owner", "admin", "manager", "cleaner", "client"];

const ROLE_PRESETS: Record<Role, Permission[]> = {
  owner: [...ALL_PERMISSIONS],
  admin: [...ALL_PERMISSIONS],
  manager: ["dashboard","customers","leads","bookings","invoices","quotes","contracts","services","inspections","email","automations","reports","activity","staff"],
  cleaner: ["dashboard","bookings","inspections","activity"],
  client: ["dashboard","bookings","invoices","quotes"],
};

const INVITE_STATUS_STYLE: Record<InviteStatus, string> = {
  none: "bg-muted text-muted-foreground",
  pending: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200",
  used: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200",
  expired: "bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-200",
};

const INVITE_STATUS_LABEL: Record<InviteStatus, string> = {
  none: "No invite sent",
  pending: "Invite pending",
  used: "Invite accepted",
  expired: "Invite expired",
};

function formatRelative(ts: number): string {
  const diff = Date.now() - ts;
  const abs = Math.abs(diff);
  const mins = Math.round(abs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ${diff >= 0 ? "ago" : "from now"}`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ${diff >= 0 ? "ago" : "from now"}`;
  const days = Math.round(hrs / 24);
  return `${days}d ${diff >= 0 ? "ago" : "from now"}`;
}

function InviteStatePill({ userId }: { userId: string }) {
  const state = getInviteState(userId, "invite");
  if (state.status === "none") return null;
  const ts = state.status === "used" ? state.usedAt : state.sentAt;
  const label =
    state.status === "used"
      ? `Accepted ${ts ? formatRelative(ts) : ""}`
      : state.status === "expired"
        ? `Expired · sent ${state.sentAt ? formatRelative(state.sentAt) : ""}`
        : `Sent ${state.sentAt ? formatRelative(state.sentAt) : ""}`;
  return (
    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px]">
      <span className={`rounded-full px-2 py-0.5 font-medium ${INVITE_STATUS_STYLE[state.status]}`}>
        {INVITE_STATUS_LABEL[state.status]}
      </span>
      <span className="text-muted-foreground">{label}</span>
    </div>
  );
}

function UsersPermissionsCard() {

  const { users, user, addUser, updateUser, removeUser, hasPermission } = useAuth();
  const canManage = hasPermission("settings") && (user?.role === "owner" || user?.role === "admin");

  const emptyForm = { name: "", email: "", role: "manager" as Role, permissions: ROLE_PRESETS.manager };
  const [form, setForm] = useState<{ name: string; email: string; role: Role; permissions: Permission[] }>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [inviteTick, setInviteTick] = useState(0);
  const hasPendingInviteFor = (id: string) => Boolean(getPendingInvite(id, "invite"));
  // reference inviteTick so the derived pending state re-reads localStorage on updates
  void inviteTick;


  const startEdit = (id: string) => {
    const u = users.find((x) => x.id === id);
    if (!u) return;
    setEditingId(id);
    setForm({ name: u.name, email: u.email, role: u.role, permissions: [...u.permissions] });
  };

  const resetForm = () => { setEditingId(null); setForm(emptyForm); };

  const togglePerm = (p: Permission) =>
    setForm((f) => ({ ...f, permissions: f.permissions.includes(p) ? f.permissions.filter((x) => x !== p) : [...f.permissions, p] }));

  const setRole = (r: Role) => setForm((f) => ({ ...f, role: r, permissions: ROLE_PRESETS[r] }));

  const submit = async () => {
    if (!canManage) return toast.error("You don't have permission to manage users.");
    if (!form.name.trim() || !form.email.trim()) return toast.error("Name and email are required.");
    try {
      if (editingId) {
        updateUser(editingId, {
          name: form.name.trim(), email: form.email.trim(), role: form.role, permissions: form.permissions,
        });
        toast.success("User updated");
        resetForm();
      } else {
        // Create with an unusable random placeholder password — the user will set their own via the invite link.
        const placeholder = `!${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
        const created = addUser({
          name: form.name.trim(), email: form.email.trim(), password: placeholder,
          role: form.role, permissions: form.permissions,
        });
        resetForm();
        // Auto-send the setup invite so they can pick their own password.
        await sendSetupLink(created, "invite");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    }
  };


  const del = (id: string) => {
    if (!canManage) return;
    if (!window.confirm("Remove this user from the CRM?")) return;
    try { removeUser(id); toast.success("User removed"); }
    catch (e) { toast.error(e instanceof Error ? e.message : "Failed"); }
  };

  const sendSetupLink = async (u: AuthUser, kind: InviteKind) => {
    if (!canManage) return;
    const invite = createInvite({ userId: u.id, email: u.email, kind });
    const link = inviteUrl(invite.token);
    const company = getCompany();
    const isReset = kind === "reset";
    const subject = isReset
      ? `Reset your password — ${company.name}`
      : `You're invited to ${company.name} CRM`;
    const intro = isReset
      ? `We received a request to reset the password on your ${company.name} CRM account.`
      : `${user?.name ?? "Your team"} invited you to the ${company.name} CRM.`;
    const cta = isReset ? "Reset password" : "Set up your account";
    const html = `<!doctype html><html><body style="font-family:Arial,sans-serif;background:#f6f8fa;padding:24px;color:#111">
  <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:12px;padding:28px;border:1px solid #e5e7eb">
    <h1 style="margin:0 0 8px;font-size:20px;color:#036A80">${subject}</h1>
    <p style="margin:0 0 16px;font-size:14px;line-height:1.5">Hi ${u.name || "there"},</p>
    <p style="margin:0 0 16px;font-size:14px;line-height:1.5">${intro} Click the button below to ${isReset ? "choose a new password" : "set your password and sign in"}. This link expires in 7 days.</p>
    <p style="text-align:center;margin:24px 0"><a href="${link}" style="background:#036A80;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;font-weight:600">${cta}</a></p>
    <p style="margin:0 0 8px;font-size:12px;color:#6b7280">If the button doesn't work, paste this URL into your browser:</p>
    <p style="margin:0;font-size:12px;word-break:break-all;color:#374151">${link}</p>
  </div>
  <p style="text-align:center;font-size:11px;color:#9ca3af;margin-top:16px">© ${new Date().getFullYear()} ${company.name}</p>
</body></html>`;
    const result = await sendEmail({ to: u.email, subject, html });
    setInviteTick((n) => n + 1);
    if (result.ok) {
      toast.success(`${isReset ? "Reset" : "Invite"} email sent to ${u.email}`);
    } else {
      try { await navigator.clipboard.writeText(link); } catch { /* ignore */ }
      toast.message("Email provider not connected — link copied to clipboard", {
        description: link,
        duration: 10000,
      });
    }
  };



  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="font-display">Team members</CardTitle>
          <CardDescription>
            Add teammates, set their role and choose which parts of the CRM they can open. Each teammate receives an email invite to set their own password.
          </CardDescription>

        </CardHeader>
        <CardContent className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="flex flex-wrap items-center gap-3 rounded-xl border p-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-sm font-medium">
                  {u.name}
                  <Badge variant="secondary" className="text-[10px] uppercase">{u.role}</Badge>
                  {user?.id === u.id && <Badge className="bg-primary/10 text-primary text-[10px]">You</Badge>}
                </div>
                <div className="text-xs text-muted-foreground">{u.email}</div>
                <div className="mt-1 text-[11px] text-muted-foreground">
                  {u.role === "owner" ? "Full access to everything" : `${(u.permissions ?? []).length} of ${ALL_PERMISSIONS.length} modules`}
                </div>
                {user?.id !== u.id && u.role !== "owner" && <InviteStatePill userId={u.id} />}

              </div>
              {canManage && (
                <>
                  <Button size="sm" variant="outline" onClick={() => startEdit(u.id)}>Edit</Button>
                  {user?.id !== u.id && (
                    <>
                      <Button size="sm" variant="outline" onClick={() => sendSetupLink(u, "invite")}>
                        <Mail className="mr-1.5 h-3.5 w-3.5" />
                        {hasPendingInviteFor(u.id) ? "Resend invite" : "Send invite"}
                      </Button>

                      <Button size="sm" variant="outline" onClick={() => sendSetupLink(u, "reset")}>
                        <KeyRound className="mr-1.5 h-3.5 w-3.5" /> Reset password
                      </Button>
                    </>
                  )}
                  {u.role !== "owner" && user?.id !== u.id && (
                    <Button size="icon" variant="ghost" className="text-muted-foreground hover:text-destructive" onClick={() => del(u.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </>
              )}
            </div>

          ))}
        </CardContent>
      </Card>

      {canManage && (
        <Card>
          <CardHeader>
            <CardTitle className="font-display">{editingId ? "Edit user" : "Add a new user"}</CardTitle>
            <CardDescription>{editingId ? "Update details, role or module access. Use “Reset password” to email them a new setup link." : "They'll receive an email with a secure link to set their own password."}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3 md:grid-cols-2">
              <Field label="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <Field label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              <div className="space-y-1.5 md:col-span-2">
                <Label>Role</Label>
                <select
                  className="w-full rounded-md border bg-background px-3 py-2 text-sm"
                  value={form.role}
                  onChange={(e) => setRole(e.target.value as Role)}
                >
                  {ROLES.map((r) => <option key={r} value={r} className="capitalize">{r}</option>)}
                </select>
              </div>
            </div>


            <div>
              <div className="mb-2 flex items-center justify-between">
                <Label className="text-sm">Module access</Label>
                <div className="flex gap-2 text-xs">
                  <button type="button" className="text-primary hover:underline" onClick={() => setForm((f) => ({ ...f, permissions: [...ALL_PERMISSIONS] }))}>Select all</button>
                  <span className="text-muted-foreground">·</span>
                  <button type="button" className="text-primary hover:underline" onClick={() => setForm((f) => ({ ...f, permissions: [] }))}>Clear</button>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 rounded-lg border p-3 sm:grid-cols-3">
                {ALL_PERMISSIONS.map((p) => (
                  <label key={p} className="flex items-center gap-2 text-sm capitalize">
                    <input
                      type="checkbox"
                      className="h-4 w-4 accent-primary"
                      checked={form.role === "owner" ? true : form.permissions.includes(p)}
                      disabled={form.role === "owner"}
                      onChange={() => togglePerm(p)}
                    />
                    {p}
                  </label>
                ))}
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">Only the modules ticked here appear in that user's sidebar.</p>
            </div>

            <div className="flex justify-end gap-2">
              {editingId && <Button variant="outline" onClick={resetForm}>Cancel</Button>}
              <Button onClick={submit}>{editingId ? "Save changes" : "Add user"}</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

