import { createFileRoute, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  Send,
  Mail,
  Users2,
  CheckCircle2,
  UserPlus,
  FileText,
  Copy,
  Info,
  Upload,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EntityDialog, useDialogState } from "@/components/entity-dialog";
import { BulkImportDialog } from "@/components/bulk-import-dialog";
import {
  EmailBlockEditor,
  DEFAULT_BLOCKS,
  compileEmail,
  type EmailBlock,
} from "@/components/email-editor";
import {
  useStore,
  newId,
  type Campaign,
  type CampaignStatus,
  type Audience,
  type AudienceContact,
  type EmailTemplate,
} from "@/lib/data-store";
import {
  loadIntegrations,
  saveIntegrations,
  sendEmail,
  PROVIDER_LABELS,
  type EmailProviderId,
  type EmailIntegrations,
} from "@/lib/email-provider";

export const Route = createFileRoute("/_authenticated/email-marketing")({
  component: EmailMarketingPage,
});

const STATUSES: CampaignStatus[] = ["Draft", "Scheduled", "Sent"];

const statusBadge: Record<CampaignStatus, string> = {
  Draft: "bg-muted text-foreground",
  Scheduled: "bg-secondary/30 text-foreground",
  Sent: "bg-primary-soft text-primary",
};

const TAB_HASHES = ["campaigns", "audiences", "templates", "integrations"] as const;

function EmailMarketingPage() {
  const { campaigns, audiences, templates } = useStore();
  const navigate = useNavigate();
  const hash = useRouterState({ select: (s) => s.location.hash });
  const activeTab = (TAB_HASHES as readonly string[]).includes(hash) ? hash : "campaigns";

  const totals = useMemo(() => {
    const sent = campaigns.filter((c) => c.status === "Sent").length;
    const scheduled = campaigns.filter((c) => c.status === "Scheduled").length;
    const contacts = audiences.reduce((a, x) => a + x.contacts.length, 0);
    return { sent, scheduled, contacts };
  }, [campaigns, audiences]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Email Marketing"
        description="Create campaigns, manage audiences and pick from ready-made templates."
      />

      <div className="grid gap-4 sm:grid-cols-4">
        <StatCard icon={<Mail className="h-4 w-4" />} label="Campaigns" value={campaigns.length} />
        <StatCard icon={<CheckCircle2 className="h-4 w-4" />} label="Sent" value={totals.sent} />
        <StatCard icon={<Users2 className="h-4 w-4" />} label="Contacts" value={totals.contacts} />
        <StatCard icon={<FileText className="h-4 w-4" />} label="Templates" value={templates.length} />
      </div>

      <Tabs
        value={activeTab}
        onValueChange={(v) =>
          navigate({ to: "/email-marketing", hash: v, replace: true })
        }
        className="space-y-4"
      >
        <TabsList>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="audiences">Audiences</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="campaigns">
          <CampaignsTab />
        </TabsContent>
        <TabsContent value="audiences">
          <AudiencesTab />
        </TabsContent>
        <TabsContent value="templates">
          <TemplatesTab />
        </TabsContent>
        <TabsContent value="integrations">
          <IntegrationsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ------------------ Campaigns ------------------ */

const emptyCampaign = {
  name: "",
  subject: "",
  audience: "",
  body: "",
  status: "Draft" as CampaignStatus,
  scheduledAt: new Date().toISOString().slice(0, 10),
  recipients: 0,
  templateId: "",
};

function CampaignsTab() {
  const { campaigns, audiences, add, update, remove } = useStore();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<CampaignStatus | "All">("All");

  const filtered = useMemo(
    () =>
      campaigns.filter((c) => {
        const q = (c.name + c.subject + c.audience)
          .toLowerCase()
          .includes(query.toLowerCase());
        const s = statusFilter === "All" || c.status === statusFilter;
        return q && s;
      }),
    [campaigns, query, statusFilter],
  );

  const openNew = () => {
    const first = audiences[0];
    const id = newId("cm");
    add("campaigns", {
      id,
      name: "Untitled campaign",
      subject: "",
      previewText: "",
      fromName: "T Square Solutions",
      fromEmail: "",
      audience: first?.name ?? "",
      body: "",
      blocks: [],
      status: "Draft",
      scheduledAt: new Date().toISOString().slice(0, 10),
      recipients: first?.contacts.length ?? 0,
    });
    navigate({ to: "/campaigns/$id", params: { id } });
  };
  const openEdit = (c: Campaign) => {
    navigate({ to: "/campaigns/$id", params: { id: c.id } });
  };
  const del = (c: Campaign) => {
    remove("campaigns", c.id);
    toast.success("Campaign deleted");
  };
  const sendNow = async (c: Campaign) => {
    const cfg = loadIntegrations();
    if (!cfg.active) {
      toast.error("Connect an email provider first (Integrations tab).");
      return;
    }
    const aud = audiences.find((a) => a.name === c.audience);
    const recipients = (aud?.contacts ?? []).map((x) => x.email).filter(Boolean);
    if (recipients.length === 0) {
      toast.error("Audience has no contacts with email addresses.");
      return;
    }
    const html = c.body?.trim().startsWith("<")
      ? c.body
      : `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5;white-space:pre-wrap">${(c.body || "").replace(/</g, "&lt;")}</div>`;
    const t = toast.loading(`Sending "${c.name}" to ${recipients.length} contact(s)…`);
    const result = await sendEmail({ to: recipients, subject: c.subject, html });
    toast.dismiss(t);
    if (result.ok) {
      update("campaigns", c.id, {
        status: "Sent",
        scheduledAt: new Date().toISOString().slice(0, 10),
        recipients: result.sent,
      });
      toast.success(`Sent to ${result.sent} contact(s) via ${result.provider}.`);
    } else {
      toast.error(
        `Sent ${result.sent}, failed ${result.failed}. ${result.errors?.[0] ?? ""}`.trim(),
      );
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-sm flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search campaigns…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {(["All", ...STATUSES] as const).map((s) => {
            const active = statusFilter === s;
            const count =
              s === "All" ? campaigns.length : campaigns.filter((c) => c.status === s).length;
            return (
              <button
                key={s}
                type="button"
                onClick={() => setStatusFilter(s)}
                className={
                  "inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition " +
                  (active
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-background text-muted-foreground hover:text-foreground")
                }
              >
                <span>{s}</span>
                <span
                  className={
                    "rounded-full px-1.5 text-[10px] " +
                    (active
                      ? "bg-primary-foreground/20 text-primary-foreground"
                      : "bg-muted text-foreground")
                  }
                >
                  {count}
                </span>
              </button>
            );
          })}
          <Button size="sm" onClick={openNew}>
            <Plus className="mr-2 h-4 w-4" /> New campaign
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="grid grid-cols-12 border-b bg-muted/50 px-4 py-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <div className="col-span-3">Campaign</div>
            <div className="col-span-3">Subject</div>
            <div className="col-span-2">Audience</div>
            <div className="col-span-1 text-right">Recipients</div>
            <div className="col-span-1">Status</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          {filtered.map((c) => (
            <div
              key={c.id}
              className="grid grid-cols-12 items-center border-b px-4 py-3 text-sm last:border-b-0 hover:bg-muted/40"
            >
              <div className="col-span-3">
                <button
                  onClick={() => openEdit(c)}
                  className="text-left font-medium hover:text-primary hover:underline"
                >
                  {c.name}
                </button>
                <div className="text-xs text-muted-foreground">
                  {c.status === "Sent" ? "Sent " : "Scheduled "} {c.scheduledAt}
                </div>
              </div>
              <div className="col-span-3 truncate text-muted-foreground">{c.subject || <span className="italic">No subject</span>}</div>
              <div className="col-span-2">
                <Badge variant="secondary" className="bg-primary-soft text-primary">
                  {c.audience || "—"}
                </Badge>
              </div>
              <div className="col-span-1 text-right font-display font-semibold">{c.recipients}</div>
              <div className="col-span-1">
                <Badge variant="secondary" className={statusBadge[c.status]}>
                  {c.status}
                </Badge>
              </div>
              <div className="col-span-2 flex justify-end gap-1">
                {c.status !== "Sent" && (
                  <Button variant="outline" size="sm" onClick={() => sendNow(c)}>
                    <Send className="mr-1.5 h-3.5 w-3.5" /> Send
                  </Button>
                )}
                <Button variant="ghost" size="icon" onClick={() => openEdit(c)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => del(c)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="p-8 text-center text-sm text-muted-foreground">No campaigns yet.</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}


/* ------------------ Audiences ------------------ */

function AudiencesTab() {
  const { audiences, add, update, remove } = useStore();
  const dlg = useDialogState<Audience>();
  const [form, setForm] = useState({ name: "", description: "" });
  const [selectedId, setSelectedId] = useState<string | null>(audiences[0]?.id ?? null);
  const selected = audiences.find((a) => a.id === selectedId) ?? audiences[0];

  const openNew = () => {
    setForm({ name: "", description: "" });
    dlg.openCreate();
  };
  const openEdit = (a: Audience) => {
    setForm({ name: a.name, description: a.description });
    dlg.openEdit(a);
  };
  const submit = () => {
    if (!form.name.trim()) return toast.error("Audience name is required");
    if (dlg.editing) {
      update("audiences", dlg.editing.id, { ...form });
      toast.success("Audience updated");
    } else {
      const id = newId("aud");
      add("audiences", { id, ...form, contacts: [] });
      setSelectedId(id);
      toast.success("Audience created");
    }
    dlg.close();
  };
  const del = (a: Audience) => {
    remove("audiences", a.id);
    if (selectedId === a.id) setSelectedId(null);
    toast.success("Audience deleted");
  };

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <Card>
        <CardContent className="space-y-2 p-3">
          <Button size="sm" className="w-full" onClick={openNew}>
            <Plus className="mr-2 h-4 w-4" /> New audience
          </Button>
          <div className="space-y-1">
            {audiences.map((a) => {
              const active = selected?.id === a.id;
              return (
                <button
                  key={a.id}
                  onClick={() => setSelectedId(a.id)}
                  className={
                    "flex w-full items-center justify-between rounded-md border px-3 py-2 text-left text-sm " +
                    (active
                      ? "border-primary bg-primary-soft"
                      : "border-transparent hover:bg-muted")
                  }
                >
                  <span className="font-medium">{a.name}</span>
                  <span className="text-xs text-muted-foreground">{a.contacts.length}</span>
                </button>
              );
            })}
            {audiences.length === 0 && (
              <div className="p-4 text-center text-xs text-muted-foreground">
                No audiences yet.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {selected ? (
        <AudienceDetail
          audience={selected}
          onEdit={() => openEdit(selected)}
          onDelete={() => del(selected)}
        />
      ) : (
        <Card>
          <CardContent className="p-10 text-center text-sm text-muted-foreground">
            Create an audience to start adding contacts.
          </CardContent>
        </Card>
      )}

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit audience" : "New audience"}
        onSubmit={submit}
      >
        <div>
          <Label>Name</Label>
          <Input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="e.g. VIP customers"
          />
        </div>
        <div>
          <Label>Description</Label>
          <Textarea
            rows={3}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Who is in this list?"
          />
        </div>
      </EntityDialog>
    </div>
  );
}

function AudienceDetail({
  audience,
  onEdit,
  onDelete,
}: {
  audience: Audience;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const { update, customers, templates } = useStore();
  const dlg = useDialogState<AudienceContact>();
  const [form, setForm] = useState({ name: "", email: "", phone: "", tags: "" });
  const [query, setQuery] = useState("");
  const [bulkOpen, setBulkOpen] = useState(false);
  const [newsletterOpen, setNewsletterOpen] = useState(false);
  const [newsletterTpl, setNewsletterTpl] = useState<string>("");
  const [sending, setSending] = useState(false);

  const openNew = () => {
    setForm({ name: "", email: "", phone: "", tags: "" });
    dlg.openCreate();
  };
  const openEdit = (c: AudienceContact) => {
    setForm({ name: c.name, email: c.email, phone: c.phone ?? "", tags: c.tags ?? "" });
    dlg.openEdit(c);
  };
  const submit = () => {
    if (!form.name.trim() || !form.email.trim())
      return toast.error("Name and email are required");
    let next: AudienceContact[];
    if (dlg.editing) {
      next = audience.contacts.map((c) =>
        c.id === dlg.editing!.id ? { ...c, ...form } : c,
      );
      toast.success("Contact updated");
    } else {
      next = [{ id: newId("ct"), ...form }, ...audience.contacts];
      toast.success("Contact added");
    }
    update("audiences", audience.id, { contacts: next });
    dlg.close();
  };
  const removeContact = (id: string) => {
    update("audiences", audience.id, {
      contacts: audience.contacts.filter((c) => c.id !== id),
    });
    toast.success("Contact removed");
  };
  const importFromCustomers = () => {
    const existing = new Set(audience.contacts.map((c) => c.email.toLowerCase()));
    const additions: AudienceContact[] = customers
      .filter((c) => c.email && !existing.has(c.email.toLowerCase()))
      .map((c) => ({
        id: newId("ct"),
        name: c.name,
        email: c.email,
        phone: c.phone,
        tags: c.type,
      }));
    if (additions.length === 0) return toast.info("All customers are already in this audience");
    update("audiences", audience.id, { contacts: [...additions, ...audience.contacts] });
    toast.success(`Imported ${additions.length} contacts`);
  };

  const filtered = audience.contacts.filter((c) =>
    (c.name + c.email + (c.tags ?? "")).toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <Card>
      <CardContent className="space-y-4 p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="font-display text-lg font-semibold">{audience.name}</div>
            <div className="text-sm text-muted-foreground">
              {audience.description || "No description"} · {audience.contacts.length} contacts
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={importFromCustomers}>
              <Users2 className="mr-2 h-4 w-4" /> Import customers
            </Button>
            <Button size="sm" variant="outline" onClick={() => setBulkOpen(true)}>
              <Upload className="mr-2 h-4 w-4" /> Bulk import
            </Button>
            <Button size="sm" variant="outline" onClick={() => setNewsletterOpen(true)} disabled={audience.contacts.length === 0}>
              <Send className="mr-2 h-4 w-4" /> Send newsletter
            </Button>
            <Button size="sm" variant="outline" onClick={onEdit}>
              <Pencil className="mr-2 h-4 w-4" /> Edit list
            </Button>
            <Button size="sm" variant="outline" onClick={onDelete}>
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
            <Button size="sm" onClick={openNew}>
              <UserPlus className="mr-2 h-4 w-4" /> Add contact
            </Button>
          </div>
        </div>

        <div className="relative max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search contacts…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        <div className="overflow-hidden rounded-md border">
          <div className="grid grid-cols-12 border-b bg-muted/50 px-4 py-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <div className="col-span-3">Name</div>
            <div className="col-span-4">Email</div>
            <div className="col-span-2">Phone</div>
            <div className="col-span-2">Tags</div>
            <div className="col-span-1 text-right">Actions</div>
          </div>
          {filtered.map((c) => (
            <div
              key={c.id}
              className="grid grid-cols-12 items-center border-b px-4 py-2.5 text-sm last:border-b-0 hover:bg-muted/40"
            >
              <div className="col-span-3 font-medium">{c.name}</div>
              <div className="col-span-4 truncate text-muted-foreground">{c.email}</div>
              <div className="col-span-2 text-muted-foreground">{c.phone || "—"}</div>
              <div className="col-span-2">
                {c.tags ? (
                  <Badge variant="secondary" className="bg-primary-soft text-primary">
                    {c.tags}
                  </Badge>
                ) : (
                  <span className="text-xs text-muted-foreground">—</span>
                )}
              </div>
              <div className="col-span-1 flex justify-end gap-1">
                <Button variant="ghost" size="icon" onClick={() => openEdit(c)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => removeContact(c.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="p-6 text-center text-sm text-muted-foreground">
              No contacts yet. Add one or import from your customers.
            </div>
          )}
        </div>

        <EntityDialog
          open={dlg.open}
          onOpenChange={(v) => (v ? undefined : dlg.close())}
          title={dlg.editing ? "Edit contact" : "Add contact"}
          onSubmit={submit}
        >
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Name</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </div>
            <div>
              <Label>Phone</Label>
              <Input
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
              />
            </div>
            <div>
              <Label>Tags</Label>
              <Input
                value={form.tags}
                onChange={(e) => setForm({ ...form, tags: e.target.value })}
                placeholder="e.g. VIP, Airbnb"
              />
            </div>
          </div>
        </EntityDialog>

        <BulkImportDialog
          open={bulkOpen}
          onOpenChange={setBulkOpen}
          title="Bulk import contacts"
          description="Paste rows from a spreadsheet or upload a CSV. One contact per line."
          fields={[
            { key: "name", label: "Name", required: true },
            { key: "email", label: "Email", required: true },
            { key: "phone", label: "Phone" },
            { key: "tags", label: "Tags" },
          ]}
          sampleRow="Jane Doe, jane@example.com, 555-2020, VIP"
          onImport={(rows) => {
            const existing = new Set(audience.contacts.map((c) => c.email.toLowerCase()));
            const additions: AudienceContact[] = [];
            for (const r of rows) {
              const em = (r.email || "").trim().toLowerCase();
              if (!em || existing.has(em)) continue;
              existing.add(em);
              additions.push({ id: newId("ct"), name: r.name, email: r.email, phone: r.phone || "", tags: r.tags || "" });
            }
            if (additions.length === 0) { toast.info("No new contacts to add"); return 0; }
            update("audiences", audience.id, { contacts: [...additions, ...audience.contacts] });
            return additions.length;
          }}
        />

        <EntityDialog
          open={newsletterOpen}
          onOpenChange={(v) => (v ? undefined : setNewsletterOpen(false))}
          title={`Send newsletter to ${audience.contacts.length} contacts`}
          submitLabel={sending ? "Sending…" : "Send now"}
          onSubmit={async () => {
            const tpl = templates.find((t) => t.id === newsletterTpl);
            if (!tpl) return toast.error("Choose a template");
            setSending(true);
            let ok = 0, fail = 0;
            for (const c of audience.contacts) {
              try {
                const html = tpl.body
                  .replaceAll("{{name}}", c.name)
                  .replaceAll("{{email}}", c.email);
                const res = await sendEmail({ to: c.email, subject: tpl.subject, html });
                if (res.ok) ok++; else fail++;
              } catch { fail++; }
            }
            setSending(false);
            setNewsletterOpen(false);
            toast.success(`Newsletter sent: ${ok} delivered${fail ? `, ${fail} failed` : ""}`);
          }}
        >
          <div className="space-y-3">
            <div>
              <Label>Template</Label>
              <Select value={newsletterTpl} onValueChange={setNewsletterTpl}>
                <SelectTrigger><SelectValue placeholder="Choose an email template" /></SelectTrigger>
                <SelectContent>
                  {templates.map((t) => (
                    <SelectItem key={t.id} value={t.id}>{t.name} — {t.subject}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <p className="text-xs text-muted-foreground">
              Uses your configured email provider under Integrations. Merge tags <code>{"{{name}}"}</code> and <code>{"{{email}}"}</code> are replaced per contact.
            </p>
          </div>
        </EntityDialog>
      </CardContent>
    </Card>
  );
}

/* ------------------ Templates ------------------ */

const TEMPLATE_CATEGORIES = ["Onboarding", "Promotion", "Reviews", "Retention", "Newsletter", "Announcement"];

function TemplatesTab() {
  const { templates, add, update, remove } = useStore();
  const dlg = useDialogState<EmailTemplate>();
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Newsletter");
  const [subject, setSubject] = useState("");
  const [blocks, setBlocks] = useState<EmailBlock[]>(DEFAULT_BLOCKS);

  const openNew = () => {
    setName("");
    setCategory("Newsletter");
    setSubject("");
    setBlocks(DEFAULT_BLOCKS.map((b) => ({ ...b, id: Math.random().toString(36).slice(2, 9) })));
    dlg.openCreate();
  };
  const openEdit = (t: EmailTemplate) => {
    setName(t.name);
    setCategory(t.category);
    setSubject(t.subject);
    if (Array.isArray(t.blocks) && t.blocks.length) {
      setBlocks(t.blocks as EmailBlock[]);
    } else {
      // Legacy HTML-only template — start with a default block layout so it can be edited visually.
      setBlocks(DEFAULT_BLOCKS.map((b) => ({ ...b, id: Math.random().toString(36).slice(2, 9) })));
    }
    dlg.openEdit(t);
  };
  const submit = () => {
    if (!name.trim() || !subject.trim())
      return toast.error("Name and subject are required");
    const body = compileEmail(blocks, subject);
    const payload = { name, category, subject, body, blocks };
    if (dlg.editing) {
      update("templates", dlg.editing.id, payload);
      toast.success("Template updated");
    } else {
      add("templates", { id: newId("tpl"), ...payload });
      toast.success("Template created");
    }
    dlg.close();
  };
  const duplicate = (t: EmailTemplate) => {
    add("templates", { ...t, id: newId("tpl"), name: `${t.name} (copy)` });
    toast.success("Template duplicated");
  };
  const del = (t: EmailTemplate) => {
    remove("templates", t.id);
    toast.success("Template deleted");
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button size="sm" onClick={openNew}>
          <Plus className="mr-2 h-4 w-4" /> New template
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {templates.map((t) => (
          <Card key={t.id} className="flex flex-col overflow-hidden">
            <div className="border-b bg-[#E6F3F6]">
              <iframe
                title={t.name}
                srcDoc={t.body}
                sandbox=""
                className="pointer-events-none block h-56 w-full"
              />
            </div>
            <CardContent className="flex flex-1 flex-col gap-2 p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-display text-base font-semibold">{t.name}</div>
                  <Badge variant="secondary" className="mt-1 bg-primary-soft text-primary">
                    {t.category}
                  </Badge>
                </div>
              </div>
              <div className="truncate text-xs text-muted-foreground">
                <span className="font-medium text-foreground">Subject:</span> {t.subject}
              </div>
              <div className="mt-auto flex justify-end gap-1 pt-2">
                <Button variant="ghost" size="icon" onClick={() => duplicate(t)}>
                  <Copy className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => openEdit(t)}>
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => del(t)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {templates.length === 0 && (
          <Card className="md:col-span-2 xl:col-span-3">
            <CardContent className="p-10 text-center text-sm text-muted-foreground">
              No templates yet.
            </CardContent>
          </Card>
        )}
      </div>

      <EntityDialog
        open={dlg.open}
        onOpenChange={(v) => (v ? undefined : dlg.close())}
        title={dlg.editing ? "Edit template" : "New template"}
        onSubmit={submit}
        size="xl"
        submitLabel="Save template"
      >
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label>Template name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Spring promo" />
          </div>
          <div>
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TEMPLATE_CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Subject line</Label>
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Shown in the inbox" />
          </div>
        </div>
        <EmailBlockEditor blocks={blocks} onChange={setBlocks} subject={subject} />
      </EntityDialog>
    </div>
  );
}



/* ------------------ Integrations ------------------ */

const PROVIDERS: EmailProviderId[] = ["brevo", "resend", "sendgrid", "mailgun", "mailchimp"];

const PROVIDER_HINTS: Record<EmailProviderId, string> = {
  brevo:
    "Get a v3 API key at Brevo → SMTP & API → API keys. Free tier: 300 emails/day.",
  resend:
    "Create an API key at resend.com/api-keys. Verify your sending domain first. Free: 3,000/month.",
  sendgrid:
    "Create a Full Access API key at SendGrid → Settings → API Keys. Sender must be verified.",
  mailgun:
    "API key + sending domain from mailgun.com → Sending → Domain settings. Pick US or EU region.",
  mailchimp:
    "Uses Mailchimp Transactional (Mandrill). API key from mandrillapp.com → Settings.",
};

function IntegrationsTab() {
  const [cfg, setCfg] = useState<EmailIntegrations>(() => loadIntegrations());
  const [tab, setTab] = useState<EmailProviderId>(cfg.active ?? "brevo");
  const [testTo, setTestTo] = useState("");
  const [testing, setTesting] = useState(false);

  const update = (next: EmailIntegrations) => {
    saveIntegrations(next);
    setCfg(next);
  };

  const isConnected = (p: EmailProviderId) => Boolean(cfg[p]);
  const activeCreds = cfg[tab];

  const setActive = (p: EmailProviderId) => {
    if (!cfg[p]) {
      toast.error(`Save ${PROVIDER_LABELS[p]} credentials first.`);
      return;
    }
    update({ ...cfg, active: p });
    toast.success(`${PROVIDER_LABELS[p]} is now the active sender.`);
  };

  const disconnect = (p: EmailProviderId) => {
    const next: EmailIntegrations = { ...cfg };
    delete next[p];
    if (next.active === p) next.active = null;
    update(next);
    toast.success(`${PROVIDER_LABELS[p]} disconnected.`);
  };

  const sendTest = async () => {
    if (!testTo.trim()) return toast.error("Enter a recipient email");
    if (!cfg.active) return toast.error("Set an active provider first");
    setTesting(true);
    const res = await sendEmail({
      to: testTo.trim(),
      subject: "Test email from your CRM",
      html: `<div style="font-family:Arial,sans-serif"><h2>It works ✓</h2><p>This is a test email sent via <b>${PROVIDER_LABELS[cfg.active]}</b>.</p></div>`,
    });
    setTesting(false);
    if (res.ok) toast.success(`Test sent via ${res.provider}.`);
    else toast.error(res.errors?.[0] ?? "Send failed.");
  };

  return (
    <div className="space-y-4">
      <Card className="border-primary/20 bg-primary-soft/40">
        <CardContent className="space-y-1 p-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Info className="h-4 w-4 text-primary" /> One provider handles every email
          </div>
          <p>
            Whichever provider is marked <b>Active</b> below is used for <b>all</b> outgoing
            email in the CRM — campaigns, newsletters, invoice deliveries, contract emails,
            teammate invites and password resets. You only need to connect one.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="font-display text-base font-semibold">Active sending provider</div>
            <div className="text-xs text-muted-foreground">
              Used for every email the CRM sends.
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {cfg.active ? (
              activeCreds?.lastVerifiedAt ? (
                <Badge className="bg-emerald-600 text-white hover:bg-emerald-600">
                  <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />
                  Connected · {PROVIDER_LABELS[cfg.active]}
                </Badge>
              ) : activeCreds?.lastVerifyError ? (
                <Badge variant="destructive">
                  Not connected · check {PROVIDER_LABELS[cfg.active]}
                </Badge>
              ) : (
                <Badge className="bg-amber-500 text-white hover:bg-amber-500">
                  Saved · verify {PROVIDER_LABELS[cfg.active]}
                </Badge>
              )
            ) : (
              <Badge variant="destructive">No provider connected — emails won't send</Badge>
            )}
            <div className="flex items-center gap-2">
              <Input
                type="email"
                placeholder="test@example.com"
                value={testTo}
                onChange={(e) => setTestTo(e.target.value)}
                className="w-56"
              />
              <Button size="sm" variant="outline" onClick={sendTest} disabled={testing}>
                <Send className="mr-1.5 h-3.5 w-3.5" />
                {testing ? "Sending…" : "Send test"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={tab} onValueChange={(v) => setTab(v as EmailProviderId)} className="space-y-4">
        <TabsList className="flex-wrap">
          {PROVIDERS.map((p) => (
            <TabsTrigger key={p} value={p} className="gap-2">
              {PROVIDER_LABELS[p]}
              {isConnected(p) && (
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    cfg[p]?.lastVerifiedAt
                      ? "bg-emerald-500"
                      : cfg[p]?.lastVerifyError
                        ? "bg-red-500"
                        : "bg-amber-500"
                  }`}
                />
              )}
            </TabsTrigger>
          ))}
        </TabsList>

        {PROVIDERS.map((p) => (
          <TabsContent key={p} value={p}>
            <ProviderForm
              provider={p}
              creds={cfg[p]}
              active={cfg.active === p}
              onSave={(next) => update({ ...cfg, [p]: next, active: cfg.active ?? p })}
              onSetActive={() => setActive(p)}
              onDisconnect={() => disconnect(p)}
              onVerified={(next) => update({ ...cfg, [p]: next })}
              hint={PROVIDER_HINTS[p]}
            />
          </TabsContent>
        ))}
      </Tabs>

      <Card>
        <CardContent className="space-y-2 p-5 text-xs text-muted-foreground">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Info className="h-4 w-4 text-primary" /> How this works
          </div>
          <p>
            Credentials are stored in this browser only. When you send, the CRM posts your
            credentials to its own server route which forwards to the provider's API — no third
            party sees your data.
          </p>
          <p>
            The <b>From email</b> must be verified in the provider's dashboard, otherwise the
            provider will reject the message.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}


function ProviderForm({
  provider,
  creds,
  active,
  onSave,
  onSetActive,
  onDisconnect,
  onVerified,
  hint,
}: {
  provider: EmailProviderId;
  creds: any;
  active: boolean;
  onSave: (next: any) => void;
  onSetActive: () => void;
  onDisconnect: () => void;
  onVerified: (next: any) => void;
  hint: string;
}) {

  const [apiKey, setApiKey] = useState<string>(creds?.apiKey ?? "");
  const [fromName, setFromName] = useState<string>(creds?.fromName ?? "T Square Solutions");
  const [fromEmail, setFromEmail] = useState<string>(creds?.fromEmail ?? "");
  const [domain, setDomain] = useState<string>(creds?.domain ?? "");
  const [region, setRegion] = useState<"us" | "eu">(creds?.region ?? "us");
  const [serverPrefix, setServerPrefix] = useState<string>(creds?.serverPrefix ?? "");
  const [show, setShow] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const verify = async () => {
    if (!creds) return toast.error("Save credentials first");
    setVerifying(true);
    try {
      const res = await fetch("/api/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider,
          creds,
          message: {
            to: creds.fromEmail,
            subject: "CRM connection test",
            html: `<p>Your <b>${PROVIDER_LABELS[provider]}</b> integration is working. You can delete this email.</p>`,
          },
        }),
      });
      const data = await res.json();
      if (data.ok) {
        onVerified({
          ...creds,
          lastVerifiedAt: new Date().toISOString(),
          lastVerifyError: undefined,
        });
        toast.success(`${PROVIDER_LABELS[provider]} verified — check ${creds.fromEmail}`);
      } else {
        const msg = data.errors?.[0] ?? "Verification failed.";
        onVerified({ ...creds, lastVerifiedAt: undefined, lastVerifyError: msg });
        toast.error(msg);
      }
    } catch (err) {
      const msg = String(err);
      onVerified({ ...creds, lastVerifiedAt: undefined, lastVerifyError: msg });
      toast.error(msg);
    } finally {
      setVerifying(false);
    }
  };


  const save = () => {
    if (!apiKey.trim()) return toast.error("API key is required");
    if (!fromEmail.trim()) return toast.error("From email is required");
    if (provider === "mailgun" && !domain.trim()) return toast.error("Mailgun domain is required");
    const base = {
      apiKey: apiKey.trim(),
      fromName: fromName.trim() || "CRM",
      fromEmail: fromEmail.trim(),
      connectedAt: new Date().toISOString(),
    };
    const next =
      provider === "mailgun"
        ? { ...base, domain: domain.trim(), region }
        : provider === "mailchimp"
          ? { ...base, serverPrefix: serverPrefix.trim() }
          : base;
    onSave(next);
    toast.success(`${PROVIDER_LABELS[provider]} saved.`);
  };

  const masked = (k: string) =>
    k.length > 10 ? `${k.slice(0, 4)}••••••${k.slice(-4)}` : "••••••";

  return (
    <Card>
      <CardContent className="space-y-4 p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="font-display text-lg font-semibold">{PROVIDER_LABELS[provider]}</div>
            <div className="text-xs text-muted-foreground">{hint}</div>
          </div>
          {creds ? (
            <div className="flex flex-col items-end gap-1">
              {active ? (
                <Badge className="bg-primary text-primary-foreground">
                  <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" /> Active
                </Badge>
              ) : (
                <Badge variant="secondary" className="bg-primary-soft text-primary">Saved</Badge>
              )}
              {creds.lastVerifiedAt ? (
                <Badge className="bg-emerald-600 text-white hover:bg-emerald-600">
                  <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" /> Verified
                </Badge>
              ) : creds.lastVerifyError ? (
                <Badge variant="destructive">Verification failed</Badge>
              ) : (
                <Badge className="bg-amber-500 text-white hover:bg-amber-500">Not verified</Badge>
              )}
            </div>
          ) : (
            <Badge variant="destructive">Not connected</Badge>
          )}

        </div>

        {creds && (
          <div className="rounded-lg border border-primary/20 bg-primary-soft/60 p-3 text-xs text-muted-foreground">
            Key on file: <span className="font-mono">{masked(creds.apiKey)}</span> · From{" "}
            <span className="font-medium text-foreground">
              {creds.fromName} &lt;{creds.fromEmail}&gt;
            </span>
          </div>
        )}

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Label>API key</Label>
            <div className="flex gap-2">
              <Input
                type={show ? "text" : "password"}
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Paste your key"
              />
              <Button variant="outline" size="sm" onClick={() => setShow((s) => !s)}>
                {show ? "Hide" : "Show"}
              </Button>
            </div>
          </div>
          <div>
            <Label>From name</Label>
            <Input value={fromName} onChange={(e) => setFromName(e.target.value)} />
          </div>
          <div>
            <Label>From email (verified with provider)</Label>
            <Input
              type="email"
              value={fromEmail}
              onChange={(e) => setFromEmail(e.target.value)}
              placeholder="hello@yourdomain.com"
            />
          </div>
          {provider === "mailgun" && (
            <>
              <div>
                <Label>Sending domain</Label>
                <Input
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  placeholder="mg.yourdomain.com"
                />
              </div>
              <div>
                <Label>Region</Label>
                <Select value={region} onValueChange={(v) => setRegion(v as "us" | "eu")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">US</SelectItem>
                    <SelectItem value="eu">EU</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </>
          )}
          {provider === "mailchimp" && (
            <div>
              <Label>Server prefix (optional)</Label>
              <Input
                value={serverPrefix}
                onChange={(e) => setServerPrefix(e.target.value)}
                placeholder="us21"
              />
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={save}>
            <CheckCircle2 className="mr-2 h-4 w-4" />
            {creds ? "Update credentials" : `Connect ${PROVIDER_LABELS[provider]}`}
          </Button>
          {creds && (
            <Button variant="outline" onClick={verify} disabled={verifying}>
              <Send className="mr-2 h-4 w-4" />
              {verifying ? "Verifying…" : "Verify connection"}
            </Button>
          )}
          {creds && !active && (
            <Button variant="outline" onClick={onSetActive}>
              Set as active
            </Button>
          )}
          {creds && (
            <Button variant="outline" onClick={onDisconnect}>
              <Trash2 className="mr-2 h-4 w-4" /> Disconnect
            </Button>
          )}
        </div>
        {creds?.lastVerifyError && (
          <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
            Last verify error: {creds.lastVerifyError}
          </div>
        )}
        {creds?.lastVerifiedAt && !creds.lastVerifyError && (
          <div className="text-xs text-muted-foreground">
            Verified {new Date(creds.lastVerifiedAt).toLocaleString()}
          </div>
        )}

      </CardContent>
    </Card>
  );
}


/* ------------------ Small helpers ------------------ */

function StatCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
}) {
  return (
    <Card>
      <CardContent className="flex items-center justify-between p-4">
        <div>
          <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
          <div className="font-display text-2xl font-bold">{value}</div>
        </div>
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary-soft text-primary">
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}
