import { createFileRoute } from "@tanstack/react-router";
import { ContractForm } from "@/components/contract-form";

export const Route = createFileRoute("/_authenticated/contracts/new")({
  component: () => <ContractForm />,
});
