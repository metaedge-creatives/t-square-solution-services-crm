import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { Download, TrendingUp, DollarSign, Users, Briefcase } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useStore } from "@/lib/data-store";
import { downloadCsv } from "@/lib/export";

export const Route = createFileRoute("/_authenticated/reports")({
  component: ReportsPage,
});

function ReportsPage() {
  const { invoices, bookings, customers, leads, staff, services } = useStore();

  const revenueByMonth = useMemo(() => {
    const map = new Map<string, number>();
    for (const i of invoices) {
      if (i.status !== "Paid") continue;
      const m = i.issued.slice(0, 7);
      map.set(m, (map.get(m) ?? 0) + i.amount);
    }
    return Array.from(map, ([month, total]) => ({ month, total })).sort((a, b) => a.month.localeCompare(b.month));
  }, [invoices]);

  const revenueByService = useMemo(() => {
    const map = new Map<string, { revenue: number; jobs: number }>();
    for (const b of bookings) {
      const svc = services.find((s) => s.name === b.service);
      const price = svc?.basePrice ?? 0;
      const cur = map.get(b.service) ?? { revenue: 0, jobs: 0 };
      map.set(b.service, { revenue: cur.revenue + price, jobs: cur.jobs + 1 });
    }
    return Array.from(map, ([service, v]) => ({ service, ...v })).sort((a, b) => b.revenue - a.revenue);
  }, [bookings, services]);

  const staffProductivity = useMemo(() => {
    const map = new Map<string, number>();
    for (const b of bookings) map.set(b.assignee, (map.get(b.assignee) ?? 0) + 1);
    return Array.from(map, ([name, jobs]) => ({ name, jobs })).sort((a, b) => b.jobs - a.jobs);
  }, [bookings]);

  const leadConversion = useMemo(() => {
    const won = leads.filter((l) => l.stage === "Won").length;
    const total = leads.length || 1;
    return { won, total, rate: Math.round((won / total) * 100) };
  }, [leads]);

  const totalRevenue = invoices.filter((i) => i.status === "Paid").reduce((s, i) => s + i.amount, 0);
  const outstanding = invoices.filter((i) => i.status !== "Paid").reduce((s, i) => s + i.amount, 0);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Reports & Analytics"
        description="Revenue trends, service performance, staff productivity — all exportable."
        actions={
          <Button variant="outline" size="sm" onClick={() => { downloadCsv("revenue-by-month", revenueByMonth); toast.success("Exported"); }}>
            <Download className="mr-2 h-4 w-4" /> Export revenue
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={DollarSign} label="Total revenue" value={`$${totalRevenue.toLocaleString()}`} />
        <StatCard icon={TrendingUp} label="Outstanding" value={`$${outstanding.toLocaleString()}`} />
        <StatCard icon={Users} label="Customers" value={customers.length.toString()} />
        <StatCard icon={Briefcase} label="Lead conversion" value={`${leadConversion.rate}%`} sub={`${leadConversion.won}/${leadConversion.total} won`} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-display">Revenue by month</CardTitle>
            <CardDescription>Paid invoices grouped by issue month.</CardDescription>
          </CardHeader>
          <CardContent>
            {revenueByMonth.length === 0 ? (
              <div className="py-8 text-center text-sm text-muted-foreground">No paid invoices yet.</div>
            ) : (
              <div className="space-y-2">
                {revenueByMonth.map((r) => {
                  const max = Math.max(...revenueByMonth.map((x) => x.total));
                  const pct = (r.total / max) * 100;
                  return (
                    <div key={r.month} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="font-medium">{r.month}</span>
                        <span className="text-muted-foreground">${r.total.toLocaleString()}</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted">
                        <div className="h-2 rounded-full bg-primary" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="font-display">Top services</CardTitle>
            <CardDescription>Revenue and jobs per service line.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Service</TableHead>
                    <TableHead className="text-right">Jobs</TableHead>
                    <TableHead className="text-right">Revenue</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {revenueByService.map((r) => (
                    <TableRow key={r.service}>
                      <TableCell>{r.service}</TableCell>
                      <TableCell className="text-right">{r.jobs}</TableCell>
                      <TableCell className="text-right font-semibold">${r.revenue.toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                  {revenueByService.length === 0 && (
                    <TableRow><TableCell colSpan={3} className="py-8 text-center text-sm text-muted-foreground">No bookings yet.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <div>
            <CardTitle className="font-display">Staff productivity</CardTitle>
            <CardDescription>Jobs assigned per team member.</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => { downloadCsv("staff-productivity", staffProductivity); toast.success("Exported"); }}>
            <Download className="mr-2 h-4 w-4" /> Export
          </Button>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Staff</TableHead>
                  <TableHead className="text-right">Jobs</TableHead>
                  <TableHead>Role</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {staffProductivity.map((s) => {
                  const st = staff.find((x) => x.name === s.name);
                  return (
                    <TableRow key={s.name}>
                      <TableCell>{s.name}</TableCell>
                      <TableCell className="text-right font-semibold">{s.jobs}</TableCell>
                      <TableCell className="text-muted-foreground">{st?.role ?? "—"}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, sub }: { icon: typeof DollarSign; label: string; value: string; sub?: string }) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-primary-soft p-2 text-primary"><Icon className="h-5 w-5" /></div>
          <div>
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
            <div className="font-display text-2xl font-bold">{value}</div>
            {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
