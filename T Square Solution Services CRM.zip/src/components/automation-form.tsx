import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { ArrowLeft, Save, Mail, User, Calendar, Clock, DollarSign, Wrench, Hash, Sparkles, AtSign } from "lucide-react";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { readRules, writeRules, type AutomationRule, type TriggerType, type ActionType } from "@/lib/automations";
import { useCompanyProfile, interpolate } from "@/lib/company-profile";

const TRIGGERS: { value: TriggerType; label: string }[] = [
  { value: "booking.created", label: "When a booking is created" },
  { value: "booking.completed", label: "When a booking is completed" },
  { value: "invoice.created", label: "When an invoice is created" },
  { value: "invoice.approved", label: "When an invoice is approved" },
  { value: "invoice.paid", label: "When an invoice is paid" },
  { value: "contract.sent", label: "When a contract is sent" },
  { value: "customer.created", label: "When a new customer is added" },
  { value: "lead.created", label: "When a new lead comes in" },
];
const ACTIONS: { value: ActionType; label: string }[] = [
  { value: "send_email", label: "Send an email" },
  { value: "log", label: "Log to activity feed" },
];

type TagKey = "customer" | "email" | "service" | "date" | "time" | "amount" | "id" | "source" | "company_name";
const TAGS: { key: TagKey; label: string; icon: typeof User; sample: string }[] = [
  { key: "customer", label: "Customer name", icon: User, sample: "Alex Johnson" },
  { key: "email", label: "Customer email", icon: AtSign, sample: "alex@example.com" },
  { key: "service", label: "Service", icon: Wrench, sample: "Deep Cleaning" },
  { key: "date", label: "Date", icon: Calendar, sample: new Date().toISOString().slice(0, 10) },
  { key: "time", label: "Time", icon: Clock, sample: "10:00 AM" },
  { key: "amount", label: "Amount", icon: DollarSign, sample: "250.00" },
  { key: "id", label: "Record ID", icon: Hash, sample: "BK-1024" },
  { key: "source", label: "Lead source", icon: Sparkles, sample: "Website" },
  { key: "company_name", label: "Company name", icon: Mail, sample: "" },
];

const empty: Omit<AutomationRule, "id"> = {
  name: "",
  trigger: "booking.created",
  action: "send_email",
  enabled: true,
  to: "{{email}}",
  subject: "Your booking is confirmed",
  message: "Hi {{customer}},\n\nThanks for booking {{service}} with us on {{date}} at {{time}}.\n\nWe'll see you soon!",
};

type FieldKey = "to" | "subject" | "message";

export function AutomationForm({ editingId }: { editingId?: string }) {
  const navigate = useNavigate();
  const company = useCompanyProfile();

  const [rules, setRules] = useState<AutomationRule[]>([]);
  const editing = editingId ? rules.find((r) => r.id === editingId) : undefined;

  const [form, setForm] = useState<Omit<AutomationRule, "id">>(empty);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const list = readRules();
    setRules(list);
    if (editingId) {
      const found = list.find((r) => r.id === editingId);
      if (found) setForm({ ...empty, ...found });
    }
    setLoaded(true);
  }, [editingId]);

  const [focused, setFocused] = useState<FieldKey>("message");
  const toRef = useRef<HTMLInputElement | null>(null);
  const subjectRef = useRef<HTMLInputElement | null>(null);
  const messageRef = useRef<HTMLTextAreaElement | null>(null);
  const selRef = useRef<Record<FieldKey, { start: number; end: number }>>({
    to: { start: 0, end: 0 }, subject: { start: 0, end: 0 }, message: { start: 0, end: 0 },
  });

  const insertTag = (key: TagKey) => {
    const token = `{{${key}}}`;
    const field = focused;
    const cur = (form[field] ?? "") as string;
    const sel = selRef.current[field];
    const start = sel.start ?? cur.length;
    const end = sel.end ?? cur.length;
    const next = cur.slice(0, start) + token + cur.slice(end);
    setForm({ ...form, [field]: next });
    requestAnimationFrame(() => {
      const el = field === "to" ? toRef.current : field === "subject" ? subjectRef.current : messageRef.current;
      if (el) {
        el.focus();
        const pos = start + token.length;
        (el as HTMLInputElement).selectionStart = pos;
        (el as HTMLInputElement).selectionEnd = pos;
        selRef.current[field] = { start: pos, end: pos };
      }
    });
  };

  const trackSel = (field: FieldKey) => (e: React.SyntheticEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const t = e.currentTarget;
    selRef.current[field] = { start: t.selectionStart ?? 0, end: t.selectionEnd ?? 0 };
  };

  const preview = useMemo(() => {
    const vars: Record<string, string> = { company_name: company.name };
    for (const t of TAGS) if (t.key !== "company_name") vars[t.key] = t.sample;
    return {
      to: interpolate(form.to ?? "", vars) || "recipient@example.com",
      subject: interpolate(form.subject ?? "", vars) || "(no subject)",
      message: interpolate(form.message ?? "", vars) || "(empty message)",
    };
  }, [form.to, form.subject, form.message, company.name]);

  const renderChip = (text: string) => {
    const parts = text.split(/(\{\{[\w.-]+\}\})/g);
    return parts.map((p, i) => {
      const m = p.match(/^\{\{\s*([\w.-]+)\s*\}\}$/);
      if (!m) return <span key={i}>{p}</span>;
      const tag = TAGS.find((t) => t.key === (m[1] as TagKey));
      return (
        <span key={i} className="inline-flex items-center rounded-md bg-primary/10 px-1.5 py-0.5 text-[11px] font-medium text-primary">
          {tag?.label ?? m[1]}
        </span>
      );
    });
  };

  const submit = () => {
    if (!form.name.trim()) return toast.error("Name your rule");
    if (editing) {
      const list = rules.map((r) => r.id === editing.id ? { ...editing, ...form } : r);
      writeRules(list);
      toast.success("Rule updated");
    } else {
      const list = [{ id: `rule_${Date.now()}`, ...form }, ...rules];
      writeRules(list);
      toast.success("Rule created");
    }
    navigate({ to: "/automations" });
  };

  if (!loaded) return null;

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" className="w-fit" onClick={() => navigate({ to: "/automations" })}>
        <ArrowLeft className="mr-2 h-4 w-4" /> All automations
      </Button>
      <PageHeader
        title={editing ? "Edit automation" : "New automation"}
        description="Click a tag to insert it into a field. The preview updates live."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => navigate({ to: "/automations" })}>Cancel</Button>
            <Button size="sm" onClick={submit}><Save className="mr-2 h-4 w-4" /> {editing ? "Save changes" : "Create rule"}</Button>
          </>
        }
      />

      {form.action === "send_email" && (
        <Card>
          <CardContent className="p-4">
            <div className="mb-2 text-xs font-medium text-muted-foreground">
              Click a tag to insert it into the <span className="text-foreground">{focused === "to" ? "recipient" : focused}</span> field
            </div>
            <div className="flex flex-wrap gap-1.5">
              {TAGS.map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => insertTag(t.key)}
                  className="inline-flex items-center gap-1 rounded-full border bg-background px-2.5 py-1 text-xs font-medium transition hover:border-primary hover:bg-primary/10 hover:text-primary"
                >
                  <t.icon className="h-3 w-3" /> {t.label}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardContent className="space-y-3 p-6">
            <div>
              <Label>Rule name</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Booking confirmation email" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Trigger</Label>
                <Select value={form.trigger} onValueChange={(v) => setForm({ ...form, trigger: v as TriggerType })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TRIGGERS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Action</Label>
                <Select value={form.action} onValueChange={(v) => setForm({ ...form, action: v as ActionType })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ACTIONS.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            {form.action === "send_email" && (
              <>
                <div>
                  <Label>Send to</Label>
                  <Input
                    ref={toRef}
                    value={form.to ?? ""}
                    onChange={(e) => setForm({ ...form, to: e.target.value })}
                    onFocus={() => setFocused("to")}
                    onSelect={trackSel("to")}
                    onKeyUp={trackSel("to")}
                    onMouseUp={trackSel("to")}
                  />
                </div>
                <div>
                  <Label>Subject</Label>
                  <Input
                    ref={subjectRef}
                    value={form.subject ?? ""}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    onFocus={() => setFocused("subject")}
                    onSelect={trackSel("subject")}
                    onKeyUp={trackSel("subject")}
                    onMouseUp={trackSel("subject")}
                  />
                </div>
                <div>
                  <Label>Message</Label>
                  <Textarea
                    ref={messageRef}
                    rows={10}
                    value={form.message ?? ""}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    onFocus={() => setFocused("message")}
                    onSelect={trackSel("message")}
                    onKeyUp={trackSel("message")}
                    onMouseUp={trackSel("message")}
                  />
                </div>
              </>
            )}
            {form.action === "log" && (
              <div>
                <Label>Log summary</Label>
                <Input value={form.message ?? ""} onChange={(e) => setForm({ ...form, message: e.target.value })} />
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-2">
          <div className="text-xs font-medium text-muted-foreground">Live preview</div>
          {form.action === "send_email" ? (
            <div className="overflow-hidden rounded-xl border bg-background shadow-sm">
              <div className="border-b bg-muted/50 px-4 py-3">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Mail className="h-3.5 w-3.5" /> Email preview
                </div>
              </div>
              <div className="space-y-2 border-b px-4 py-3 text-sm">
                <div className="flex gap-2"><span className="w-16 shrink-0 text-xs text-muted-foreground">From</span><span className="truncate">{company.name} &lt;{company.email || "hello@example.com"}&gt;</span></div>
                <div className="flex flex-wrap gap-2"><span className="w-16 shrink-0 text-xs text-muted-foreground">To</span><span className="truncate">{renderChip(form.to ?? "")}</span></div>
                <div className="flex flex-wrap gap-2"><span className="w-16 shrink-0 text-xs text-muted-foreground">Subject</span><span className="truncate font-medium">{renderChip(form.subject ?? "")}</span></div>
              </div>
              <div className="px-6 py-6">
                <div className="whitespace-pre-wrap break-words text-sm leading-6 text-foreground/90">
                  {(form.message ?? "").split("\n").map((line, i) => (
                    <div key={i} className="min-h-[1.5em]">{renderChip(line)}</div>
                  ))}
                </div>
                <div className="mt-6 border-t pt-4 text-xs text-muted-foreground">Sent by {company.name}</div>
              </div>
              <div className="border-t bg-muted/30 px-4 py-3">
                <div className="mb-1 text-[11px] font-medium text-muted-foreground">With sample values</div>
                <div className="rounded-md bg-background px-3 py-2 text-xs">
                  <div><span className="text-muted-foreground">To: </span>{preview.to}</div>
                  <div><span className="text-muted-foreground">Subject: </span>{preview.subject}</div>
                  <div className="mt-1 whitespace-pre-wrap text-foreground/80">{preview.message}</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-xl border bg-background p-4 text-sm">
              <div className="text-xs text-muted-foreground">Activity entry</div>
              <div className="mt-1">{renderChip(form.message ?? "")}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
