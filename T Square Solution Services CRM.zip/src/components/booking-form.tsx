import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { ArrowLeft, Save } from "lucide-react";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, newId, type Booking, type Customer } from "@/lib/data-store";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";

const STATUSES = ["Scheduled", "In progress", "Completed", "Cancelled"];

export function BookingForm({ editing }: { editing?: Booking }) {
  const { customers, services, staff, add, update, ensureCustomer } = useStore();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    customer: editing?.customer ?? "",
    email: editing?.email ?? "",
    phone: editing?.phone ?? "",
    address: editing?.address ?? "",
    service: editing?.service ?? "",
    date: editing?.date ?? new Date().toISOString().slice(0, 10),
    time: editing?.time ?? "09:00",
    assignee: editing?.assignee ?? staff[0]?.name ?? "",
    status: editing?.status ?? "Scheduled",
    price: editing?.price ?? 0,
    notes: editing?.notes ?? "",
  });
  const [customerQuery, setCustomerQuery] = useState("");

  const customerMatches = useMemo(() => {
    const q = customerQuery.trim().toLowerCase();
    if (!q) return [];
    return customers.filter((c) => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)).slice(0, 5);
  }, [customerQuery, customers]);

  const pickCustomer = (c: Customer) => {
    setForm((f) => ({ ...f, customer: c.name, email: c.email, phone: c.phone, address: c.address ?? "" }));
    setCustomerQuery("");
  };

  const submit = () => {
    if (!form.customer.trim()) return toast.error("Customer is required");
    if (!form.service.trim()) return toast.error("Pick a service");
    const cust = ensureCustomer({ name: form.customer, email: form.email, phone: form.phone, address: form.address });
    if (editing) {
      update("bookings", editing.id, { ...form });
      toast.success("Booking updated");
    } else {
      const id = newId("b");
      add("bookings", { id, ...form });
      fireEvent({
        trigger: "booking.created",
        payload: { id, customer: form.customer, email: form.email, service: form.service, date: form.date, time: form.time },
      });
      logActivity({ actor: "You", entity: "booking", entityId: id, action: "created", summary: `${form.customer} — ${form.service}` });
      toast.success("Booking created for " + cust.name);
    }
    navigate({ to: "/bookings" });
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" className="w-fit" onClick={() => navigate({ to: "/bookings" })}>
        <ArrowLeft className="mr-2 h-4 w-4" /> All bookings
      </Button>
      <PageHeader
        title={editing ? `Edit booking ${editing.id}` : "New booking"}
        description="Schedule a job and dispatch it to a team member."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => navigate({ to: "/bookings" })}>Cancel</Button>
            <Button size="sm" onClick={submit}><Save className="mr-2 h-4 w-4" /> {editing ? "Save changes" : "Create booking"}</Button>
          </>
        }
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardContent className="space-y-4 p-6">
            <div className="text-sm font-semibold">Customer</div>
            <div>
              <Label>Customer name</Label>
              <Input
                value={form.customer}
                onChange={(e) => { setForm({ ...form, customer: e.target.value }); setCustomerQuery(e.target.value); }}
                placeholder="Type to search or add new"
              />
              {customerMatches.length > 0 && (
                <div className="mt-1 rounded-md border bg-popover text-sm shadow-sm">
                  {customerMatches.map((c) => (
                    <button type="button" key={c.id} onClick={() => pickCustomer(c)} className="flex w-full items-center justify-between px-3 py-2 text-left hover:bg-accent">
                      <span>{c.name}</span>
                      <span className="text-xs text-muted-foreground">{c.email}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            </div>
            <div><Label>Address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div><Label>Notes</Label><Textarea rows={4} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Access codes, special requests, etc." /></div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="space-y-3 p-6">
            <div className="text-sm font-semibold">Job details</div>
            <div>
              <Label>Service</Label>
              <Select value={form.service} onValueChange={(v) => {
                const svc = services.find((s) => s.name === v);
                setForm({ ...form, service: v, price: svc?.basePrice ?? form.price });
              }}>
                <SelectTrigger><SelectValue placeholder="Select service" /></SelectTrigger>
                <SelectContent>{services.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Price ($)</Label>
              <Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Date</Label><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
              <div><Label>Time</Label><Input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} /></div>
            </div>
            <div>
              <Label>Assignee</Label>
              <Select value={form.assignee || staff[0]?.name} onValueChange={(v) => setForm({ ...form, assignee: v })}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>{staff.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
