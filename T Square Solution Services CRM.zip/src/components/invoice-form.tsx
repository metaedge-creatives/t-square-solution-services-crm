import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { ArrowLeft, Download, Mail, Plus, Save, Trash2 } from "lucide-react";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  useStore,
  type Invoice,
  type InvoiceLineItem,
  type InvoiceStatus,
  type RecurringFrequency,
} from "@/lib/data-store";
import { fireEvent } from "@/lib/automations";
import { logActivity } from "@/lib/activity-log";
import { buildVars, interpolate, useCompanyProfile, useDocTemplates } from "@/lib/company-profile";
import { openMailto, renderInvoicePdf } from "@/lib/pdf";

const STATUSES: InvoiceStatus[] = ["Draft", "Pending Approval", "Sent", "Paid", "Overdue"];

const today = () => new Date().toISOString().slice(0, 10);
const plusDays = (days: number) => {
  const d = new Date(); d.setDate(d.getDate() + days); return d.toISOString().slice(0, 10);
};

function nextInvId(existing: Invoice[]) {
  const nums = existing.map((i) => Number(i.id.replace(/\D/g, ""))).filter(Boolean);
  const next = (nums.length ? Math.max(...nums) : 2080) + 1;
  return `INV-${next}`;
}

const money = (v: number) =>
  `$${(Number.isFinite(v) ? v : 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

function defaultItems(editing?: Invoice): InvoiceLineItem[] {
  if (editing?.items && editing.items.length) return editing.items;
  if (editing) return [{ description: editing.service || "Services rendered", qty: 1, rate: editing.amount }];
  return [{ description: "", qty: 1, rate: 0 }];
}

export function InvoiceForm({ editing }: { editing?: Invoice }) {
  const { invoices, customers, services, add, update, ensureCustomer } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const navigate = useNavigate();

  const [form, setForm] = useState(() => ({
    customer: editing?.customer ?? "",
    email: editing?.email ?? "",
    phone: editing?.phone ?? "",
    address: editing?.address ?? "",
    service: editing?.service ?? "",
    notes: editing?.notes ?? "",
    issued: editing?.issued ?? today(),
    due: editing?.due ?? plusDays(14),
    status: (editing?.status ?? "Draft") as InvoiceStatus,
    taxRate: editing?.taxRate ?? 0,
    discount: editing?.discount ?? 0,
    recurringOn: !!editing?.recurring,
    recurringFreq: (editing?.recurring?.frequency ?? "monthly") as RecurringFrequency,
  }));
  const [items, setItems] = useState<InvoiceLineItem[]>(() => defaultItems(editing));
  const [customerQuery, setCustomerQuery] = useState("");
  const [previewId] = useState(() => editing?.id ?? nextInvId(invoices));

  const customerMatches = useMemo(() => {
    const q = customerQuery.trim().toLowerCase();
    if (!q) return [];
    return customers.filter((c) => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)).slice(0, 5);
  }, [customerQuery, customers]);

  const subtotal = useMemo(() => items.reduce((s, it) => s + (Number(it.qty) || 0) * (Number(it.rate) || 0), 0), [items]);
  const taxAmount = useMemo(() => (subtotal - (Number(form.discount) || 0)) * ((Number(form.taxRate) || 0) / 100), [subtotal, form.discount, form.taxRate]);
  const total = useMemo(() => Math.max(0, subtotal - (Number(form.discount) || 0) + taxAmount), [subtotal, form.discount, taxAmount]);

  const pickCustomer = (name: string) => {
    const c = customers.find((x) => x.name === name);
    setForm((f) => ({
      ...f,
      customer: name,
      email: c?.email ?? f.email,
      phone: c?.phone ?? f.phone,
      address: c?.address ?? f.address,
    }));
    setCustomerQuery("");
  };

  const updateItem = (i: number, patch: Partial<InvoiceLineItem>) =>
    setItems((prev) => prev.map((it, idx) => (idx === i ? { ...it, ...patch } : it)));
  const addItem = () => setItems((prev) => [...prev, { description: "", qty: 1, rate: 0 }]);
  const removeItem = (i: number) => setItems((prev) => prev.filter((_, idx) => idx !== i));

  const buildInvoicePayload = (id: string): Invoice => {
    const { recurringOn, recurringFreq, ...rest } = form;
    const recurring = recurringOn
      ? { frequency: recurringFreq, nextIssue: plusDays({ weekly: 7, biweekly: 14, monthly: 30, quarterly: 90 }[recurringFreq]) }
      : undefined;
    return {
      id,
      ...rest,
      amount: Number(total.toFixed(2)),
      items: items.filter((it) => it.description.trim() || it.rate > 0),
      recurring,
    };
  };

  const persist = (): Invoice => {
    if (!form.customer.trim()) {
      toast.error("Customer is required");
      throw new Error("no customer");
    }
    ensureCustomer({ name: form.customer, email: form.email, phone: form.phone, address: form.address });
    if (editing) {
      const payload = buildInvoicePayload(editing.id);
      update("invoices", editing.id, payload);
      return payload;
    }
    const id = previewId;
    const payload = buildInvoicePayload(id);
    add("invoices", payload);
    fireEvent({ trigger: "invoice.created", payload: { id, customer: form.customer, email: form.email, amount: payload.amount } });
    logActivity({ actor: "You", entity: "invoice", entityId: id, action: "created", summary: `${id} · ${money(payload.amount)}` });
    return payload;
  };

  const submit = () => {
    try {
      persist();
      toast.success(editing ? "Invoice updated" : "Invoice created");
      navigate({ to: "/invoices" });
    } catch {/* handled */}
  };

  const buildPdf = async (inv: Invoice) =>
    renderInvoicePdf(
      {
        id: inv.id,
        customer: inv.customer,
        customerEmail: inv.email,
        customerPhone: inv.phone,
        customerAddress: inv.address,
        amount: inv.amount,
        issued: inv.issued,
        due: inv.due,
        status: inv.status,
        lineItems: (inv.items && inv.items.length ? inv.items : [{ description: inv.service || "Services rendered", qty: 1, rate: inv.amount }]),
      },
      company,
      docs,
    );

  const downloadPdf = async () => {
    try {
      const inv = persist();
      const doc = await buildPdf(inv);
      doc.save(`${inv.id}-${inv.customer.replace(/\s+/g, "-")}.pdf`);
      toast.success("PDF downloaded");
    } catch {/* handled */}
  };

  const emailPdf = async () => {
    try {
      const inv = persist();
      if (!inv.email) return toast.error("Add a customer email first");
      const doc = await buildPdf(inv);
      doc.save(`${inv.id}-${inv.customer.replace(/\s+/g, "-")}.pdf`);
      const vars = buildVars(company, { invoice_id: inv.id, customer_name: inv.customer, amount: inv.amount.toFixed(2), due_date: inv.due });
      openMailto(inv.email, interpolate(docs.invoiceEmailSubject, vars), interpolate(docs.invoiceEmailBody, vars));
      update("invoices", inv.id, { status: "Sent" });
      toast.success("Email drafted — attach the downloaded PDF");
    } catch {/* handled */}
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" className="w-fit" onClick={() => navigate({ to: "/invoices" })}>
        <ArrowLeft className="mr-2 h-4 w-4" /> All invoices
      </Button>
      <PageHeader
        title={editing ? `Edit ${editing.id}` : "New invoice"}
        description="Edit details on the left, preview updates live on the right."
        actions={
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={downloadPdf}><Download className="mr-2 h-4 w-4" /> PDF</Button>
            <Button variant="outline" size="sm" onClick={emailPdf}><Mail className="mr-2 h-4 w-4" /> Email</Button>
            <Button variant="outline" size="sm" onClick={() => navigate({ to: "/invoices" })}>Cancel</Button>
            <Button size="sm" onClick={submit}><Save className="mr-2 h-4 w-4" /> {editing ? "Save changes" : "Create invoice"}</Button>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* LEFT: form */}
        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Customer</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Customer name</Label>
                <Input
                  value={form.customer}
                  onChange={(e) => { setForm({ ...form, customer: e.target.value }); setCustomerQuery(e.target.value); }}
                  placeholder="Type to search or add a new customer"
                />
                {customerMatches.length > 0 && (
                  <div className="mt-1 rounded-md border bg-popover text-sm shadow-sm">
                    {customerMatches.map((c) => (
                      <button key={c.id} type="button" onClick={() => pickCustomer(c.name)} className="flex w-full items-center justify-between px-3 py-2 text-left hover:bg-accent">
                        <span>{c.name}</span><span className="text-xs text-muted-foreground">{c.email}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              </div>
              <div><Label>Billing address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Street, City, ZIP" /></div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Line items</CardTitle>
              <Button size="sm" variant="outline" onClick={addItem}><Plus className="mr-2 h-4 w-4" /> Add item</Button>
            </CardHeader>
            <CardContent className="space-y-3">
              {items.map((it, i) => (
                <div key={i} className="grid grid-cols-12 gap-2">
                  <Input className="col-span-6" placeholder="Description" value={it.description} onChange={(e) => updateItem(i, { description: e.target.value })} />
                  <Input className="col-span-2" type="number" min={0} step="0.01" placeholder="Qty" value={it.qty} onChange={(e) => updateItem(i, { qty: Number(e.target.value) || 0 })} />
                  <Input className="col-span-3" type="number" min={0} step="0.01" placeholder="Rate" value={it.rate} onChange={(e) => updateItem(i, { rate: Number(e.target.value) || 0 })} />
                  <Button className="col-span-1" variant="ghost" size="icon" onClick={() => removeItem(i)} disabled={items.length === 1}><Trash2 className="h-4 w-4" /></Button>
                </div>
              ))}
              {services.length > 0 && (
                <div>
                  <Label>Quick add from services</Label>
                  <Select value="" onValueChange={(v) => {
                    const s = services.find((x) => x.name === v);
                    if (s) setItems((prev) => [...prev, { description: s.name, qty: 1, rate: (s as unknown as { price?: number }).price ?? 0 }]);
                  }}>
                    <SelectTrigger><SelectValue placeholder="Insert service…" /></SelectTrigger>
                    <SelectContent>{services.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
              <div className="grid gap-3 sm:grid-cols-2 pt-2 border-t">
                <div><Label>Discount ($)</Label><Input type="number" min={0} step="0.01" value={form.discount} onChange={(e) => setForm({ ...form, discount: Number(e.target.value) || 0 })} /></div>
                <div><Label>Tax rate (%)</Label><Input type="number" min={0} step="0.01" value={form.taxRate} onChange={(e) => setForm({ ...form, taxRate: Number(e.target.value) || 0 })} /></div>
              </div>
              <div className="flex flex-col items-end gap-1 pt-2 text-sm">
                <div className="text-muted-foreground">Subtotal: {money(subtotal)}</div>
                {form.discount > 0 && <div className="text-muted-foreground">Discount: −{money(form.discount)}</div>}
                {form.taxRate > 0 && <div className="text-muted-foreground">Tax ({form.taxRate}%): {money(taxAmount)}</div>}
                <div className="text-lg font-semibold">Total: {money(total)}</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Details</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-3">
                <div><Label>Issued</Label><Input type="date" value={form.issued} onChange={(e) => setForm({ ...form, issued: e.target.value })} /></div>
                <div><Label>Due</Label><Input type="date" value={form.due} onChange={(e) => setForm({ ...form, due: e.target.value })} /></div>
                <div>
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as InvoiceStatus })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label>Notes</Label><Textarea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Payment terms, thank-you note…" /></div>
              <div className="flex items-center justify-between gap-3 border-t pt-3">
                <div>
                  <div className="font-medium text-sm">Recurring invoice</div>
                  <div className="text-xs text-muted-foreground">Auto-generate on a schedule.</div>
                </div>
                <label className="inline-flex items-center gap-2 text-xs">
                  <input type="checkbox" className="h-4 w-4 accent-primary" checked={form.recurringOn} onChange={(e) => setForm({ ...form, recurringOn: e.target.checked })} /> Enable
                </label>
              </div>
              {form.recurringOn && (
                <Select value={form.recurringFreq} onValueChange={(v) => setForm({ ...form, recurringFreq: v as RecurringFrequency })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="biweekly">Bi-weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </CardContent>
          </Card>
        </div>

        {/* RIGHT: live preview */}
        <div className="lg:sticky lg:top-4 lg:self-start">
          <Card>
            <CardHeader><CardTitle className="text-base">Live preview</CardTitle></CardHeader>
            <CardContent>
              <div className="overflow-hidden rounded-lg border bg-background shadow-sm">
                <div className="bg-primary px-6 py-5 text-primary-foreground">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <img src="/tsquare-logo.png" alt="" className="h-11 w-auto object-contain" />
                      <div>
                        <div className="font-display text-xl font-bold leading-tight">{company.name}</div>
                        <div className="mt-0.5 text-xs opacity-90">{[company.email, company.phone, company.website].filter(Boolean).join(" · ")}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-display text-2xl font-bold tracking-wide">INVOICE</div>
                      <div className="text-sm opacity-90">{previewId}</div>
                    </div>
                  </div>
                </div>
                <div className="h-0.5 w-full bg-secondary" />

                <div className="grid gap-6 p-6 md:grid-cols-2">
                  <div>
                    <div className="mb-2 text-xs font-semibold uppercase text-muted-foreground">Bill to</div>
                    <div className="font-semibold">{form.customer || "Customer name"}</div>
                    <div className="text-sm text-muted-foreground">{form.email || "email@example.com"}</div>
                    <div className="text-sm text-muted-foreground">{form.phone || "—"}</div>
                    <div className="text-sm text-muted-foreground">{form.address || "—"}</div>
                  </div>
                  <div className="rounded-lg bg-primary-soft p-4 text-sm space-y-1">
                    <div className="flex justify-between"><span className="font-semibold uppercase text-muted-foreground text-xs">Issued</span><span>{form.issued}</span></div>
                    <div className="flex justify-between"><span className="font-semibold uppercase text-muted-foreground text-xs">Due</span><span>{form.due}</span></div>
                    <div className="flex justify-between"><span className="font-semibold uppercase text-muted-foreground text-xs">Status</span><span>{form.status}</span></div>
                  </div>
                </div>
                <div className="px-6 pb-6">
                  <Table>
                    <TableHeader><TableRow><TableHead>Description</TableHead><TableHead className="text-right">Qty</TableHead><TableHead className="text-right">Rate</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {items.map((it, i) => (
                        <TableRow key={i}>
                          <TableCell>{it.description || <span className="text-muted-foreground">Item description</span>}</TableCell>
                          <TableCell className="text-right">{it.qty}</TableCell>
                          <TableCell className="text-right">{money(it.rate)}</TableCell>
                          <TableCell className="text-right font-semibold">{money((it.qty || 0) * (it.rate || 0))}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <div className="mt-4 flex justify-end">
                    <div className="w-full max-w-xs space-y-1 text-sm">
                      <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{money(subtotal)}</span></div>
                      {form.discount > 0 && <div className="flex justify-between"><span className="text-muted-foreground">Discount</span><span>−{money(form.discount)}</span></div>}
                      {form.taxRate > 0 && <div className="flex justify-between"><span className="text-muted-foreground">Tax ({form.taxRate}%)</span><span>{money(taxAmount)}</span></div>}
                      <div className="mt-2 rounded-lg bg-primary px-4 py-3 text-primary-foreground">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold uppercase opacity-90">Total due</span>
                          <span className="font-display text-xl font-bold">{money(total)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  {form.notes && <div className="mt-6 rounded-md bg-muted/50 p-3 text-sm"><div className="mb-1 text-xs font-semibold uppercase text-muted-foreground">Notes</div>{form.notes}</div>}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
