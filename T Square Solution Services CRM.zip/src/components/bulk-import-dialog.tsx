import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Upload, FileText, Info } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export interface BulkImportField {
  key: string;
  label: string;
  required?: boolean;
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  description?: string;
  fields: BulkImportField[];
  /** Called with parsed rows; return number successfully imported. */
  onImport: (rows: Record<string, string>[]) => number | Promise<number>;
  placeholder?: string;
  sampleRow?: string;
}

/** Split a CSV line respecting simple quoted values. */
function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQ && line[i + 1] === '"') { cur += '"'; i++; }
      else inQ = !inQ;
    } else if ((ch === "," || ch === "\t") && !inQ) {
      out.push(cur);
      cur = "";
    } else cur += ch;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

export function BulkImportDialog({
  open, onOpenChange, title, description, fields, onImport, placeholder, sampleRow,
}: Props) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  const parsed = useMemo(() => {
    const rows: Record<string, string>[] = [];
    const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    for (const line of lines) {
      const cells = splitCsvLine(line);
      const row: Record<string, string> = {};
      fields.forEach((f, i) => { row[f.key] = cells[i] ?? ""; });
      rows.push(row);
    }
    return rows;
  }, [text, fields]);

  const valid = useMemo(
    () => parsed.filter((r) => fields.every((f) => !f.required || (r[f.key] ?? "").trim())),
    [parsed, fields],
  );

  const handleFile = async (file: File) => {
    const t = await file.text();
    // Skip header row if it looks like column names
    const lines = t.split(/\r?\n/);
    if (lines[0] && fields.some((f) => lines[0].toLowerCase().includes(f.key.toLowerCase()) || lines[0].toLowerCase().includes(f.label.toLowerCase()))) {
      lines.shift();
    }
    setText(lines.join("\n"));
  };

  const submit = async () => {
    if (valid.length === 0) { toast.error("No valid rows to import"); return; }
    setBusy(true);
    try {
      const n = await onImport(valid);
      toast.success(`Imported ${n} record${n === 1 ? "" : "s"}`);
      setText("");
      onOpenChange(false);
    } finally { setBusy(false); }
  };

  const template = fields.map((f) => f.label).join(", ");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>

        <div className="space-y-3">
          <div className="rounded-md border bg-muted/40 p-3 text-xs">
            <div className="mb-1 flex items-center gap-1.5 font-medium text-foreground">
              <Info className="h-3.5 w-3.5" /> Column order (comma or tab separated)
            </div>
            <code className="text-[11px] text-muted-foreground">{template}</code>
            {sampleRow && (
              <div className="mt-2 text-[11px] text-muted-foreground">
                <span className="font-medium text-foreground">Example:</span>{" "}
                <code>{sampleRow}</code>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Label htmlFor="bulk-file" className="cursor-pointer">
              <span className="inline-flex items-center gap-1.5 rounded-md border bg-background px-3 py-1.5 text-xs font-medium hover:bg-muted">
                <Upload className="h-3.5 w-3.5" /> Upload CSV
              </span>
              <input
                id="bulk-file"
                type="file"
                accept=".csv,.tsv,.txt"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
              />
            </Label>
            <span className="text-xs text-muted-foreground">or paste rows below (one per line)</span>
          </div>

          <div>
            <Textarea
              rows={10}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={placeholder ?? sampleRow ?? "Paste rows here…"}
              className="font-mono text-xs"
            />
          </div>

          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-muted-foreground">
              <FileText className="h-3.5 w-3.5" />
              {parsed.length} row{parsed.length === 1 ? "" : "s"} detected
              {parsed.length !== valid.length && (
                <span className="text-destructive">
                  · {parsed.length - valid.length} skipped (missing required)
                </span>
              )}
            </div>
            {valid.length > 0 && (
              <span className="rounded-full bg-primary-soft px-2 py-0.5 text-primary">
                {valid.length} ready to import
              </span>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Cancel</Button>
          <Button onClick={submit} disabled={busy || valid.length === 0}>
            {busy ? "Importing…" : `Import ${valid.length || ""}`.trim()}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
