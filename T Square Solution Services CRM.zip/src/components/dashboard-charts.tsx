import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

import { revenueSeries } from "@/lib/mock-data";

export function RevenueChart() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={revenueSeries} margin={{ left: 4, right: 4, top: 4 }}>
        <defs>
          <linearGradient id="revFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.35} />
            <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" vertical={false} />
        <XAxis dataKey="month" stroke="var(--color-muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="var(--color-muted-foreground)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} formatter={(v: number) => [`$${v.toLocaleString()}`, "Revenue"]} />
        <Area type="monotone" dataKey="revenue" stroke="var(--color-primary)" strokeWidth={2.5} fill="url(#revFill)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function ServicesBarChart({ data }: { data: { service: string; jobs: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={data} layout="vertical" margin={{ left: 12 }}>
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="service" stroke="var(--color-muted-foreground)" fontSize={12} tickLine={false} axisLine={false} width={110} />
        <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid var(--color-border)" }} />
        <Bar dataKey="jobs" radius={[0, 8, 8, 0]} fill="var(--color-primary)" />
      </BarChart>
    </ResponsiveContainer>
  );
}
