import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Users,
  Sparkles,
  FileText,
  CalendarDays,
  UserCog,
  ClipboardCheck,
  Receipt,
  Star,
  Settings,
  Bell,
  Search,
  LogOut,
  Target,
  Menu,
  Mail,
  FileSignature,
  BarChart3,
  Zap,
  History,
} from "lucide-react";

import { useEffect, useMemo, useState, type ReactNode } from "react";

import { BrandLogo } from "@/components/brand-logo";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/lib/auth";
import { useStore } from "@/lib/data-store";
import { cn } from "@/lib/utils";

interface NavChild {
  hash: string;
  label: string;
}

interface NavItem {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  permission: import("@/lib/data-store").Permission;
  children?: NavChild[];
}

const NAV: NavItem[] = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, permission: "dashboard" },
  { to: "/leads", label: "Leads", icon: Target, permission: "leads" },
  { to: "/quotes", label: "Quotes", icon: FileText, permission: "quotes" },
  { to: "/customers", label: "Customers", icon: Users, permission: "customers" },
  {
    to: "/email-marketing",
    label: "Email Marketing",
    icon: Mail,
    permission: "email",
    children: [
      { hash: "campaigns", label: "Campaigns" },
      { hash: "audiences", label: "Audiences" },
      { hash: "templates", label: "Templates" },
      { hash: "integrations", label: "Integrations" },
    ],
  },
  { to: "/bookings", label: "Bookings", icon: CalendarDays, permission: "bookings" },
  { to: "/staff", label: "Staff", icon: UserCog, permission: "staff" },
  { to: "/inspections", label: "Inspections", icon: ClipboardCheck, permission: "inspections" },
  { to: "/invoices", label: "Invoices", icon: Receipt, permission: "invoices" },
  { to: "/contracts", label: "Contracts", icon: FileSignature, permission: "contracts" },

  { to: "/automations", label: "Automations", icon: Zap, permission: "automations" },
  { to: "/reports", label: "Reports", icon: BarChart3, permission: "reports" },
  { to: "/activity", label: "Activity", icon: History, permission: "activity" },
  { to: "/settings", label: "Settings", icon: Settings, permission: "settings" },
];




function SidebarNav({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hash = useRouterState({ select: (s) => s.location.hash });
  const { hasPermission } = useAuth();
  const items = NAV.filter((n) => hasPermission(n.permission));
  return (
    <nav className="flex-1 space-y-1 px-3 py-4">
      {items.map((item) => {
        const active = pathname === item.to || pathname.startsWith(item.to + "/");
        const Icon = item.icon;

        return (
          <div key={item.to}>
            <Link
              to={item.to}
              onClick={onNavigate}
              className={cn(
                "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground",
              )}
            >
              <Icon className="h-4 w-4" />
              <span>{item.label}</span>
              {active && (
                <span className="ml-auto h-1.5 w-1.5 rounded-full bg-secondary" aria-hidden />
              )}
            </Link>
            {item.children && active && (
              <div className="mt-1 space-y-0.5 border-l border-border/60 pl-3 ml-5">
                {item.children.map((child) => {
                  const childActive =
                    hash === child.hash ||
                    (!hash && child.hash === item.children![0].hash);
                  return (
                    <Link
                      key={child.hash}
                      to={item.to}
                      hash={child.hash}
                      onClick={onNavigate}
                      className={cn(
                        "block rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                        childActive
                          ? "bg-accent text-foreground"
                          : "text-muted-foreground hover:bg-accent hover:text-foreground",
                      )}
                    >
                      {child.label}
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </nav>
  );
}


function SidebarPanel({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center border-b px-5">
        <BrandLogo />
      </div>
      <SidebarNav onNavigate={onNavigate} />
      <div className="border-t p-4">
        <div className="rounded-xl bg-gradient-to-br from-primary to-primary/70 p-4 text-primary-foreground">
          <div className="font-display text-sm font-semibold">Field-ready CRM</div>
          <p className="mt-1 text-xs text-primary-foreground/85">
            Track every job, from quote to sparkling finish.
          </p>
        </div>
      </div>
    </div>
  );
}

function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const { customers, leads, bookings, invoices, quotes, staff } = useStore();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const go = (to: string) => {
    setOpen(false);
    setQ("");
    navigate({ to });
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="relative hidden max-w-sm flex-1 items-center md:flex"
      >
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          readOnly
          placeholder="Search customers, bookings, invoices…"
          className="h-9 cursor-pointer pl-9 pr-16"
        />
        <kbd className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 select-none items-center gap-1 rounded border bg-muted px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground sm:inline-flex">
          ⌘K
        </kbd>
      </button>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        className="md:hidden"
        onClick={() => setOpen(true)}
        aria-label="Search"
      >
        <Search className="h-5 w-5" />
      </Button>


      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Search everything…" value={q} onValueChange={setQ} />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          <CommandGroup heading="Pages">
            {NAV.map((n) => (
              <CommandItem key={n.to} value={`page ${n.label}`} onSelect={() => go(n.to)}>
                <n.icon className="mr-2 h-4 w-4" /> {n.label}
              </CommandItem>
            ))}
          </CommandGroup>
          {customers.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Customers">
                {customers.slice(0, 8).map((c) => (
                  <CommandItem
                    key={c.id}
                    value={`customer ${c.name} ${c.email} ${c.phone}`}
                    onSelect={() => go("/customers")}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    <div className="flex flex-col">
                      <span>{c.name}</span>
                      <span className="text-xs text-muted-foreground">{c.email}</span>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
          {leads.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Leads">
                {leads.slice(0, 8).map((l) => (
                  <CommandItem
                    key={l.id}
                    value={`lead ${l.name} ${l.email} ${l.source}`}
                    onSelect={() => go("/leads")}
                  >
                    <Target className="mr-2 h-4 w-4" /> {l.name}
                    <span className="ml-auto text-xs text-muted-foreground">{l.stage}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
          {bookings.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Bookings">
                {bookings.slice(0, 8).map((b) => (
                  <CommandItem
                    key={b.id}
                    value={`booking ${b.customer} ${b.service} ${b.assignee}`}
                    onSelect={() => go("/bookings")}
                  >
                    <CalendarDays className="mr-2 h-4 w-4" /> {b.customer}
                    <span className="ml-auto text-xs text-muted-foreground">
                      {b.date} · {b.service}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
          {invoices.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Invoices">
                {invoices.slice(0, 8).map((i) => (
                  <CommandItem
                    key={i.id}
                    value={`invoice ${i.id} ${i.customer}`}
                    onSelect={() => go("/invoices")}
                  >
                    <Receipt className="mr-2 h-4 w-4" /> {i.customer}
                    <span className="ml-auto text-xs text-muted-foreground">
                      ${i.amount.toLocaleString()} · {i.status}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
          {quotes.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Quotes">
                {quotes.slice(0, 6).map((qi) => (
                  <CommandItem
                    key={qi.id}
                    value={`quote ${qi.id} ${qi.customer} ${qi.service}`}
                    onSelect={() => go("/quotes")}
                  >
                    <FileText className="mr-2 h-4 w-4" /> {qi.customer}
                    <span className="ml-auto text-xs text-muted-foreground">
                      ${qi.amount.toLocaleString()} · {qi.status}
                    </span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
          {staff.length > 0 && (
            <>
              <CommandSeparator />
              <CommandGroup heading="Staff">
                {staff.slice(0, 6).map((s) => (
                  <CommandItem
                    key={s.id}
                    value={`staff ${s.name} ${s.role}`}
                    onSelect={() => go("/staff")}
                  >
                    <UserCog className="mr-2 h-4 w-4" /> {s.name}
                    <span className="ml-auto text-xs text-muted-foreground">{s.role}</span>
                  </CommandItem>
                ))}
              </CommandGroup>
            </>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}

interface Notification {
  id: string;
  title: string;
  body: string;
  when: string;
  tone: "default" | "warning" | "success";
  to: string;
}

function useNotifications(): Notification[] {
  const { invoices, leads, bookings } = useStore();
  return useMemo(() => {
    const items: Notification[] = [];
    for (const i of invoices) {
      if (i.status === "Overdue") {
        items.push({
          id: `n_inv_${i.id}`,
          title: `Invoice overdue — ${i.customer}`,
          body: `$${i.amount.toLocaleString()} due ${i.due}`,
          when: i.due,
          tone: "warning",
          to: "/invoices",
        });
      }
    }
    for (const l of leads) {
      if (l.stage === "New") {
        items.push({
          id: `n_lead_${l.id}`,
          title: `New lead — ${l.name}`,
          body: `${l.source} · $${l.value.toLocaleString()} potential`,
          when: "just now",
          tone: "default",
          to: "/leads",
        });
      }
    }
    for (const b of bookings.slice(0, 3)) {
      items.push({
        id: `n_book_${b.id}`,
        title: `Upcoming booking — ${b.customer}`,
        body: `${b.date} at ${b.time} · ${b.service}`,
        when: b.date,
        tone: "default",
        to: "/bookings",
      });
    }
    return items.slice(0, 20);
  }, [invoices, leads, bookings]);
}


function NotificationBell() {
  const notifications = useNotifications();
  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const navigate = useNavigate();

  const visible = notifications.filter((n) => !dismissed.has(n.id));
  const unread = visible.length;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
          <Bell className="h-5 w-5" />
          {unread > 0 && (
            <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-secondary px-1 text-[10px] font-bold text-secondary-foreground ring-2 ring-background">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-96 p-0">
        <div className="flex items-center justify-between border-b px-4 py-3">
          <div className="font-display text-sm font-semibold">Notifications</div>
          {unread > 0 && (
            <button
              type="button"
              onClick={() => setDismissed(new Set(notifications.map((n) => n.id)))}
              className="text-xs text-primary hover:underline"
            >
              Mark all read
            </button>
          )}
        </div>
        <ScrollArea className="max-h-96">
          {visible.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-muted-foreground">
              You're all caught up.
            </div>
          ) : (
            <ul className="divide-y">
              {visible.map((n) => (
                <li key={n.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setDismissed((prev) => new Set(prev).add(n.id));
                      setOpen(false);
                      navigate({ to: n.to });
                    }}
                    className="flex w-full items-start gap-3 px-4 py-3 text-left transition hover:bg-accent"
                  >
                    <span
                      className={cn(
                        "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                        n.tone === "warning" && "bg-destructive",
                        n.tone === "success" && "bg-success",
                        n.tone === "default" && "bg-primary",
                      )}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{n.title}</div>
                      <div className="truncate text-xs text-muted-foreground">{n.body}</div>
                      <div className="mt-0.5 text-[10px] uppercase tracking-wide text-muted-foreground">
                        {n.when}
                      </div>
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const initials = (user?.name ?? "T S")
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
  useEffect(() => {
    let gPressed = false;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const map: Record<string, string> = {
      d: "/dashboard", l: "/leads", c: "/customers", b: "/bookings",
      i: "/invoices", q: "/quotes", r: "/reports",
      a: "/automations", e: "/email-marketing", h: "/activity",
    };
    const onKey = (e: KeyboardEvent) => {
      const tgt = e.target as HTMLElement | null;
      if (tgt && (tgt.tagName === "INPUT" || tgt.tagName === "TEXTAREA" || tgt.isContentEditable)) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === "g") {
        gPressed = true;
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => { gPressed = false; }, 900);
        return;
      }
      if (gPressed && map[e.key]) {
        e.preventDefault();
        gPressed = false;
        navigate({ to: map[e.key] });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);


  const handleLogout = () => {
    logout();
    navigate({ to: "/login", replace: true });
  };

  return (
    <div className="flex min-h-screen bg-surface">
      <aside className="hidden w-64 shrink-0 border-r bg-sidebar text-sidebar-foreground lg:block">
        <SidebarPanel />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur sm:px-6">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0">
              <SidebarPanel onNavigate={() => setMobileOpen(false)} />
            </SheetContent>
          </Sheet>

          <GlobalSearch />

          <div className="ml-auto flex items-center gap-2">
            <NotificationBell />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-full border bg-card py-1 pl-1 pr-3 transition hover:bg-accent">
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="bg-primary text-xs text-primary-foreground">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden text-left text-xs leading-tight sm:block">
                    <div className="font-semibold text-foreground">{user?.name ?? "Guest"}</div>
                    <div className="capitalize text-muted-foreground">{user?.role ?? ""}</div>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="font-medium">{user?.name}</div>
                  <div className="truncate text-xs font-normal text-muted-foreground">{user?.email}</div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate({ to: "/settings" })}>
                  <Settings className="mr-2 h-4 w-4" /> Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive">
                  <LogOut className="mr-2 h-4 w-4" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="min-w-0 flex-1 overflow-x-hidden px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
          {title}
        </h1>
        {description && (
          <p className="mt-1 text-sm text-muted-foreground">{description}</p>
        )}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}
