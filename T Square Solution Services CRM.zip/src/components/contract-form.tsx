import { useMemo, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { ArrowLeft, Save, RotateCcw } from "lucide-react";

import { PageHeader } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useStore, type Contract, type ContractStatus } from "@/lib/data-store";
import {
  buildVars,
  interpolate,
  useCompanyProfile,
  useDocTemplates,
} from "@/lib/company-profile";

const STATUSES: ContractStatus[] = ["Draft", "Sent", "Signed", "Expired"];

const today = () => new Date().toISOString().slice(0, 10);
const plusDays = (days: number) => {
  const d = new Date(); d.setDate(d.getDate() + days); return d.toISOString().slice(0, 10);
};

function nextContractId(existing: Contract[]) {
  const nums = existing.map((c) => Number(c.id.replace(/\D/g, ""))).filter(Boolean);
  const next = (nums.length ? Math.max(...nums) : 3000) + 1;
  return `CT-${next}`;
}

const VARIABLES: { key: string; label: string }[] = [
  { key: "customer_name", label: "Customer name" },
  { key: "customer_email", label: "Customer email" },
  { key: "service", label: "Service" },
  { key: "amount", label: "Amount" },
  { key: "start_date", label: "Start date" },
  { key: "end_date", label: "End date" },
  { key: "today", label: "Today" },
  { key: "company_name", label: "Company name" },
  { key: "company_email", label: "Company email" },
  { key: "company_phone", label: "Company phone" },
  { key: "company_address", label: "Company address" },
  { key: "payment_instructions", label: "Payment terms" },
];

export function ContractForm({ editing }: { editing?: Contract }) {
  const { contracts, customers, services, add, update, ensureCustomer } = useStore();
  const company = useCompanyProfile();
  const docs = useDocTemplates();
  const navigate = useNavigate();

  const [form, setForm] = useState(() => ({
    customer: editing?.customer ?? "",
    customerEmail: editing?.customerEmail ?? "",
    customerPhone: editing?.customerPhone ?? "",
    customerAddress: editing?.customerAddress ?? "",
    service: editing?.service ?? services[0]?.name ?? "",
    amount: editing?.amount ?? 0,
    startDate: editing?.startDate ?? today(),
    endDate: editing?.endDate ?? plusDays(365),
    status: (editing?.status ?? "Draft") as ContractStatus,
    body: editing?.body ?? "",
    terms: editing?.terms ?? "",
  }));
  const [customerQuery, setCustomerQuery] = useState("");
  const bodyRef = useRef<HTMLTextAreaElement | null>(null);

  const customerMatches = useMemo(() => {
    const q = customerQuery.trim().toLowerCase();
    if (!q) return [];
    return customers.filter((c) => c.name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)).slice(0, 5);
  }, [customerQuery, customers]);

  const pickCustomer = (name: string) => {
    const c = customers.find((x) => x.name === name);
    setForm((f) => ({
      ...f,
      customer: name,
      customerEmail: c?.email ?? f.customerEmail,
      customerPhone: c?.phone ?? f.customerPhone,
      customerAddress: c?.address ?? f.customerAddress,
    }));
    setCustomerQuery("");
  };

  const insertVariable = (key: string) => {
    const token = `{{${key}}}`;
    const el = bodyRef.current;
    const base = form.body || docs.contractBody;
    if (!el) {
      setForm((f) => ({ ...f, body: `${base}${token}` }));
      return;
    }
    // ensure textarea is editing current template
    if (!form.body) {
      setForm((f) => ({ ...f, body: base + token }));
      return;
    }
    const start = el.selectionStart ?? base.length;
    const end = el.selectionEnd ?? base.length;
    const next = base.slice(0, start) + token + base.slice(end);
    setForm((f) => ({ ...f, body: next }));
    requestAnimationFrame(() => {
      el.focus();
      el.selectionStart = el.selectionEnd = start + token.length;
    });
  };

  const vars = useMemo(() => buildVars(company, {
    contract_id: editing?.id ?? "CT-NEW",
    customer_name: form.customer || "Client Name",
    customer_email: form.customerEmail || "client@example.com",
    customer_phone: form.customerPhone,
    customer_address: form.customerAddress,
    service: form.service || "Service",
    amount: (form.amount || 0).toFixed(2),
    start_date: form.startDate,
    end_date: form.endDate,
  }), [company, editing?.id, form]);

  const introText = useMemo(() => interpolate(docs.contractIntro, vars), [docs.contractIntro, vars]);
  const middleText = useMemo(() => interpolate(form.body || docs.contractBody, vars), [docs.contractBody, form.body, vars]);
  const termsText = useMemo(() => interpolate(docs.contractTerms, vars), [docs.contractTerms, vars]);

  const submit = () => {
    if (!form.customer.trim()) return toast.error("Customer is required");
    ensureCustomer({ name: form.customer, email: form.customerEmail, phone: form.customerPhone, address: form.customerAddress });
    if (editing) {
      update("contracts", editing.id, { ...form });
      toast.success("Contract updated");
    } else {
      add("contracts", { id: nextContractId(contracts), ...form });
      toast.success("Contract created");
    }
    navigate({ to: "/contracts" });
  };

  return (
    <div className="space-y-6">
      <Button variant="ghost" size="sm" className="w-fit" onClick={() => navigate({ to: "/contracts" })}>
        <ArrowLeft className="mr-2 h-4 w-4" /> All contracts
      </Button>
      <PageHeader
        title={editing ? `Edit ${editing.id}` : "New contract"}
        description="Fill the details on the right — the preview on the left updates live."
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => navigate({ to: "/contracts" })}>Cancel</Button>
            <Button size="sm" onClick={submit}><Save className="mr-2 h-4 w-4" /> {editing ? "Save changes" : "Create contract"}</Button>
          </>
        }
      />

      {/* Variable toolbar */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-2 p-4">
          <span className="text-sm font-medium text-muted-foreground mr-1">Insert variable:</span>
          {VARIABLES.map((v) => (
            <button
              key={v.key}
              type="button"
              onClick={() => insertVariable(v.key)}
              className="rounded-full border bg-background px-3 py-1 text-xs font-medium text-foreground/80 transition hover:border-primary hover:bg-primary/10 hover:text-primary"
              title={`Inserts {{${v.key}}}`}
            >
              {v.label}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setForm((f) => ({ ...f, body: "" }))}
              title="Reset body to default template"
            >
              <RotateCcw className="mr-2 h-3.5 w-3.5" /> Reset template
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* LEFT — preview */}
        <div className="lg:col-span-3">
          <Card className="overflow-hidden">
            <div className="border-b bg-[hsl(195,80%,94%)] px-8 py-6">
              <div className="flex items-start justify-between gap-6">
                <div>
                  <div className="text-[11px] font-semibold uppercase tracking-[0.2em] text-primary/80">Service Agreement</div>
                  <h2 className="mt-1 text-2xl font-semibold tracking-tight">{company.name}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{company.address}</p>
                  <p className="text-sm text-muted-foreground">{company.email} · {company.phone}</p>
                </div>
                <div className="text-right text-xs text-muted-foreground">
                  <div>Contract</div>
                  <div className="text-sm font-semibold text-foreground">{editing?.id ?? "CT-NEW"}</div>
                  <div className="mt-2">{form.startDate} → {form.endDate}</div>
                </div>
              </div>
            </div>
            <CardContent className="bg-background p-8">
              <div className="mx-auto max-w-2xl space-y-5 font-serif text-[13.5px] leading-7 text-foreground/90">
                {/* Auto intro: parties + agreement date */}
                <div className="whitespace-pre-wrap">{introText}</div>

                {/* Highlighted service / value / term callout */}
                <div className="grid grid-cols-3 gap-3 rounded-lg border border-primary/30 bg-primary/5 p-4 font-sans text-xs not-italic">
                  <div>
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-primary/70">Service</div>
                    <div className="mt-1 text-sm font-semibold text-foreground">{form.service || "—"}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-primary/70">Contract value</div>
                    <div className="mt-1 text-sm font-semibold text-foreground">${(form.amount || 0).toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-primary/70">Term</div>
                    <div className="mt-1 text-sm font-semibold text-foreground">{form.startDate} → {form.endDate}</div>
                  </div>
                </div>

                {/* Editable middle body (falls back to default template) */}
                <div className="rounded-md border-l-2 border-primary/40 bg-muted/30 px-4 py-3 whitespace-pre-wrap">
                  {middleText}
                </div>

                {/* Auto closing terms + signature block */}
                <div className="whitespace-pre-wrap text-muted-foreground">{termsText}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* RIGHT — details */}
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardContent className="space-y-4 p-6">
              <div className="text-sm font-semibold">Client</div>
              <div>
                <Label>Customer name</Label>
                <Input
                  value={form.customer}
                  onChange={(e) => { setForm({ ...form, customer: e.target.value }); setCustomerQuery(e.target.value); }}
                  placeholder="Search existing or add new"
                />
                {customerMatches.length > 0 && (
                  <div className="mt-1 rounded-md border bg-popover text-sm shadow-sm">
                    {customerMatches.map((c) => (
                      <button key={c.id} type="button" onClick={() => pickCustomer(c.name)} className="flex w-full items-center justify-between px-3 py-2 text-left hover:bg-accent">
                        <span>{c.name}</span>
                        <span className="text-xs text-muted-foreground">{c.email}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div><Label>Email</Label><Input type="email" value={form.customerEmail} onChange={(e) => setForm({ ...form, customerEmail: e.target.value })} /></div>
                <div><Label>Phone</Label><Input value={form.customerPhone} onChange={(e) => setForm({ ...form, customerPhone: e.target.value })} /></div>
              </div>
              <div>
                <Label>Address</Label>
                <Input value={form.customerAddress} onChange={(e) => setForm({ ...form, customerAddress: e.target.value })} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-3 p-6">
              <div className="text-sm font-semibold">Agreement</div>
              <div>
                <Label>Service</Label>
                {services.length > 0 ? (
                  <Select value={form.service} onValueChange={(v) => setForm({ ...form, service: v })}>
                    <SelectTrigger><SelectValue placeholder="Select service" /></SelectTrigger>
                    <SelectContent>
                      {services.map((s) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} />
                )}
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div>
                  <Label>Contract value ($)</Label>
                  <Input type="number" min={0} value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) || 0 })} />
                </div>
                <div>
                  <Label>Status</Label>
                  <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as ContractStatus })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div><Label>Start date</Label><Input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></div>
                <div><Label>End date</Label><Input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-2 p-6">
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold">Middle body</div>
                <span className="text-[11px] text-muted-foreground">Only this section is editable</span>
              </div>
              <p className="text-[11px] leading-relaxed text-muted-foreground">
                The parties header appears automatically above and the closing terms + signatures appear
                below — both are managed in <span className="font-medium">Settings → Documents</span>.
                Leave empty to use the default middle paragraph.
              </p>
              <Textarea
                ref={bodyRef}
                rows={10}
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                placeholder="Write the scope, deliverables, schedule, or any specific clauses for this contract. Leave empty to use the default text."
                className="text-sm"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
