import { cn } from "@/lib/utils";

export function BrandLogo({ className }: { className?: string; compact?: boolean }) {
  return (
    <div
      className={cn(
        "inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2",
        className
      )}
    >
      <img
        src="/tsquare-logo.png"
        alt="T Square Solution"
        className="h-8 w-auto object-contain"
      />
    </div>
  );
}

