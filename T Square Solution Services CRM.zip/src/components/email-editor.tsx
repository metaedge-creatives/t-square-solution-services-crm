import {
  ArrowDown,
  ArrowUp,
  Columns2,
  Copy,
  Code2,
  Heading1,
  Image as ImageIcon,
  Link as LinkIcon,
  List,
  Minus,
  Monitor,
  MousePointerClick,
  Move,
  Quote,
  Redo2,
  Share2,
  Smartphone,
  Trash2,
  Type,
  Undo2,
  Video,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

/* ---------- Block model ---------- */

export type Align = "left" | "center" | "right";

export type EmailBlock =
  | { id: string; type: "heading"; text: string; level: 1 | 2 | 3; align: Align; color: string }
  | { id: string; type: "text"; text: string; align: Align; color: string; size: number }
  | { id: string; type: "button"; text: string; url: string; bg: string; color: string; align: Align; radius: number }
  | { id: string; type: "image"; src: string; alt: string; width: number; align: Align; url?: string }
  | { id: string; type: "divider"; color: string }
  | { id: string; type: "spacer"; height: number }
  | { id: string; type: "bullets"; items: string[]; color: string }
  | { id: string; type: "quote"; text: string; author: string; accent: string }
  | { id: string; type: "columns"; left: string; right: string; color: string }
  | { id: string; type: "social"; facebook: string; instagram: string; twitter: string; linkedin: string; align: Align }
  | { id: string; type: "video"; thumb: string; url: string; title: string }
  | { id: string; type: "html"; html: string };

const uid = () => Math.random().toString(36).slice(2, 9);

export const DEFAULT_BLOCKS: EmailBlock[] = [
  { id: uid(), type: "heading", text: "Hi {{name}}, welcome!", level: 1, align: "left", color: "#0F1F24" },
  { id: uid(), type: "text", text: "Thanks for choosing T Square Solutions. Here's what happens next.", align: "left", color: "#4a5b62", size: 16 },
  { id: uid(), type: "button", text: "Book your first clean", url: "https://tsquaresulotionservices.com", bg: "#048BA8", color: "#ffffff", align: "left", radius: 10 },
];

export const MERGE_TAGS = [
  { tag: "{{name}}", label: "Customer name" },
  { tag: "{{email}}", label: "Customer email" },
  { tag: "{{phone}}", label: "Customer phone" },
  { tag: "{{company}}", label: "Company name" },
  { tag: "{{date}}", label: "Today's date" },
  { tag: "{{service}}", label: "Service name" },
  { tag: "{{amount}}", label: "Amount" },
];

/* ---------- Compile blocks to email-safe HTML ---------- */

const escape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function blockHtml(b: EmailBlock): string {
  switch (b.type) {
    case "heading": {
      const size = b.level === 1 ? 28 : b.level === 2 ? 22 : 18;
      return `<h${b.level} style="margin:0 0 16px 0;font-family:Georgia,'Times New Roman',serif;font-size:${size}px;line-height:1.25;color:${b.color};font-weight:700;text-align:${b.align};">${escape(b.text)}</h${b.level}>`;
    }
    case "text":
      return `<p style="margin:0 0 16px 0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:${b.color};font-size:${b.size}px;line-height:1.65;text-align:${b.align};">${escape(b.text).replace(/\n/g, "<br/>")}</p>`;
    case "button": {
      const marginLeft = b.align === "center" ? "auto" : b.align === "right" ? "auto" : "0";
      const marginRight = b.align === "center" ? "auto" : b.align === "left" ? "auto" : "0";
      return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 ${marginRight} 20px ${marginLeft};"><tr><td style="border-radius:${b.radius}px;background:${b.bg};"><a href="${escape(b.url)}" style="display:inline-block;padding:14px 28px;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;color:${b.color};text-decoration:none;border-radius:${b.radius}px;">${escape(b.text)}</a></td></tr></table>`;
    }
    case "image": {
      const img = `<img src="${escape(b.src)}" alt="${escape(b.alt)}" width="${b.width}" style="max-width:100%;height:auto;border:0;display:inline-block;border-radius:8px;"/>`;
      const wrapped = b.url ? `<a href="${escape(b.url)}" style="text-decoration:none;">${img}</a>` : img;
      return `<div style="text-align:${b.align};margin:0 0 20px 0;">${wrapped}</div>`;
    }
    case "divider":
      return `<hr style="border:none;border-top:1px solid ${b.color};margin:20px 0;"/>`;
    case "spacer":
      return `<div style="height:${b.height}px;line-height:${b.height}px;font-size:1px;">&nbsp;</div>`;
    case "bullets":
      return `<ul style="margin:0 0 20px 0;padding:0 0 0 20px;color:${b.color};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;font-size:15px;line-height:1.7;">${b.items.map((i) => `<li style="margin:0 0 8px 0;">${escape(i)}</li>`).join("")}</ul>`;
    case "quote":
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px 0;"><tr><td style="border-left:4px solid ${b.accent};padding:8px 18px;font-family:Georgia,serif;font-style:italic;color:#3a4a51;font-size:17px;line-height:1.6;">"${escape(b.text)}"${b.author ? `<div style="margin-top:8px;font-style:normal;font-size:13px;color:#7a8b92;">— ${escape(b.author)}</div>` : ""}</td></tr></table>`;
    case "columns":
      return `<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 20px 0;"><tr><td width="50%" valign="top" style="padding-right:12px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:${b.color};font-size:15px;line-height:1.65;">${escape(b.left).replace(/\n/g, "<br/>")}</td><td width="50%" valign="top" style="padding-left:12px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;color:${b.color};font-size:15px;line-height:1.65;">${escape(b.right).replace(/\n/g, "<br/>")}</td></tr></table>`;
    case "social": {
      const items: [string, string][] = [
        ["Facebook", b.facebook],
        ["Instagram", b.instagram],
        ["Twitter", b.twitter],
        ["LinkedIn", b.linkedin],
      ];
      const links = items.filter(([, u]) => u).map(([n, u]) => `<a href="${escape(u)}" style="display:inline-block;margin:0 8px;padding:8px 14px;background:#048BA8;color:#fff;border-radius:6px;font-family:Arial,sans-serif;font-size:13px;font-weight:600;text-decoration:none;">${n}</a>`).join("");
      return `<div style="text-align:${b.align};margin:0 0 20px 0;">${links}</div>`;
    }
    case "video": {
      const play = `<div style="position:relative;display:inline-block;"><img src="${escape(b.thumb)}" alt="${escape(b.title)}" width="520" style="max-width:100%;height:auto;border-radius:12px;display:block;"/><div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:60px;height:60px;background:rgba(4,139,168,0.92);border-radius:50%;color:#fff;font-size:26px;line-height:60px;text-align:center;">▶</div></div>`;
      return `<div style="text-align:center;margin:0 0 20px 0;"><a href="${escape(b.url)}" style="text-decoration:none;">${play}</a>${b.title ? `<div style="margin-top:10px;font-family:Arial,sans-serif;font-size:14px;color:#4a5b62;">${escape(b.title)}</div>` : ""}</div>`;
    }
    case "html":
      return `<div style="margin:0 0 20px 0;">${b.html}</div>`;
  }
}

export function compileEmail(blocks: EmailBlock[], subject: string): string {
  const P = "#048BA8";
  const S = "#F8DD42";
  const bg = "#E6F3F6";
  const ink = "#0F1F24";
  const inner = blocks.map(blockHtml).join("\n");
  return `<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(subject)}</title></head>
<body style="margin:0;padding:0;background:${bg};font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${bg};padding:32px 12px;">
<tr><td align="center">
  <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:20px;overflow:hidden;box-shadow:0 4px 24px rgba(4,139,168,0.08);">
    <tr><td style="background:${P};padding:20px 32px;" align="left">
      <img src="${typeof window !== 'undefined' ? window.location.origin : ''}/tsquare-logo.png" alt="T Square Solutions" height="44" style="display:block;height:44px;width:auto;border:0;outline:none;text-decoration:none;" />
    </td></tr>
    <tr><td style="padding:36px 40px 24px 40px;">
      ${inner}
    </td></tr>
    <tr><td style="background:#fafcfd;padding:20px 40px;color:#7a8b92;font-size:12px;line-height:1.5;" align="center">
      <div style="margin-bottom:6px;"><strong style="color:${ink};">T Square Solutions</strong> · Trusted cleaning services</div>
      <div>You're receiving this because you're a valued customer.</div>
    </td></tr>
  </table>
</td></tr></table>
</body></html>`;
}

/* ---------- Block factories ---------- */

const factory: Record<EmailBlock["type"], () => EmailBlock> = {
  heading: () => ({ id: uid(), type: "heading", text: "New heading", level: 2, align: "left", color: "#0F1F24" }),
  text: () => ({ id: uid(), type: "text", text: "Write something great here…", align: "left", color: "#4a5b62", size: 16 }),
  button: () => ({ id: uid(), type: "button", text: "Click me", url: "https://", bg: "#048BA8", color: "#ffffff", align: "left", radius: 10 }),
  image: () => ({ id: uid(), type: "image", src: "https://images.unsplash.com/photo-1521783988139-89397d761dce?w=600", alt: "Image", width: 520, align: "center", url: "" }),
  divider: () => ({ id: uid(), type: "divider", color: "#e5eaec" }),
  spacer: () => ({ id: uid(), type: "spacer", height: 24 }),
  bullets: () => ({ id: uid(), type: "bullets", items: ["First point", "Second point", "Third point"], color: "#4a5b62" }),
  quote: () => ({ id: uid(), type: "quote", text: "Absolutely the best cleaning service we've used.", author: "Happy client", accent: "#048BA8" }),
  columns: () => ({ id: uid(), type: "columns", left: "Left column text.", right: "Right column text.", color: "#4a5b62" }),
  social: () => ({ id: uid(), type: "social", facebook: "https://facebook.com/", instagram: "https://instagram.com/", twitter: "", linkedin: "", align: "center" }),
  video: () => ({ id: uid(), type: "video", thumb: "https://images.unsplash.com/photo-1585421514738-01798e348b17?w=600", url: "https://", title: "Watch the walkthrough" }),
  html: () => ({ id: uid(), type: "html", html: "<p>Custom HTML here</p>" }),
};

const GROUPS: { label: string; items: { type: EmailBlock["type"]; label: string; Icon: typeof Type }[] }[] = [
  {
    label: "Content",
    items: [
      { type: "heading", label: "Heading", Icon: Heading1 },
      { type: "text", label: "Text", Icon: Type },
      { type: "bullets", label: "List", Icon: List },
      { type: "quote", label: "Quote", Icon: Quote },
    ],
  },
  {
    label: "Media",
    items: [
      { type: "image", label: "Image", Icon: ImageIcon },
      { type: "video", label: "Video", Icon: Video },
      { type: "button", label: "Button", Icon: MousePointerClick },
    ],
  },
  {
    label: "Layout",
    items: [
      { type: "columns", label: "Columns", Icon: Columns2 },
      { type: "divider", label: "Divider", Icon: Minus },
      { type: "spacer", label: "Spacer", Icon: Move },
      { type: "social", label: "Social", Icon: Share2 },
      { type: "html", label: "HTML", Icon: Code2 },
    ],
  },
];

/* ---------- Editor UI ---------- */

interface Props {
  blocks: EmailBlock[];
  onChange: (blocks: EmailBlock[]) => void;
  subject: string;
}

export function EmailBlockEditor({ blocks, onChange, subject }: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(blocks[0]?.id ?? null);
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const [dragId, setDragId] = useState<string | null>(null);

  // Undo/redo history (block state only)
  const historyRef = useRef<EmailBlock[][]>([blocks]);
  const cursorRef = useRef(0);
  const skipNext = useRef(false);
  useEffect(() => {
    if (skipNext.current) { skipNext.current = false; return; }
    const cur = historyRef.current[cursorRef.current];
    if (JSON.stringify(cur) === JSON.stringify(blocks)) return;
    historyRef.current = historyRef.current.slice(0, cursorRef.current + 1);
    historyRef.current.push(blocks);
    if (historyRef.current.length > 40) historyRef.current.shift();
    cursorRef.current = historyRef.current.length - 1;
  }, [blocks]);
  const undo = () => {
    if (cursorRef.current <= 0) return;
    cursorRef.current -= 1;
    skipNext.current = true;
    onChange(historyRef.current[cursorRef.current]);
  };
  const redo = () => {
    if (cursorRef.current >= historyRef.current.length - 1) return;
    cursorRef.current += 1;
    skipNext.current = true;
    onChange(historyRef.current[cursorRef.current]);
  };

  const selected = blocks.find((b) => b.id === selectedId) ?? null;
  const compiled = useMemo(() => compileEmail(blocks, subject), [blocks, subject]);

  const patch = (id: string, changes: Partial<EmailBlock>) =>
    onChange(blocks.map((b) => (b.id === id ? ({ ...b, ...changes } as EmailBlock) : b)));

  const move = (id: string, dir: -1 | 1) => {
    const idx = blocks.findIndex((b) => b.id === id);
    const next = idx + dir;
    if (idx < 0 || next < 0 || next >= blocks.length) return;
    const copy = blocks.slice();
    [copy[idx], copy[next]] = [copy[next], copy[idx]];
    onChange(copy);
  };
  const remove = (id: string) => {
    onChange(blocks.filter((b) => b.id !== id));
    if (selectedId === id) setSelectedId(null);
  };
  const duplicate = (id: string) => {
    const b = blocks.find((x) => x.id === id);
    if (!b) return;
    const clone = { ...b, id: uid() } as EmailBlock;
    const idx = blocks.findIndex((x) => x.id === id);
    const copy = blocks.slice();
    copy.splice(idx + 1, 0, clone);
    onChange(copy);
    setSelectedId(clone.id);
  };
  const addBlock = (type: EmailBlock["type"]) => {
    const b = factory[type]();
    onChange([...blocks, b]);
    setSelectedId(b.id);
  };

  const handleDragStart = (id: string) => setDragId(id);
  const handleDrop = (targetId: string) => {
    if (!dragId || dragId === targetId) return;
    const from = blocks.findIndex((b) => b.id === dragId);
    const to = blocks.findIndex((b) => b.id === targetId);
    if (from < 0 || to < 0) return;
    const copy = blocks.slice();
    const [item] = copy.splice(from, 1);
    copy.splice(to, 0, item);
    onChange(copy);
    setDragId(null);
  };

  const insertTag = useCallback((tag: string) => {
    if (!selected) return;
    if (selected.type === "heading" || selected.type === "text") {
      patch(selected.id, { text: (selected.text ?? "") + tag } as Partial<EmailBlock>);
    } else if (selected.type === "button") {
      patch(selected.id, { text: (selected.text ?? "") + tag } as Partial<EmailBlock>);
    }
  }, [selected, blocks]);

  const canvasWidth = device === "mobile" ? "max-w-[380px]" : "max-w-[600px]";

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border bg-gradient-to-r from-primary-soft/40 to-background p-2">
        <div className="flex items-center gap-1">
          <Button type="button" size="sm" variant="ghost" onClick={undo} disabled={cursorRef.current <= 0}>
            <Undo2 className="mr-1 h-4 w-4" /> Undo
          </Button>
          <Button type="button" size="sm" variant="ghost" onClick={redo} disabled={cursorRef.current >= historyRef.current.length - 1}>
            <Redo2 className="mr-1 h-4 w-4" /> Redo
          </Button>
          <div className="mx-2 h-6 w-px bg-border" />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button type="button" size="sm" variant="ghost" disabled={!selected || !("text" in (selected ?? {}))}>
                Merge tag
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56">
              <DropdownMenuLabel>Insert into selected block</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {MERGE_TAGS.map((m) => (
                <DropdownMenuItem key={m.tag} onClick={() => insertTag(m.tag)}>
                  <code className="mr-2 rounded bg-muted px-1.5 py-0.5 text-[11px]">{m.tag}</code>
                  <span className="text-xs text-muted-foreground">{m.label}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="inline-flex rounded-md border bg-background p-0.5">
          <button
            type="button"
            onClick={() => setDevice("desktop")}
            className={`inline-flex items-center gap-1 rounded px-2.5 py-1 text-xs font-medium transition ${device === "desktop" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Monitor className="h-3.5 w-3.5" /> Desktop
          </button>
          <button
            type="button"
            onClick={() => setDevice("mobile")}
            className={`inline-flex items-center gap-1 rounded px-2.5 py-1 text-xs font-medium transition ${device === "mobile" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Smartphone className="h-3.5 w-3.5" /> Mobile
          </button>
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-[210px_1fr_320px]">
        {/* Palette */}
        <div className="rounded-lg border bg-gradient-to-b from-muted/40 to-background p-3">
          {GROUPS.map((g) => (
            <div key={g.label} className="mb-4 last:mb-0">
              <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{g.label}</div>
              <div className="grid grid-cols-2 gap-2">
                {g.items.map(({ type, label, Icon }) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => addBlock(type)}
                    className="group flex flex-col items-center gap-1 rounded-lg border bg-background px-2 py-2.5 text-[11px] font-medium transition hover:-translate-y-0.5 hover:border-primary hover:bg-primary-soft hover:shadow-sm"
                  >
                    <Icon className="h-4 w-4 text-primary transition group-hover:scale-110" />
                    {label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Canvas */}
        <div className="rounded-lg border bg-[#E6F3F6] p-4 transition-all">
          <div className={`mx-auto rounded-xl bg-white shadow-lg transition-all ${canvasWidth}`}>
            <div className="rounded-t-xl bg-[#048BA8] px-6 py-4">
              <img src="/tsquare-logo.png" alt="T Square Solutions" className="h-11 w-auto object-contain" />
            </div>
            <div className="space-y-1 p-6">
              {blocks.map((b) => {
                const active = b.id === selectedId;
                return (
                  <div
                    key={b.id}
                    draggable
                    onDragStart={() => handleDragStart(b.id)}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() => handleDrop(b.id)}
                    onClick={() => setSelectedId(b.id)}
                    className={
                      "group relative cursor-pointer rounded-md border-2 border-transparent p-1 transition " +
                      (active ? "border-primary bg-primary-soft/40 ring-2 ring-primary/20" : "hover:border-primary/40")
                    }
                  >
                    <div dangerouslySetInnerHTML={{ __html: blockHtml(b) }} />
                    {active && (
                      <div className="absolute -top-3 right-2 flex gap-0.5 rounded-md bg-background/95 p-0.5 shadow-md ring-1 ring-border">
                        <button type="button" onClick={(e) => { e.stopPropagation(); move(b.id, -1); }} className="rounded p-1 hover:bg-muted" title="Move up">
                          <ArrowUp className="h-3.5 w-3.5" />
                        </button>
                        <button type="button" onClick={(e) => { e.stopPropagation(); move(b.id, 1); }} className="rounded p-1 hover:bg-muted" title="Move down">
                          <ArrowDown className="h-3.5 w-3.5" />
                        </button>
                        <button type="button" onClick={(e) => { e.stopPropagation(); duplicate(b.id); }} className="rounded p-1 hover:bg-muted" title="Duplicate">
                          <Copy className="h-3.5 w-3.5" />
                        </button>
                        <button type="button" onClick={(e) => { e.stopPropagation(); remove(b.id); }} className="rounded p-1 text-destructive hover:bg-destructive/10" title="Delete">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
              {blocks.length === 0 && (
                <div className="rounded-md border-2 border-dashed p-10 text-center text-sm text-muted-foreground">
                  <ImageIcon className="mx-auto mb-2 h-8 w-8 opacity-40" />
                  Drag or click blocks from the left panel to start.
                </div>
              )}
            </div>
            <div className="rounded-b-xl bg-[#fafcfd] px-6 py-4 text-center text-[11px] text-[#7a8b92]">
              <strong className="text-[#0F1F24]">T Square Solutions</strong> · Trusted cleaning services
            </div>
          </div>
        </div>

        {/* Inspector */}
        <div className="rounded-lg border bg-background p-3">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {selected ? `Edit ${selected.type}` : "Select a block"}
            </div>
            {selected && (
              <span className="rounded-full bg-primary-soft px-2 py-0.5 text-[10px] font-medium text-primary">
                {selected.type}
              </span>
            )}
          </div>
          {selected ? (
            <Inspector block={selected} patch={(c) => patch(selected.id, c)} />
          ) : (
            <p className="text-xs text-muted-foreground">Click any block in the preview to edit it.</p>
          )}
          <details className="mt-4">
            <summary className="cursor-pointer text-xs font-medium text-muted-foreground">View raw HTML</summary>
            <textarea readOnly value={compiled} className="mt-2 h-40 w-full rounded border bg-muted/40 p-2 font-mono text-[10px]" />
          </details>
        </div>
      </div>
    </div>
  );
}

/* ---------- Inspector ---------- */

function Inspector({ block, patch }: { block: EmailBlock; patch: (c: Partial<EmailBlock>) => void }) {
  const alignRow = (value: Align, onChange: (v: Align) => void) => (
    <div>
      <Label className="text-xs">Align</Label>
      <Select value={value} onValueChange={(v) => onChange(v as Align)}>
        <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="left">Left</SelectItem>
          <SelectItem value="center">Center</SelectItem>
          <SelectItem value="right">Right</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
  const colorRow = (label: string, value: string, onChange: (v: string) => void) => (
    <div>
      <Label className="text-xs">{label}</Label>
      <div className="flex gap-2">
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-8 w-10 cursor-pointer rounded border" />
        <Input value={value} onChange={(e) => onChange(e.target.value)} className="h-8 flex-1 font-mono text-xs" />
      </div>
    </div>
  );

  switch (block.type) {
    case "heading":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Text</Label>
            <Input value={block.text} onChange={(e) => patch({ text: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Level</Label>
            <Select value={String(block.level)} onValueChange={(v) => patch({ level: Number(v) as 1 | 2 | 3 })}>
              <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="1">H1 — Large</SelectItem>
                <SelectItem value="2">H2 — Medium</SelectItem>
                <SelectItem value="3">H3 — Small</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {alignRow(block.align, (v) => patch({ align: v }))}
          {colorRow("Color", block.color, (v) => patch({ color: v }))}
        </div>
      );
    case "text":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Text</Label>
            <Textarea rows={5} value={block.text} onChange={(e) => patch({ text: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Font size (px)</Label>
            <Input type="number" min={10} max={32} value={block.size} onChange={(e) => patch({ size: Number(e.target.value) || 16 })} />
          </div>
          {alignRow(block.align, (v) => patch({ align: v }))}
          {colorRow("Color", block.color, (v) => patch({ color: v }))}
        </div>
      );
    case "button":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Label</Label>
            <Input value={block.text} onChange={(e) => patch({ text: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs flex items-center gap-1"><LinkIcon className="h-3 w-3" /> URL</Label>
            <Input value={block.url} onChange={(e) => patch({ url: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Corner radius (px)</Label>
            <Input type="number" min={0} max={40} value={block.radius} onChange={(e) => patch({ radius: Number(e.target.value) || 0 })} />
          </div>
          {colorRow("Background", block.bg, (v) => patch({ bg: v }))}
          {colorRow("Text color", block.color, (v) => patch({ color: v }))}
          {alignRow(block.align, (v) => patch({ align: v }))}
        </div>
      );
    case "image":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Image URL</Label>
            <Input value={block.src} onChange={(e) => patch({ src: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Link URL (optional)</Label>
            <Input value={block.url ?? ""} onChange={(e) => patch({ url: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Alt text</Label>
            <Input value={block.alt} onChange={(e) => patch({ alt: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Width (px)</Label>
            <Input type="number" min={100} max={600} value={block.width} onChange={(e) => patch({ width: Number(e.target.value) || 520 })} />
          </div>
          {alignRow(block.align, (v) => patch({ align: v }))}
        </div>
      );
    case "divider":
      return <div className="space-y-3">{colorRow("Color", block.color, (v) => patch({ color: v }))}</div>;
    case "spacer":
      return (
        <div>
          <Label className="text-xs">Height (px)</Label>
          <Input type="number" min={4} max={120} value={block.height} onChange={(e) => patch({ height: Number(e.target.value) || 24 })} />
        </div>
      );
    case "bullets":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Items (one per line)</Label>
            <Textarea rows={6} value={block.items.join("\n")} onChange={(e) => patch({ items: e.target.value.split("\n").filter(Boolean) })} />
          </div>
          {colorRow("Color", block.color, (v) => patch({ color: v }))}
        </div>
      );
    case "quote":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Quote</Label>
            <Textarea rows={4} value={block.text} onChange={(e) => patch({ text: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Author</Label>
            <Input value={block.author} onChange={(e) => patch({ author: e.target.value })} />
          </div>
          {colorRow("Accent", block.accent, (v) => patch({ accent: v }))}
        </div>
      );
    case "columns":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Left column</Label>
            <Textarea rows={4} value={block.left} onChange={(e) => patch({ left: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Right column</Label>
            <Textarea rows={4} value={block.right} onChange={(e) => patch({ right: e.target.value })} />
          </div>
          {colorRow("Text color", block.color, (v) => patch({ color: v }))}
        </div>
      );
    case "social":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Facebook URL</Label>
            <Input value={block.facebook} onChange={(e) => patch({ facebook: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Instagram URL</Label>
            <Input value={block.instagram} onChange={(e) => patch({ instagram: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Twitter URL</Label>
            <Input value={block.twitter} onChange={(e) => patch({ twitter: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">LinkedIn URL</Label>
            <Input value={block.linkedin} onChange={(e) => patch({ linkedin: e.target.value })} />
          </div>
          {alignRow(block.align, (v) => patch({ align: v }))}
        </div>
      );
    case "video":
      return (
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Thumbnail URL</Label>
            <Input value={block.thumb} onChange={(e) => patch({ thumb: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Video / link URL</Label>
            <Input value={block.url} onChange={(e) => patch({ url: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Caption</Label>
            <Input value={block.title} onChange={(e) => patch({ title: e.target.value })} />
          </div>
        </div>
      );
    case "html":
      return (
        <div>
          <Label className="text-xs">Custom HTML</Label>
          <Textarea rows={8} value={block.html} onChange={(e) => patch({ html: e.target.value })} className="font-mono text-xs" />
        </div>
      );
  }
}
